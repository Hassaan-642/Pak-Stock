import React from 'react';
import { useState } from 'react';
// import { UserProvider } from './Components/Context/UserContext.jsx';
import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom';
// import Dashboard from './Components/Dashboard';
import Register from './Components/Register/Register'
import Login from './Components/Login/Login'
import Dashboard from './pages/Dashboard';
import LoginOTP from './Components/Login/LoginOTP';
import OTP from './Components/Register/RegisterOTP';
import MainHome from './pages/MainHome'
// import Detail from './pages/DetailedRecommendationPage';

import AboutUs from './Components/Layout/AboutUs';
import Disclaimer from './Components/Layout/disclaimer';
import TermsOfUse from './Components/Layout/terms-of-use';
import HelpCenter from './Components/Layout/help-center';
import PrivacyPolicy from './Components/Layout/privacy-policy';
import axios from 'axios';
import AdminPanel from './pages/Admin';
import ProtectedRoute from './Services/ProtectedRoute';
import { ToastContainer } from 'react-toastify';
import UserProfile from './Components/Layout/Userprofile';
import UserManagement from './pages/Admin';
import CommunityPosts from './Components/Layout/CommunityPosts';
import StockDiscussion from './Components/Layout/StockDiscussion';
import CreatePostForm from './Components/Layout/CreatePostsForm';
import { getAuth } from "firebase/auth";
// import RichTextForm, { BlogCreationComponent,  } from './Components/Layout/ContentInput';

import TextEditor from './Components/Layout/ContentInput';
import NewsItem from './Components/Layout/NewsItemsCard';
import ProfileEditPage from './Components/Layout/EditProflie';
import { BlogDisplayComponent } from './Components/Layout/BlogDisplay';
import ArticlesGrid from './Components/Layout/NewsItemsCard';
import BlogCreationComponent from './Components/Layout/ContentInput';
import DetailedAnalysisPage from './Components/Layout/DetailRecommendation';
import EmailVerificationPage from './Components/Login/email-verification';
import ForgotPassword from './Components/Login/Forgetpassword';
import ChatbotComponent from './Components/Layout/Chatbot';
import ChatSystem from './Components/Layout/chat/ChatSystem';
import BrokerVerification from './pages/Broker_verify';
import BrokerVerificationForm from './pages/BrokerVerification';
// import { getAuth } from "firebase/auth";




const fetchAndStoreJwt = async () => {
  const auth = getAuth();
  const user = auth.currentUser;

  if (user) {
    try {
      const token = await user.getIdToken();
      sessionStorage.setItem("jwtToken", token); // Store token in sessionStorage
      console.log("JWT Token stored:", token);
    } catch (error) {
      console.error("Error fetching token:", error);
    }
  } else {
    console.log("No user is signed in.");
  }
};


const router = createBrowserRouter([
  {
    path: '/',
    element: <Dashboard/> // Protected route
  },
  {
    path: '/Login',
    element: <Login/> // Protected route
  },
  {
    path: '/Register',
    element: <Register/> // Protected route
  },
  {
    path: '/Dashboard',
    element: <Dashboard/> // Protected route
  },
  {
    path: '/Admin',
    element: <AdminPanel/> // Protected route
  },
  { 
    path:"/community",
    element:<CommunityPosts />
  }, 
  {
    path:"/stocks/:stockId/discussion", 
    element:<StockDiscussion />
  },
  {
    path:"/create-post", 
    element:<CreatePostForm />
  },
  {
    path:"/posts/:postId", 
    element:<StockDiscussion />
  },
  {
    path:'/DetailRecommendationPage/:stock_symbol',
    element:<DetailedAnalysisPage/>
  },
  {
    path:'/LoginOTP',
    element:<LoginOTP/>
  },
  {
    path:'/MainHome',
    element:<MainHome/>
  },
  {
    path:'/AboutUs',
    element:<AboutUs/>
  },
  {
    path:'/PrivacyPolicy',
    element:<PrivacyPolicy/>
  },
  {
    path:'/TermsOfUse',
    element:<TermsOfUse/>
  },
  {
    path:'/Disclaimer',
    element:<Disclaimer/>
  },
  {
    path:'/HelpCenter',
    element:<HelpCenter/>
  },
  {
    path:'/Userprofile',
    element:<UserProfile/>
  },
  {
    path:'/ContentInput',
    element:<BlogCreationComponent/>
  },
  {
    path:'/ContentDisplay/:articleId',
    element:<BlogDisplayComponent/>
  },
  {
    path:'/NewsItem',
    element:<ArticlesGrid/>
  },
  {
    path:'/EditProfile',
    element:<ProfileEditPage/>
  },
  {
    path:'/email-verification',
    element:<EmailVerificationPage/>
  },
  {
    path:'/forgot-password',
    element:<ForgotPassword/>
  },
  {
    path:'/Chatbot',
    element:<ChatbotComponent/>
  },
  {
    path: '/Chatrooms',
    element: <ChatSystem/>
  },
  {
    path: '/Broker-Verification',
    element: <BrokerVerification/>
  },
  {
    path: '/Broker-Verification-form',
    element: <BrokerVerificationForm/>
  }
]);


const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  return (
    <div>
      <ToastContainer position="top-right" autoClose={3000} />
    <RouterProvider router={router} />
  </div>
  );
};

export default App;