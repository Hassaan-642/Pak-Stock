// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth";
import {firestore, getFirestore} from 'firebase/firestore';
import { getStorage } from "firebase/storage";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAKyDqE5BvPRAqO-gFJdAQMnfCEqQkct4I",
  authDomain: "pak-stock.firebaseapp.com",
  projectId: "pak-stock",
  storageBucket: "pak-stock.firebasestorage.app",
  messagingSenderId: "111489176611",
  appId: "1:111489176611:web:f29ea4025ea78e4af78d96"
};

// Initialize Firebase

const app = initializeApp(firebaseConfig);
export const auth = getAuth();
export const db = getFirestore();
export const storage = getStorage(app);

export default app;
