import React from 'react'
import { ArrowRight, BarChart2, Users, MessageCircle, Bot, TrendingUp, Brain } from 'lucide-react'

const objectives = [
  {
    icon: <BarChart2 className="h-8 w-8 text-blue-500" />,
    title: "User-Friendly Web Platform",
    description: "Develop an intuitive platform integrating prediction systems, sentiment analysis, recommendations, and real-time communication features."
  },
  {
    icon: <Brain className="h-8 w-8 text-blue-500" />,
    title: "Advanced Prediction Models",
    description: "Train machine learning models to forecast stock market movements with high accuracy and reliability."
  },
  {
    icon: <TrendingUp className="h-8 w-8 text-blue-500" />,
    title: "Market Sentiment Analysis",
    description: "Provide up-to-date market sentiment analysis to enhance decision-making processes for investors."
  },
  {
    icon: <ArrowRight className="h-8 w-8 text-blue-500" />,
    title: "Intelligent Recommendations",
    description: "Generate buy/sell/hold recommendations based on predicted stock data, technical indicators, and sentiment analysis."
  },
  {
    icon: <Users className="h-8 w-8 text-blue-500" />,
    title: "Community Collaboration",
    description: "Foster a vibrant community where investors can share insights, ask questions, and engage in meaningful discussions."
  },
  {
    icon: <Bot className="h-8 w-8 text-blue-500" />,
    title: "AI-Powered Assistance",
    description: "Implement an LLM-based chatbot to answer queries related to technical stock terms and PSX-specific information."
  },
  {
    icon: <MessageCircle className="h-8 w-8 text-blue-500" />,
    title: "Real-Time Communication",
    description: "Enable seamless communication between users and brokers to facilitate informed investing decisions."
  }
]

export default function AboutUs() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold text-blue-900 mb-2">About PakStock</h1>
          <p className="text-xl text-blue-700">Pakistan Stock Exchange Prediction and Recommendation System</p>
        </header>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold text-blue-800 mb-6">Our Mission</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            PakStock aims to revolutionize financial decision-making in the Pakistan Stock Exchange by empowering investors with innovative tools and insights. We're committed to providing a comprehensive platform that combines cutting-edge technology with user-friendly features, enabling investors of all levels to navigate the market with confidence and precision.
          </p>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold text-blue-800 mb-6">Our Objectives</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {objectives.map((objective, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 transition-all duration-300 hover:shadow-lg">
                <div className="flex items-center mb-4">
                  {objective.icon}
                  <h3 className="text-xl font-semibold text-blue-700 ml-3">{objective.title}</h3>
                </div>
                <p className="text-gray-600">{objective.description}</p>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-3xl font-semibold text-blue-800 mb-6">Join Us in Shaping the Future of PSX Investing</h2>
          <p className="text-lg text-gray-700 leading-relaxed mb-8">
            By achieving these objectives, PakStock is set to enhance user engagement, satisfaction, and retention rates. We're committed to fostering a more efficient investment landscape in Pakistan, where investors can make informed decisions backed by data-driven insights and community collaboration.
          </p>
          <div className="text-center">
            <a href="/dashboard" className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors duration-300">
              Get Started with PakStock
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </div>
        </section>
      </div>
    </div>
  )
}