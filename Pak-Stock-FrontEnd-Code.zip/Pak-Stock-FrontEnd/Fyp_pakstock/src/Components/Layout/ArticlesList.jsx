// src/Components/ArticlesList.js
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/Card";

const ArticlesList = ({ articles }) => (
  <Card className="w-full">
    <CardHeader>
      <CardTitle>Recent Articles</CardTitle>
    </CardHeader>
    <CardContent>
      {articles.map((article) => (
        <div key={article.article_id} className="mb-4">
          <h3 className="font-bold">{article.title}</h3>
          <p>{article.description}</p>
          <p>Published: {article.publish_date}</p>
          <p>Sentiment: {article.label}</p>
        </div>
      ))}
    </CardContent>
  </Card>
);

export default ArticlesList;
