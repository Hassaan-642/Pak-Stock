import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import { Button } from '../ui/Button';
import { Skeleton } from '../ui/Skeleton';
import { AlertCircle, ArrowLeft, Calendar, Eye, User, Share2, Trash2, Menu } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '../ui/Alert';
import HomepageSidebar from './HomePageSidebar';
import { blogService } from '../../Services/api/BlogService';
import { getAuth, onAuthStateChanged } from 'firebase/auth';

export const BlogDisplayComponent = () => {
  const { articleId } = useParams();
  const navigate = useNavigate();
  const [blogData, setBlogData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showShareOptions, setShowShareOptions] = useState(false);
  const [userId, setUserId] = useState(null);
  const [username, setUsername] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState(null);
  
  // Add state for sidebar control
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Function to toggle sidebar
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Firebase authentication setup
  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUserId(user.uid);
        setUsername(user.displayName || 'Anonymous');
       
        // Check if user is admin using Firestore
        try {
          // Import needed Firestore modules
          const { doc, getDoc, getFirestore } = await import('firebase/firestore');
          const db = getFirestore();
         
          const userDoc = doc(db, "Users", user.uid);
          const docSnap = await getDoc(userDoc);
         
          if (docSnap.exists()) {
            const userData = docSnap.data();
            setUserRole(userData.role || 'User');
            setIsAdmin(userData.role === 'Admin'); // Note: Case-sensitive match 'Admin' not 'admin'
            console.log("User role detected:", userData.role);
          } else {
            setUserRole('User');
            setIsAdmin(false);
            console.log("User document doesn't exist");
          }
        } catch (error) {
          console.error("Error checking admin status:", error);
          setUserRole('User');
          setIsAdmin(false);
        }
      } else {
        setUserId(null);
        setUsername(null);
        setUserRole(null);
        setIsAdmin(false);
        console.log("No user logged in");
      }
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const fetchBlogData = async () => {
      try {
        const data = await blogService.fetchBlogArticle(articleId);
        console.log('Fetched blog data:', data);
        setBlogData(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchBlogData();
  }, [articleId]);

  const handleGoBack = () => {
    navigate(-1);
  };

  const toggleShareOptions = () => {
    setShowShareOptions(!showShareOptions);
  };

  // Function to delete article
  const handleDeleteArticle = async () => {
    // Confirm deletion
    if (!window.confirm("Are you sure you want to delete this article? This action cannot be undone.")) {
      return;
    }

    setDeleteLoading(true);
    setDeleteError(null);

    try {
      const response = await fetch(`https://pakstock-deployed-backend-production.up.railway.app/api/user-articles?article_id=${articleId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
         // Include cookies for authentication
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to delete article');
      }

      // On successful deletion, navigate back to articles list
      navigate('/NewsItem', { replace: true });
      // Optionally show a success message
      alert('Article deleted successfully');
    } catch (err) {
      setDeleteError(err.message || 'Failed to delete article');
    } finally {
      setDeleteLoading(false);
    }
  };

  const shareToSocialMedia = (platform) => {
    if (!blogData) return;

    // Get the exact current URL of the page
    const currentUrl = window.location.href;
    const title = encodeURIComponent(blogData.title);
    const encodedUrl = encodeURIComponent(currentUrl);
    let shareUrl = '';

    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${title}&url=${encodedUrl}`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
        break;
      case 'whatsapp':
        shareUrl = `https://api.whatsapp.com/send?text=${title}%20${encodedUrl}`;
        break;
      case 'telegram':
        shareUrl = `https://t.me/share/url?url=${encodedUrl}&text=${title}`;
        break;
      default:
        return;
    }

    // Open in a new window or tab
    window.open(shareUrl, '_blank', 'noopener,noreferrer');
  };

  // Function to copy the current URL to clipboard
  const copyLinkToClipboard = () => {
    const currentUrl = window.location.href;
    navigator.clipboard.writeText(currentUrl).then(() => {
      alert("Link copied to clipboard!");
      setShowShareOptions(false);
    }).catch(err => {
      console.error('Failed to copy: ', err);
    });
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-8">
        <Skeleton className="w-full h-12 mb-4" />
        <Skeleton className="w-3/4 h-6 mb-2" />
        <Skeleton className="w-1/2 h-6 mb-8" />
        <Skeleton className="w-full h-64" />
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive" className="max-w-4xl mx-auto mt-8">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!blogData) {
    return (
      <Alert className="max-w-4xl mx-auto mt-8">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>No Content</AlertTitle>
        <AlertDescription>No blog data available</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-100 ml-0 md:ml-[250px]">
      <HomepageSidebar onToggle={toggleSidebar} isOpen={isSidebarOpen} />
      <div className={`flex-grow p-8 transition-all duration-300 ${isSidebarOpen ? 'ml-0 md:ml-[250px]' : 'ml-0'}`}>
        {/* Mobile menu button - only visible on small screens */}
        <div className="md:hidden flex items-center mb-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={toggleSidebar}
            className="mr-2"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <span className="font-medium">Menu</span>
        </div>
        
        {deleteError && (
          <Alert variant="destructive" className="max-w-4xl mx-auto mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Delete Error</AlertTitle>
            <AlertDescription>{deleteError}</AlertDescription>
          </Alert>
        )}
        
        <Card className="mx-auto shadow-lg">
          <CardHeader className="space-y-4">
            <div className="flex justify-between items-center">
              <Button
                variant="ghost"
                size="sm"
                className="mb-4"
                onClick={handleGoBack}
              >
                <ArrowLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <div className="flex items-center gap-2">
                {isAdmin && (
                  <Button
                    variant="destructive"
                    size="sm"
                    className="mb-4"
                    onClick={handleDeleteArticle}
                    disabled={deleteLoading}
                  >
                    <Trash2 className="mr-2 h-4 w-4" /> 
                    {deleteLoading ? 'Deleting...' : 'Delete Article'}
                  </Button>
                )}
                <div className="relative">
                  <Button
                    variant="outline"
                    size="sm"
                    className="mb-4 flex items-center"
                    onClick={toggleShareOptions}
                  >
                    <Share2 className="mr-2 h-4 w-4" /> Share
                  </Button>
                  {showShareOptions && (
                    <div className="absolute right-0 mt-2 p-4 bg-white rounded-md shadow-lg z-10 border border-gray-200 w-64">
                      <h3 className="text-sm font-medium mb-2">Share this article</h3>
                      <div className="grid grid-cols-5 gap-3 mb-3">
                        {/* Facebook */}
                        <button 
                          onClick={() => shareToSocialMedia('facebook')}
                          className="p-2 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors"
                          title="Share on Facebook"
                        >
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z" />
                          </svg>
                        </button>
                        
                        {/* Twitter/X */}
                        <button 
                          onClick={() => shareToSocialMedia('twitter')}
                          className="p-2 rounded-full bg-black text-white hover:bg-gray-800 transition-colors"
                          title="Share on Twitter/X"
                        >
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                          </svg>
                        </button>
                        
                        {/* LinkedIn */}
                        <button 
                          onClick={() => shareToSocialMedia('linkedin')}
                          className="p-2 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                          title="Share on LinkedIn"
                        >
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M4.98 3.5C4.98 4.881 3.87 6 2.5 6S.02 4.881.02 3.5C.02 2.12 1.13 1 2.5 1s2.48 1.12 2.48 2.5zM5 8H0v16h5V8zm7.982 0H8.014v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0V24H24V13.869c0-7.88-8.922-7.593-11.018-3.714V8z" />
                          </svg>
                        </button>
                        
                        {/* WhatsApp */}
                        <button 
                          onClick={() => shareToSocialMedia('whatsapp')}
                          className="p-2 rounded-full bg-green-500 text-white hover:bg-green-600 transition-colors"
                          title="Share on WhatsApp"
                        >
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                          </svg>
                        </button>
                        
                        {/* Telegram */}
                        <button 
                          onClick={() => shareToSocialMedia('telegram')}
                          className="p-2 rounded-full bg-blue-400 text-white hover:bg-blue-500 transition-colors"
                          title="Share on Telegram"
                        >
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z" />
                          </svg>
                        </button>
                      </div>
                      
                      {/* Copy Link Button */}
                      <button 
                        onClick={copyLinkToClipboard}
                        className="mt-2 w-full p-2 bg-gray-100 hover:bg-gray-200 rounded-md flex items-center justify-center text-sm transition-colors"
                      >
                        <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        Copy link
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <CardTitle className="text-3xl font-bold">{blogData.title}</CardTitle>
            <div className="flex items-center justify-between text-sm text-gray-500">
              <div className="flex items-center space-x-4">
                <div className="flex items-center">
                  <User className="mr-2 h-4 w-4" />
                  <span>{blogData.username}</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="mr-2 h-4 w-4" />
                  <span>{new Date(blogData.date_created).toLocaleDateString()}</span>
                </div>
              </div>
              <div className="flex items-center">
                <Eye className="mr-2 h-4 w-4" />
                <span>{blogData.view_count || 0} views</span>
              </div>
            </div>
          </CardHeader>
          
          {/* Article Images */}
          {blogData.images && blogData.images.length > 0 && (
            <div className="px-6">
              <div className="w-full h-full overflow-hidden rounded-lg mb-6">
                <img
                  src={blogData.images[0].image_url}
                  alt={blogData.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.src = "/api/placeholder/800/400";
                  }}
                />
              </div>
            </div>
          )}

          <CardContent className="space-y-6">
            <div 
              className="prose max-w-none"
              dangerouslySetInnerHTML={{ __html: blogData.content.replace(/\\"/g, '"') }}
            />
          </CardContent>
          <CardFooter className="flex justify-between items-center">
            
            <div className="flex space-x-2">
              <div className="text-sm text-gray-500 mr-2 flex items-center">
                <Share2 className="mr-1 h-4 w-4" /> Share:
              </div>
              <button 
                onClick={() => shareToSocialMedia('facebook')}
                className="p-1.5 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors"
                title="Share on Facebook"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z" />
                </svg>
              </button>
              <button 
                onClick={() => shareToSocialMedia('twitter')}
                className="p-1.5 rounded-full bg-black text-white hover:bg-gray-800 transition-colors"
                title="Share on Twitter/X"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </button>
              <button 
                onClick={() => shareToSocialMedia('linkedin')}
                className="p-1.5 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                title="Share on LinkedIn"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M4.98 3.5C4.98 4.881 3.87 6 2.5 6S.02 4.881.02 3.5C.02 2.12 1.13 1 2.5 1s2.48 1.12 2.48 2.5zM5 8H0v16h5V8zm7.982 0H8.014v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0V24H24V13.869c0-7.88-8.922-7.593-11.018-3.714V8z" />
                </svg>
              </button>
              <button 
                onClick={() => shareToSocialMedia('whatsapp')}
                className="p-1.5 rounded-full bg-green-500 text-white hover:bg-green-600 transition-colors"
                title="Share on WhatsApp"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default BlogDisplayComponent;