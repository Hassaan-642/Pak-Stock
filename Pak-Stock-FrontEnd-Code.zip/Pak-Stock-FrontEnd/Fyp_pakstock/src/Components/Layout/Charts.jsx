// Charts.js
import React from 'react';
import PriceChart from './PriceChart.jsx';
import VolumeChart from './VolumeChart.jsx';
import MarketChart from './MarketChart.jsx';
import LiveStockInfo from './LiveStockInfo.jsx';

const Charts = ({ stockName, days, stockData }) => {
  const currentDate = new Date().toLocaleDateString();
  const currentTime = new Date().toLocaleTimeString();

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2 style={styles.stockName}>{stockName}</h2>
        
      </div>
      <div style={styles.chartsColumn}>
               <VolumeChart />
               <PriceChart stockName={stockName} days={days} />

        <MarketChart />
      </div>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: 'white',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    padding: '20px',
    margin: '20px',
    maxWidth: '1500px',
    width: '100%',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '20px',
  },
  stockName: {
    fontSize: '24px',
    fontWeight: 'bold',
    margin: 0,
  },
  priceInfo: {
    textAlign: 'right',
  },
  days: {
    fontSize: '20px',
    fontWeight: 'bold',
    margin: '0 0 5px 0',
  },
  dateTime: {
    fontSize: '14px',
    color: '#666',
    margin: 0,
  },
  chartsColumn: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
  },
};

export default Charts;
