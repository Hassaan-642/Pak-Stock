import React, { useState, useRef, useEffect } from 'react';

const ChatbotWithModal = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { text: "Hi, I'm your financial assistant. Ask me anything about stocks, investments, or financial data.", sender: 'bot' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorType, setErrorType] = useState(null);
  const messagesEndRef = useRef(null);

  // IMPORTANT: This is your API endpoint
  const API_URL = 'http://localhost:8000/api/chatbot-query';

  // Auto-scroll to the most recent message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
  };

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleSend = async () => {
    if (inputValue.trim() === '') return;

    // Reset error state
    setErrorType(null);

    // Add user message to chat
    const userMessage = { text: inputValue, sender: 'user' };
    setMessages(prevMessages => [...prevMessages, userMessage]);
    
    // Clear input field
    setInputValue('');
    
    // Show loading state
    setIsLoading(true);
    
    try {
      console.log("Attempting to connect to:", API_URL);
      
      // Send request to backend API with additional CORS mode
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Adding headers that might help with CORS
          'Accept': 'application/json',
        },
        mode: 'cors', // Explicitly set CORS mode
        body: JSON.stringify({ user_query: userMessage.text })
      });
      
      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log("Response received:", data);
      
      // Add bot response to chat
      setMessages(prevMessages => [
        ...prevMessages, 
        { text: data.response, sender: 'bot' }
      ]);
      
    } catch (error) {
      console.error('Error:', error);
      
      // Determine error type to provide better feedback
      if (error.message.includes('NetworkError') || error.message.includes('Failed to fetch')) {
        setErrorType('connection');
      } else if (error.message.includes('cors') || error.message.includes('CORS')) {
        setErrorType('cors');
      } else {
        setErrorType('unknown');
      }
      
      const errorMessage = getErrorMessage(errorType);
      setMessages(prevMessages => [
        ...prevMessages, 
        { text: errorMessage, sender: 'bot', isError: true }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper function to get appropriate error message
  const getErrorMessage = (type) => {
    switch (type) {
      case 'connection':
        return `Unable to connect to the server at ${API_URL}. Please check if your backend is running.`;
      case 'cors':
        return 'CORS error: Your backend server needs to allow requests from your frontend. Check the backend CORS configuration.';
      default:
        return 'An error occurred while communicating with the server. Check the console for more details.';
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <>
      {/* Floating bot button */}
      <button
        onClick={toggleChatbot}
        className="fixed bottom-8 right-20 bg-blue-600 text-white rounded-full w-18 h-18 flex items-center justify-center shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 z-30"
      >
        {isOpen ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
        )}
      </button>

      {/* Modal overlay with blur effect */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-20">
          {/* Close overlay when clicking outside the chatbot */}
          <div className="absolute inset-0" onClick={toggleChatbot}></div>
          
          {/* Chatbot modal */}
          <div 
            className="relative w-full max-w-md h-[700px] mx-4 bg-white rounded-lg shadow-xl z-30 flex flex-col"
            onClick={(e) => e.stopPropagation()} // Prevent closing when clicking on the chatbot
          >
            {/* Chat header */}
            <div className="bg-blue-600 text-white py-3 px-4 rounded-t-lg flex justify-between items-center">
              <h2 className="text-xl font-semibold">Financial Assistant PakStock</h2>
              <button 
                onClick={toggleChatbot}
                className="text-white hover:text-gray-200 focus:outline-none"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            {/* Messages container */}
            <div className="flex-1 p-4 overflow-y-auto">
              {messages.map((message, index) => (
                <div 
                  key={index} 
                  className={`mb-4 ${message.sender === 'user' ? 'text-right' : ''}`}
                >
                  <div 
                    className={`inline-block rounded-lg py-2 px-3 max-w-xs ${
                      message.sender === 'user' 
                        ? 'bg-blue-500 text-white rounded-br-none' 
                        : message.isError
                          ? 'bg-red-100 text-red-800 border border-red-300 rounded-bl-none'
                          : 'bg-gray-200 text-gray-800 rounded-bl-none'
                    }`}
                  >
                    {message.text}
                  </div>
                </div>
              ))}
              
              {isLoading && (
                <div className="mb-4">
                  <div className="inline-block bg-gray-200 text-gray-800 rounded-lg py-2 px-3 rounded-bl-none">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
            
            {/* Error guidance message if there's an error */}
            {errorType && (
              <div className="bg-red-100 border-l-4 border-red-500 p-3 text-sm">
                <p className="font-bold text-red-700">Connection Troubleshooting</p>
                <p className="text-red-600 mt-1">
                  {errorType === 'cors' ? (
                    <>
                      This looks like a CORS issue. Add these headers to your backend:
                      <pre className="mt-1 bg-red-50 p-2 rounded text-xs">
                        Access-Control-Allow-Origin: *<br/>
                        Access-Control-Allow-Methods: POST, GET, OPTIONS<br/>
                        Access-Control-Allow-Headers: Content-Type
                      </pre>
                    </>
                  ) : (
                    "Make sure your server is running and accessible. Try testing the endpoint in Postman again."
                  )}
                </p>
              </div>
            )}
            
            {/* Input area */}
            <div className="border-t p-3 flex">
              <input
                type="text"
                value={inputValue}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                placeholder="Ask about stocks, investments..."
                className="flex-1 border rounded-l-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button 
                onClick={handleSend}
                disabled={isLoading}
                className="bg-blue-600 text-white rounded-r-lg px-4 py-2 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
              >
                Send
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatbotWithModal;