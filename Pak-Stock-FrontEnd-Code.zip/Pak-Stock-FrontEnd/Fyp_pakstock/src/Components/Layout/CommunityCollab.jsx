import React, { useState, useEffect, useRef } from 'react';
import { ThumbsUp, ThumbsDown, MessageSquare, Send, User, Loader2 } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "../ui/Avatar"
import { Button } from "../ui/Button"
import { Card, CardContent, CardFooter, CardHeader } from "../ui/Card"
import { Input } from "../ui/Input"
import { Textarea } from "../ui/Textarea"
import { Separator } from "../ui/separator"

const CommunityCollaboration = () => {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const commentInputRefs = useRef({});

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      setPosts([
        { id: 1, content: 'This is a sample post about investing strategies.', votes: 5, comments: [], author: 'JohnDoe', avatar: 'https://i.pravatar.cc/150?img=1' },
        { id: 2, content: 'What are your thoughts on diversification?', votes: 3, comments: [], author: 'JaneSmith', avatar: 'https://i.pravatar.cc/150?img=2' }
      ]);
      setIsLoading(false);
    };

    fetchData();
  }, []);

  const handleNewPost = () => {
    if (newPost.trim()) {
      setPosts([
        { 
          id: Date.now(), 
          content: newPost, 
          votes: 0, 
          comments: [], 
          author: 'CurrentUser', 
          avatar: 'https://i.pravatar.cc/150?img=3'
        },
        ...posts
      ]);
      setNewPost('');
    }
  };

  const handleVote = (id, increment) => {
    setPosts(posts.map(post => 
      post.id === id ? { ...post, votes: post.votes + increment } : post
    ));
  };

  const handleAddComment = (postId, comment) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, comments: [...post.comments, { id: Date.now(), content: comment, author: 'CurrentUser', avatar: 'https://i.pravatar.cc/150?img=3' }] } 
        : post
    ));
    if (commentInputRefs.current[postId]) {
      commentInputRefs.current[postId].value = '';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-r from-blue-100 to-indigo-100">
        <Loader2 className="h-16 w-16 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r  to-indigo-100 min-h-screen p-8">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-8">
          <CardHeader>
            <h1 className="text-3xl font-bold text-blue-800">Community Hub</h1>
          </CardHeader>
          <CardContent>
            <div className="flex items-start space-x-4">
              <Avatar>
                <AvatarImage src="https://i.pravatar.cc/150?img=3" alt="Current User" />
                <AvatarFallback>CU</AvatarFallback>
              </Avatar>
              <div className="flex-grow">
                <Textarea
                  placeholder="What's on your mind?"
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="justify-end">
            <Button onClick={handleNewPost}>Post</Button>
          </CardFooter>
        </Card>

        <div className="space-y-6">
          {posts.map(post => (
            <Card key={post.id} className="overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src={post.avatar} alt={post.author} />
                    <AvatarFallback>{post.author[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-blue-800">{post.author}</h3>
                    <p className="text-sm text-gray-500">Posted 2 hours ago</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-gray-700 mb-4">{post.content}</p>
                <div className="flex items-center space-x-4 mb-4">
                  <Button variant="ghost" size="sm" onClick={() => handleVote(post.id, 1)} className="text-blue-500 hover:text-blue-700">
                    <ThumbsUp size={18} className="mr-1" />
                    <span>{post.votes}</span>
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleVote(post.id, -1)} className="text-red-500 hover:text-red-700">
                    <ThumbsDown size={18} />
                  </Button>
                  <Button variant="ghost" size="sm" className="text-green-500 hover:text-green-700">
                    <MessageSquare size={18} className="mr-1" />
                    <span>{post.comments.length} Comments</span>
                  </Button>
                </div>
                <Separator className="my-4" />
                <div className="space-y-4">
                  {post.comments.map(comment => (
                    <div key={comment.id} className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3 mb-2">
                        <Avatar>
                          <AvatarImage src={comment.avatar} alt={comment.author} />
                          <AvatarFallback>{comment.author[0]}</AvatarFallback>
                        </Avatar>
                        <h4 className="font-semibold text-gray-800">{comment.author}</h4>
                      </div>
                      <p className="text-gray-700">{comment.content}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex items-center space-x-2 w-full">
                  <Avatar>
                    <AvatarImage src="https://i.pravatar.cc/150?img=3" alt="Current User" />
                    <AvatarFallback>CU</AvatarFallback>
                  </Avatar>
                  <Input 
                    ref={el => commentInputRefs.current[post.id] = el}
                    placeholder="Write a comment..." 
                    className="flex-grow"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && e.target.value.trim()) {
                        handleAddComment(post.id, e.target.value);
                      }
                    }}
                  />
                  <Button 
                    size="icon"
                    onClick={() => {
                      const input = commentInputRefs.current[post.id];
                      if (input && input.value.trim()) {
                        handleAddComment(post.id, input.value);
                      }
                    }}
                  >
                    <Send size={18} />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CommunityCollaboration;