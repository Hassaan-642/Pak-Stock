import React, { useState, useEffect } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { MessageCircle, Plus, ArrowRight, Calendar, User, ImageIcon } from 'lucide-react';
import DashboardSidebar from './DashboardSidebar';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import './CommunityPosts.css'; // Import the CSS file
import HomepageSidebar from './HomePageSidebar';

const CommunityPosts = () => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [picture, setPicture] = useState("");
  const [user, setUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  // Check authentication state
  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthChecked(true);
    });

    return () => unsubscribe();
  }, []);
  
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  
  useEffect(() => {
    // Only fetch posts if user is authenticated
    if (user) {
      const fetchPostImage = async (postId) => {
        try {
          const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/user-post/image?post_id=${postId}`);
          if (!response.ok) {
            throw new Error('Failed to fetch post image');
          }
          const data = await response.json();
          setPicture(data);
          return data.image_url;
        } catch (err) {
          console.error(`Error fetching image for post ${postId}:`, err);
          return null;
        }
      };

      const fetchPosts = async () => {
        try {
          const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  '/api/user-posts');
          
          if (!response.ok) {
            throw new Error('Failed to fetch posts');
          }
          
          const data = await response.json();
          
          const postsWithImages = await Promise.all(
            data.map(async (post) => {
              if (post.picture_path) {
                const imageUrl = await fetchPostImage(post.post_id);
                return { ...post, imageUrl };
              }
              return post;
            })
          );
          
          setPosts(postsWithImages);
          setLoading(false);
        } catch (err) {
          setError(err.message);
          setLoading(false);
        }
      };

      fetchPosts();
    }
  }, [user]);

  // Show loading while checking authentication
  if (!authChecked) {
    return (
      <div className="loading-spinner">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  // Redirect if not authenticated
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Additional checks for email verification if needed
  if (user && !user.emailVerified) {
    return <Navigate to="/email-verification" replace />;
  }

  if (loading) {
    return (
     <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-lg shadow-md" role="alert">
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="community-container">
      <HomepageSidebar onToggle={toggleSidebar} isOpen={isSidebarOpen} />
      <div className={`community-layout ${isSidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
        <div className="community-content">
          <div className="community-main">
            <div className="community-header">
              <h2 className="community-title">
                Community Posts
              </h2>
              <button 
                onClick={() => navigate('/create-post')}
                className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out"
              >
                <Plus className="mr-2 -ml-1 h-5 w-5" aria-hidden="true" />
                Create Post
              </button>
            </div>
            
            {posts.length === 0 ? (
              <div className="empty-state">
                <MessageCircle className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No posts</h3>
                <p className="mt-1 text-sm text-gray-500">Get started by creating a new post.</p>
              </div>
            ) : (
              <div className="community-post-grid">
                {posts.map(post => (
                  <div key={post.post_id} className="community-post-card">
                    <div className="community-post-content">
                      <div className="community-post-header">
                        <div className="flex-shrink-0">
                          <img className="h-10 w-10 rounded-full" src={`https://ui-avatars.com/api/?name=${post.username}&background=random`} alt={post.username} />
                        </div>
                        <div className="community-post-user-info">
                          <h3 className="community-post-title">{post.title}</h3>
                          <div className="community-post-meta">
                            <User className="mr-1 h-4 w-4" aria-hidden="true" />
                            <span>{post.username}</span>
                            <span className="mx-1">&middot;</span>
                            <Calendar className="mr-1 h-4 w-4" aria-hidden="true" />
                            <span>{formatDateTime(post.date_created)}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="community-post-body">
                        {post.content}
                      </div>
                      
                      <div className="community-post-footer">
                       
                        <button 
                          onClick={() => navigate(`/posts/${post.post_id}`)}
                          className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-blue-600 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out"
                        >
                          View Detail & Discussion
                          <ArrowRight className="ml-2 -mr-1 h-4 w-4" aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                    
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommunityPosts;