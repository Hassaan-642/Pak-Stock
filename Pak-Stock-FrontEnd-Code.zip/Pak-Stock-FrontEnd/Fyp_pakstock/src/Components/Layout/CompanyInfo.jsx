import React from 'react';
import { Building2, User, Users, Briefcase, MapPin, Globe, Calendar, DollarSign, PieChart, Percent } from 'lucide-react';
import useFetchArticles from '../../Services/api/useFetchArticles'; // Import custom hook for API calls

const CompanyInfoNews = ({ companyData, industry, days }) => {
  console.log('CompanyInfoNews industry:', industry);
  const articles = useFetchArticles(industry, days); // Fetch articles using custom hook
  console.log('Articles:', articles);

  const InfoItem = ({ icon, title, value }) => (
    <div className="flex items-start mb-4">
      <div className="flex-shrink-0">
        {icon}
      </div>
      <div className="ml-3 md:ml-4">
        <h4 className="text-xs sm:text-sm font-bold text-gray-700">{title}</h4>
        <p className="text-xs sm:text-sm text-gray-600">{value}</p>
      </div>
    </div>
  );

  const handleArticleClick = (link) => {
    if (link) {
      window.open(link, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="flex flex-col lg:flex-row w-full mx-auto px-4 sm:px-6 mb-4 mt-5">
      {/* Company Info Section */}
      <div className="w-full lg:w-3/4 lg:pr-4 mb-6 lg:mb-0">
        <h2 className="text-xl sm:text-2xl font-bold mb-4 text-center">{companyData.stock_name}</h2>
        <div className="bg-white shadow-md rounded-md p-3 sm:p-4 mb-4">
          <h3 className="text-base sm:text-lg font-bold text-gray-800 mb-2 pb-2 border-b-2 border-blue-500">Company Overview</h3>
          <p className="text-xs sm:text-sm text-gray-600">{companyData.company_information}</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white shadow-md rounded-md p-3 sm:p-4">
            <h3 className="text-base sm:text-lg font-bold text-gray-800 mb-2 pb-2 border-b-2 border-blue-500">Leadership</h3>
            <InfoItem icon={<User className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="CEO" value={companyData.ceo_name} />
            <InfoItem icon={<Users className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Chairperson" value={companyData.chairperson_name} />
            <InfoItem icon={<Briefcase className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Company Secretary" value={companyData.company_secretary_name} />
          </div>
          <div className="bg-white shadow-md rounded-md p-3 sm:p-4">
            <h3 className="text-base sm:text-lg font-bold text-gray-800 mb-2 pb-2 border-b-2 border-blue-500">Contact Information</h3>
            <InfoItem icon={<MapPin className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Address" value={companyData.address} />
            <InfoItem icon={<Globe className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Website" value={companyData.website} />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div className="bg-white shadow-md rounded-md p-3 sm:p-4 pb-1">
            <h3 className="text-base sm:text-lg font-bold text-gray-800 border-b-2 border-blue-500">Financial Information</h3>
            <InfoItem icon={<Calendar className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Fiscal Year End" value={companyData.fiscal_year_end} />
            <InfoItem icon={<DollarSign className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Market Cap" value={`$${companyData.market_cap.toLocaleString()}`} />
            <InfoItem icon={<PieChart className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Shares" value={companyData.shares.toLocaleString()} />
            <InfoItem icon={<Percent className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Free Float" value={`${companyData.free_float_percentage}% (${companyData.free_float_of_shares.toLocaleString()} shares)`} />
          </div>
          <div className="bg-white shadow-md rounded-md p-3 sm:p-4">
            <h3 className="text-base sm:text-lg font-bold text-gray-800 mb-2 pb-2 border-b-2 border-blue-500">Additional Information</h3>
            <InfoItem icon={<Building2 className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Registrar" value={companyData.registrar} />
            <InfoItem icon={<Users className="text-blue-500 w-4 h-4 sm:w-5 sm:h-5" />} title="Auditor" value={companyData.auditor} />
          </div>
        </div>
      </div>

      {/* NewsCards Section */}
      <div className="w-full lg:w-1/4 lg:pl-4 pt-0 lg:pt-5">
        <div className="bg-white shadow-md rounded-md overflow-hidden">
          <h2 className="text-xl sm:text-2xl font-bold p-4 pb-2 border-b-2 border-blue-500">Stock In the News</h2>
          <div className="max-h-96 lg:max-h-[calc(8*7rem)] overflow-y-auto">
            {articles && articles.length > 0 ? (
              articles.map((article, index) => (
                <div 
                  key={article.article_id} 
                  className={`flex items-center p-3 sm:p-4 h-20 sm:h-24 ${index !== 0 ? 'border-t border-gray-200' : ''} cursor-pointer hover:bg-gray-100`}
                  onClick={() => handleArticleClick(article.link)}
                >
                  <img src={article.image} alt={article.title} className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded-md mr-3 sm:mr-4" />
                  <div className="flex-grow overflow-hidden">
                    <h3 className="font-bold text-xs sm:text-sm mb-1 truncate">{article.title}</h3>
                    <p className="text-xs text-gray-500 truncate">{article.description}</p>
                    <p className="text-xs text-gray-400">{article.publish_date}</p>
                  </div>
                  <div className="ml-2 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 sm:h-6 sm:w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              ))
            ) : (
              <p className="p-4 text-xs sm:text-sm text-gray-600">No articles available</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompanyInfoNews;