import React, { useState, useRef } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Image from "@tiptap/extension-image";
import TextStyle from "@tiptap/extension-text-style";
import Color from "@tiptap/extension-color";
import { Extension } from "@tiptap/core";
import axios from "axios";
import { getAuth } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import { Loader, Image as ImageIcon } from "lucide-react";

// Font Size Extension
const FontSize = Extension.create({
  name: "fontSize",
  addOptions() {
    return {
      types: ["textStyle"],
      sizes: [
        "8px",
        "10px",
        "12px",
        "14px",
        "16px",
        "18px",
        "20px",
        "24px",
        "30px",
        "36px",
        "48px",
        "60px",
        "72px",
        "96px",
      ],
    };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          fontSize: {
            default: null,
            parseHTML: (element) => element.style.fontSize || null,
            renderHTML: (attributes) => {
              if (!attributes.fontSize) return {};
              return { style: `font-size: ${attributes.fontSize}` };
            },
          },
        },
      },
    ];
  },
});

// Font Family Extension
const FontFamily = Extension.create({
  name: "fontFamily",
  addOptions() {
    return { types: ["textStyle"] };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          fontFamily: {
            default: null,
            parseHTML: (element) => element.style.fontFamily || null,
            renderHTML: (attributes) => {
              if (!attributes.fontFamily) return {};
              return { style: `font-family: ${attributes.fontFamily}` };
            },
          },
        },
      },
    ];
  },
});

const BlogCreationComponent = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [file, setFile] = useState(null); // Featured image
  const [isEmbeddingImage, setIsEmbeddingImage] = useState(false);
  const inlineImageInputRef = useRef(null);

  const fontSizes = [
    "12px",
    "14px",
    "16px",
    "18px",
    "20px",
    "24px",
    "30px",
    "36px",
  ];
  const fontFamilies = [
    "Arial",
    "Times New Roman",
    "Courier New",
    "Georgia",
    "Verdana",
    "Helvetica",
  ];
  const colors = [
    "#000000",
    "#FF0000",
    "#00FF00",
    "#0000FF",
    "#FFA500",
    "#800080",
    "#008080",
  ];

  const editor = useEditor({
    extensions: [StarterKit, Image, TextStyle, Color, FontSize, FontFamily],
    content: "<p>Start writing your blog post...</p>",
  });

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleInlineImageChange = (event) => {
    const file = event.target.files[0];
    if (file && editor) {
      const reader = new FileReader();
      reader.onload = (e) => {
        // Insert image at current cursor position
        editor
          .chain()
          .focus()
          .setImage({ src: e.target.result, alt: file.name })
          .run();
      };
      reader.readAsDataURL(file);
    }
    // Reset the input value to allow selecting the same file again
    event.target.value = "";
    setIsEmbeddingImage(false);
  };

  const uploadImage = async (articleId) => {
    if (!file) return;

    const formData = new FormData();
    formData.append("article_id", articleId);
    formData.append("image", file);

    try {
      const response = await fetch(
        process.env.REACT_APP_BACKEND_BASE_URL +  `/api/user-articles/images?article_id=${articleId}`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || "Failed to upload image");
      }

      return await response.json();
    } catch (error) {
      console.error("Error uploading image:", error);
      throw error;
    }
  };

  // Function to extract base64 images and save them along with the article
  const processInlineImages = async (articleId, htmlContent) => {
    // Regular expression to find base64 image data
    const regex = /src="data:image\/(jpeg|png|gif|webp);base64,([^"]+)"/g;
    let match;
    let processedHtml = htmlContent;
    let imgCount = 0;

    const uploadPromises = [];

    while ((match = regex.exec(htmlContent)) !== null) {
      imgCount++;
      const mimeType = match[1];
      const base64Data = match[2];

      // Convert base64 to blob
      const byteCharacters = atob(base64Data);
      const byteArrays = [];

      for (let offset = 0; offset < byteCharacters.length; offset += 512) {
        const slice = byteCharacters.slice(offset, offset + 512);

        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
          byteNumbers[i] = slice.charCodeAt(i);
        }

        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
      }

      const blob = new Blob(byteArrays, { type: `image/${mimeType}` });
      const imageFile = new File(
        [blob],
        `inline-image-${imgCount}.${mimeType}`,
        { type: `image/${mimeType}` }
      );

      // Prepare for upload
      const formData = new FormData();
      formData.append("article_id", articleId);
      formData.append("image", imageFile);
      formData.append("is_inline", "true");

      // Upload the image and collect the promise
      const uploadPromise = fetch(
        process.env.REACT_APP_BACKEND_BASE_URL +  `/api/user-articles/images?article_id=${articleId}`,
        {
          method: "POST",
          body: formData,
        }
      )
        .then((response) => {
          if (!response.ok) {
            throw new Error("Failed to upload inline image");
          }
          return response.json();
        })
        .then((data) => {
          // Replace base64 image data with URL to saved image
          const imageUrl = data.image_url;
          const originalImgTag = `src="data:image/${mimeType};base64,${base64Data}"`;
          const newImgTag = `src="${imageUrl}"`;
          processedHtml = processedHtml.replace(originalImgTag, newImgTag);
          return data;
        });

      uploadPromises.push(uploadPromise);
    }

    // Wait for all image uploads to complete
    if (uploadPromises.length > 0) {
      await Promise.all(uploadPromises);
    }

    return processedHtml;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    const auth = getAuth();
    const currentUser = auth.currentUser;

    if (!currentUser) {
      setError("No user logged in");
      setIsSubmitting(false);
      return;
    }

    const token = await currentUser.getIdToken();

    const content = editor.getHTML();

    try {
      // First, create the article
      const articleResponse = await axios.post(
        process.env.REACT_APP_BACKEND_BASE_URL +  "/api/user-articles",
        {
          user_id: currentUser.uid,
          username: currentUser.displayName || currentUser.email,
          title: title,
          content: content.replace(/"/g, '\\"'),
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
          }
        }
      );

      console.log("original article respones", articleResponse.data);

      // Get the article_id from the response
      const articleId = articleResponse.data.article.article_id;

      // If there's a featured image selected, upload it
      if (file) {
        await uploadImage(articleId);
      }

      // Process and upload any inline images
      const processedContent = await processInlineImages(articleId, content);

      // Update the article with processed content (with image URLs instead of base64)
      if (processedContent !== content) {
        await axios.put(
          process.env.REACT_APP_BACKEND_BASE_URL +  `/api/user-articles?article_id=${articleId}`,
          {
            content: processedContent.replace(/"/g, '\\"'),
            user_id: currentUser.uid,
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json"
            }
          }
        )
        .then((response) => {
          console.log("PUT response: ", response.data);
        });
      }

      // Reset form and redirect
      setTitle("");
      editor.commands.setContent("<p>Start writing your blog post...</p>");
      navigate("/NewsItem");
    } catch (error) {
      console.error("Error:", error);
      setError("Failed to submit blog post. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden">
      <div className="px-6 py-4 bg-gradient-to-r from-blue-500 to-blue-500">
        <h1 className="text-3xl font-bold text-white">Create New Blog Post</h1>
      </div>
      <div className="p-6">
        {error && (
          <div className="text-red-500 mb-4 p-3 bg-red-100 rounded">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <input
              type="text"
              placeholder="Enter blog title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div className="space-y-4">
            <div className="flex flex-wrap gap-2 p-3 bg-gray-100 rounded-md">
              <div className="flex gap-2 border-r pr-2">
                <button
                  type="button"
                  onClick={() => editor?.chain().focus().toggleBold().run()}
                  className={`p-2 rounded hover:bg-gray-200 transition ${
                    editor?.isActive("bold") ? "bg-gray-200" : ""
                  }`}
                >
                  <strong>B</strong>
                </button>

                <button
                  type="button"
                  onClick={() => editor?.chain().focus().toggleItalic().run()}
                  className={`p-2 rounded hover:bg-gray-200 transition ${
                    editor?.isActive("italic") ? "bg-gray-200" : ""
                  }`}
                >
                  <em>I</em>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    editor?.chain().focus().setHorizontalRule().run()
                  }
                  className="p-2 rounded hover:bg-gray-200 transition"
                >
                  ―
                </button>

                {/* Add inline image button */}
                <button
                  type="button"
                  onClick={() => {
                    setIsEmbeddingImage(true);
                    // Trigger file input click
                    setTimeout(() => {
                      if (inlineImageInputRef.current) {
                        inlineImageInputRef.current.click();
                      }
                    }, 0);
                  }}
                  className={`p-2 rounded hover:bg-gray-200 transition flex items-center ${
                    isEmbeddingImage ? "bg-gray-200" : ""
                  }`}
                >
                  <ImageIcon size={16} />
                  <span className="ml-1">Image</span>
                </button>
                {/* Hidden file input for inline images */}
                <input
                  type="file"
                  ref={inlineImageInputRef}
                  onChange={handleInlineImageChange}
                  accept="image/*"
                  className="hidden"
                />
              </div>

              <div className="flex items-center gap-2 border-r pr-2">
                <span className="text-sm">Size:</span>
                <select
                  onChange={(e) => {
                    editor
                      ?.chain()
                      .focus()
                      .setMark("textStyle", { fontSize: e.target.value })
                      .run();
                  }}
                  className="p-1 border rounded"
                >
                  {fontSizes.map((size) => (
                    <option key={size} value={size}>
                      {size}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2 border-r pr-2">
                <span className="text-sm">Font:</span>
                <select
                  onChange={(e) => {
                    editor
                      ?.chain()
                      .focus()
                      .setMark("textStyle", { fontFamily: e.target.value })
                      .run();
                  }}
                  className="p-1 border rounded"
                >
                  {fontFamilies.map((font) => (
                    <option key={font} value={font}>
                      {font}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-sm">Color:</span>
                <input
                  type="color"
                  onChange={(e) => {
                    editor?.chain().focus().setColor(e.target.value).run();
                  }}
                  className="w-8 h-8 p-0 cursor-pointer rounded"
                />
                <select
                  onChange={(e) => {
                    editor?.chain().focus().setColor(e.target.value).run();
                  }}
                  className="p-1 border rounded"
                >
                  {colors.map((color) => (
                    <option
                      key={color}
                      value={color}
                      style={{ backgroundColor: color }}
                    >
                      {color}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              Featured Image (Main cover image for your article)
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
            />
          </div>

          {editor && (
            <div>
              <div className="text-sm text-gray-500 mb-2">
                <p>
                  To insert an image in your content, click the Image button in
                  the toolbar and select an image file.
                </p>
              </div>
              <EditorContent
                editor={editor}
                className="min-h-[400px] border rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-50 flex items-center justify-center"
          >
            {isSubmitting ? (
              <>
                <Loader className="animate-spin -ml-1 mr-3 h-5 w-5" />
                Submitting...
              </>
            ) : (
              "Submit Blog Post"
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default BlogCreationComponent;
