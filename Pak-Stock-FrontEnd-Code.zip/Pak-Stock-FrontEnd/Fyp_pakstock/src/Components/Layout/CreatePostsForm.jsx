import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAuth, onAuthStateChanged } from "firebase/auth";
import axios from 'axios';
import { PenTool, X, Loader, Bold, Italic, Underline, List } from 'lucide-react';

const CreatePostForm = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [userId, setUserId] = useState('');
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [file, setFile] = useState(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(
      auth, 
      (user) => {
        if (user) {
          setUserId(user.uid);
          setUsername(user.displayName || user.email?.split('@')[0] || 'Anonymous');
          setIsLoading(false);
        } else {
          navigate('/login');
        }
      },
      (authError) => {
        console.error('Authentication error:', authError);
        setIsLoading(false);
      }
    );

    return () => unsubscribe();
  }, [navigate]);

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUpload = async (postId) => {
    if (!file) return null;

    const formData = new FormData();
    formData.append('image', file);

    const auth = getAuth();
    const user = auth.currentUser;
  
    if (!user) {
      console.error("User not logged in");
      return;
    }
  
    const token = await user.getIdToken();

    try {
      const response = await axios.post(
        process.env.REACT_APP_BACKEND_BASE_URL +  `/api/user-post/image?post_id=${postId}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      if (response.status !== 200) {
        throw new Error(response.data.detail || 'Failed to upload image');
      }

      return response.data;
    } catch (error) {
      console.error('Error uploading image:', error);
      throw new Error('Failed to upload image: ' + (error.response?.data?.detail || error.message));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!title.trim() || !content.trim()) {
      alert('Title and content are required.');
      return;
    }

    const auth = getAuth();
    const user = auth.currentUser;
  
    if (!user) {
      console.error("User not logged in");
      return;
    }
  
    const token = await user.getIdToken();

    try {
      setIsLoading(true);

      // Get current time in proper format
      const now = new Date();
      const currentTime = now.toISOString();

      // First, create the post
      const payload = {
        title: title.trim(),
        content: content, // Not trimming content to preserve whitespace
        user_id: userId,
        username: username,
        picture_path: 'N/A',
      };

      const articleResponse = await axios.post(
        process.env.REACT_APP_BACKEND_BASE_URL +  '/api/user-post', 
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        },
      );

      const postId = articleResponse.data.post.post_id;

      // Then, if there's a file, upload it
      if (file) {
        try {
          await handleUpload(postId);
        } catch (uploadError) {
          // If image upload fails, we'll show the error but still navigate away
          // since the post was created successfully
          console.error('Image upload failed:', uploadError);
          alert('Post created but image upload failed: ' + uploadError.message);
        }
      }

      navigate('/community');
    } catch (error) {
      console.error('Full error object:', error);
      
      if (error.response) {
        console.error('Response error details:', error.response.data);
        
        if (error.response.data.detail) {
          const errorMessages = Array.isArray(error.response.data.detail)
            ? error.response.data.detail.map(detail => `${detail.loc[1]}: ${detail.msg}`).join(', ')
            : error.response.data.detail;
          
          alert(`Validation Error: ${errorMessages}`);
        } else {
          alert(error.response.data.message || 'Failed to create post. Please try again.');
        }
      } else if (error.request) {
        alert('No response received from the server. Please check your internet connection.');
      } else {
        alert('An unexpected error occurred. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Text formatting functions
  const applyFormatting = (tag) => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    
    let formattedText = '';
    
    switch(tag) {
      case 'bold':
        formattedText = `**${selectedText}**`;
        break;
      case 'italic':
        formattedText = `*${selectedText}*`;
        break;
      case 'underline':
        formattedText = `__${selectedText}__`;
        break;
      case 'list':
        // Create a list with each line prefixed with "- "
        formattedText = selectedText
          .split('\n')
          .map(line => line.length > 0 ? `- ${line}` : line)
          .join('\n');
        break;
      default:
        formattedText = selectedText;
    }
    
    const newContent = content.substring(0, start) + formattedText + content.substring(end);
    setContent(newContent);
    
    // Set focus back to textarea and place cursor at the right position
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + formattedText.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  // Function to render the formatted content preview
  const renderFormattedContent = (text) => {
    let formattedText = text;
    
    // Replace markdown-style formatting with HTML tags
    formattedText = formattedText
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/__(.*?)__/g, '<u>$1</u>')
      .replace(/- (.*?)(\n|$)/g, '<li>$1</li>');
    
    return { __html: formattedText };
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen bg-gray-50">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto bg-white shadow-xl rounded-lg overflow-hidden">
        <div className="px-6 py-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-extrabold text-gray-900 flex items-center">
              <PenTool className="mr-2 h-8 w-8 text-blue-500" />
              Create a New Post
            </h2>
            <button
              onClick={() => navigate(-1)}
              className="text-gray-400 hover:text-gray-500 transition duration-150 ease-in-out"
              aria-label="Close"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Title
              </label>
              <input
                id="title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter an engaging title for your post"
                required
                maxLength={200}
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
                Content
              </label>
              
              {/* Formatting toolbar */}
              <div className="flex space-x-2 mb-2 border border-gray-300 rounded-md p-2 bg-gray-50">
                <button 
                  type="button" 
                  onClick={() => applyFormatting('bold')}
                  className="p-1 rounded hover:bg-gray-200" 
                  title="Bold"
                >
                  <Bold className="h-5 w-5" />
                </button>
                <button 
                  type="button" 
                  onClick={() => applyFormatting('italic')}
                  className="p-1 rounded hover:bg-gray-200" 
                  title="Italic"
                >
                  <Italic className="h-5 w-5" />
                </button>
                <button 
                  type="button" 
                  onClick={() => applyFormatting('underline')}
                  className="p-1 rounded hover:bg-gray-200" 
                  title="Underline"
                >
                  <Underline className="h-5 w-5" />
                </button>
                <button 
                  type="button" 
                  onClick={() => applyFormatting('list')}
                  className="p-1 rounded hover:bg-gray-200" 
                  title="List"
                >
                  <List className="h-5 w-5" />
                </button>
              </div>
              
              <textarea
                id="content"
                ref={textareaRef}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Share your thoughts, ideas, or experiences..."
                required
                rows={8}
                maxLength={1000}
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm whitespace-pre-wrap"
                spellCheck="true"
                style={{ whiteSpace: 'pre-wrap' }}
              />
              <p className="mt-2 text-sm text-gray-500">
                {1000 - content.length} characters remaining
              </p>

              {/* Preview section */}
              {content && (
                <div className="mt-4">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Preview:</h3>
                  <div 
                    className="prose max-w-none p-3 border border-gray-200 rounded-md bg-gray-50"
                    dangerouslySetInnerHTML={renderFormattedContent(content)}
                  ></div>
                </div>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Image
              </label>
              <input 
                type="file" 
                accept="image/*" 
                onChange={handleFileChange}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
              />
            </div>
            
            <div className="flex items-center justify-end space-x-4 pt-4">
              <button
                type="button"
                onClick={() => navigate(-1)}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                disabled={isLoading}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" />
                    Publishing...
                  </>
                ) : (
                  'Publish Post'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreatePostForm;