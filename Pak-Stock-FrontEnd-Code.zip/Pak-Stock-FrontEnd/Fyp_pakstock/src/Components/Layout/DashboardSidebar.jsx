import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { LayoutDashboard,Home, TrendingUp, Newspaper, Building2, Settings, Activity, Users, UserPlus, X , Menu , Info, MessageCircle } from 'lucide-react';
import styles from '../../assets/DashboardSidebar.module.css';
import image from '../../assets/PakStockLogo.jpg';

const DashboardSidebar = ({ onComponentChange, isOpen, onToggle }) => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    // Close menu after clicking on mobile
    if (window.innerWidth < 768) {
      onToggle();
    }
  };
 
  const handleNavigation = (path, component = null) => {
    if (path) {
      navigate(path);
    } else if (component) {
      onComponentChange(component);
    }
    // Close menu after navigation on mobile
    if (window.innerWidth < 768) {
      onToggle();
    }
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <div className={styles.mobileMenuButton} onClick={onToggle}>
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </div>

      {/* Overlay for mobile */}
      {isOpen && <div className={styles.overlay} onClick={onToggle}></div>}

      {/* Sidebar */}
      <div className={`${styles.sidebar} ${isOpen ? styles.open : ''}`}>
        <div className={styles.logo}>
          <img
            src={image}
            alt="Pak Stock Logo"
            className={styles.logoImage}
          />
        </div>

        <ul className={styles.menu}>
          <li
            className={`${styles.menuItem} ${location.pathname === '/Dashboard' ? styles.active : ''}`}
            onClick={() => handleNavigation('/dashboard')}
          >
            <LayoutDashboard className={styles.icon} />
            <span>Dashboard</span>
          </li>
          <li
            className={`${styles.menuItem} ${location.pathname === '/MainHome' ? styles.active : ''}`}
            onClick={() => handleNavigation('/MainHome')}
          >
            <Home className={styles.icon} />
            <span>Home</span>
          </li>
          <li
            className={`${styles.menuItem} ${location.pathname === '/NewsItem' ? styles.active : ''}`}
            onClick={() => handleNavigation('/NewsItem')}
          >
            <Newspaper className={styles.icon} />
            <span>User Articles</span>
          </li>
          <li className={styles.menuItem} onClick={() => scrollToSection('predicted')}>
            <TrendingUp className={styles.icon} />
            <span>Predictions</span>
          </li>
          <li className={styles.menuItem} onClick={() => scrollToSection('sentiment')}>
            <Activity className={styles.icon} />
            <span>Sentiment Analysis</span>
          </li>
          <li className={styles.menuItem} onClick={() => scrollToSection('company-info')}>
            <Building2 className={styles.icon} />
            <span>Company Info</span>
          </li>
          <li
            className={`${styles.menuItem} ${location.pathname === '/Community' ? styles.active : ''}`}
            onClick={() => handleNavigation('/community')}
          >
            <Users className={styles.icon} />
            <span>User Post</span>
          </li>
         
          <li
            className={`${styles.menuItem} ${location.pathname === '/AboutUs' ? styles.active : ''}`}
            onClick={() => handleNavigation('/AboutUs')}
          >
            <Info className={styles.icon} />
            <span>About Us</span>
          </li>
          <li
            className={`${styles.menuItem} ${location.pathname === '/Broker-Verification' ? styles.active : ''}`}
            onClick={() => handleNavigation('/Broker-Verification')}
          >
            <UserPlus className={styles.icon} />
            <span>Create Account as a Broker </span>
          </li>
          <li
            className={`${styles.menuItem} ${location.pathname === '/Chatrooms' ? styles.active : ''}`}
            onClick={() => handleNavigation('/Chatrooms')}
          >
            <MessageCircle className={styles.icon} />
            <span>Talk to a Broker! </span>
          </li>
        </ul>
      </div>
    </>
  );
};

export default DashboardSidebar;