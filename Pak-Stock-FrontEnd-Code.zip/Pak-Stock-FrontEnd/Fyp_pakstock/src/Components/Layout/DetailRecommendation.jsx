import React from 'react';
import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';
import { LineChart, ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,  ReferenceLine, Label } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/Card";
import { getAuth } from "firebase/auth";

const TechnicalIndicator = ({ title, value, signal, description }) => (
  <div className="mb-4">
    <h3 className="font-semibold">{title}</h3>
    <p>{signal}</p>
    {description && <p>{description}</p>}
  </div>
);

const TrendIndicator = ({ trend, type }) => {
  const getColor = () => {
    switch (trend?.toLowerCase()) {
      case 'bearish': return 'bg-red-500';
      case 'bullish': return 'bg-green-500';
      default: return 'bg-yellow-500';
    }
  };

  return (
    <div className="flex items-center gap-2 mb-2">
      <div className={`w-3 h-3 rounded-full ${getColor()}`} />
      <span>{type}: {trend}</span>
    </div>
  );
};

const DetailedAnalysisPage = () => {
  const { stock_symbol } = useParams();
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [sentimentData, setSentimentData] = useState(null);
  const [sentimentLoading, setSentimentLoading] = useState(true);

  useEffect(() => {
    if (!stock_symbol) return;

    const fetchRecommendationData = async () => {
      const auth = getAuth();
    
      const user = auth.currentUser;
    
      if (!user) {
        console.error("User not logged in");
        return;
      }

      try {
        const response = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/recommendation?stock_symbol=${stock_symbol}`);
        setData(response.data);
        setIsLoading(false);
      } catch (err) {
        setError('Failed to fetch data');
        setIsLoading(false);
      }
    };

    fetchRecommendationData();
  }, [stock_symbol]);

  useEffect(() => {
    if (!stock_symbol) return;

    const fetchSentimentData = async () => {
      setSentimentLoading(true);
      try {
        const response = await fetch(
          process.env.REACT_APP_BACKEND_BASE_URL +  `/api/sentiment?industry=${stock_symbol}&days=30`
        );
        const jsonData = await response.json();
        setSentimentData(jsonData);
      } catch (error) {
        setSentimentData({
          positive: 0,
          neutral: 5,
          negative: 1,
          positive_percentage: 0.0,
          neutral_percentage: 83.33,
          negative_percentage: 16.67,
        });
      } finally {
        setSentimentLoading(false);
      }
    };

    fetchSentimentData();
  }, [stock_symbol]);


  if (isLoading) return <div className="p-6">Loading...</div>;
  if (error) return <div className="p-6 text-red-500">{error}</div>;
  
  if (!data.length) return <div className="p-6">No data asdfsa\vailable</div>;

  const latestData = data[data.length - 1];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Technical Analysis: {stock_symbol}</h1>

      <div className="mb-6">
      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <div className="flex  md:flex-nowrap">
            {/* Trend Analysis Section */}
            <div className="p-4 border-r border-border w-full md:w-auto">
              <CardTitle className="text-sm font-medium mb-3">Trend Analysis</CardTitle>
              <div className="flex gap-4">
                <TrendIndicator type="Long Term" trend={latestData.long_term_trend} />
                <TrendIndicator type="Short Term" trend={latestData.short_term_trend} />
              </div>
            </div>

            {/* Key Signals Section */}
            <div className="p-4 w-full">
              <CardTitle className="text-sm font-medium mb-3">Key Signals</CardTitle>
              <div className="flex flex-wrap gap-3">
                <TechnicalIndicator title="SMA" signal={latestData.sma_signal} />
                <TechnicalIndicator title="EMA" signal={latestData.ema_signal} />
                <TechnicalIndicator title="RSI" signal={latestData.rsi_14_signal} />
                <TechnicalIndicator title="Bollinger Band" signal={latestData.bollinger_band_signal} />
                <TechnicalIndicator title="MACD" signal={latestData.macd_signal} />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Simple Moving Average (SMA)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="close" name="Price" stroke="#0A0A0A" dot={false} />
                <Line type="monotone" dataKey="sma_50" name="SMA 50" stroke="#8B0000" dot={false} />
                <Line type="monotone" dataKey="sma_200" name="SMA 200" stroke="#006400" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Exponential Moving Averages (EMA)</CardTitle>
          </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="ema_10" name="EMA 10" stroke="#33FF57" dot={false} />
              <Line type="monotone" dataKey="ema_20" name="EMA 20" stroke="#3380FF" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>


        <Card>
          <CardHeader>
            <CardTitle>Bollinger Band</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="close" name="Price" stroke="#0A0A0A" dot={false}/>
                <Line type="monotone" dataKey="bollinger_upper_band" name="Upper Band" stroke="#8B0000" dot={false}/>
                <Line type="monotone" dataKey="bollinger_middle_band" name="Middle Band" stroke="#006400" dot={false} />
                <Line type="monotone" dataKey="bollinger_lower_band" name="Lower Band" stroke="#00008B" dot={false}/>
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
  <CardHeader>
    <CardTitle>Relative Strength Index (RSI)</CardTitle>
  </CardHeader>
  <CardContent>
    <ResponsiveContainer width="100%" height={400}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="time" />
        <YAxis domain={[0, 100]} />
        <Tooltip />
        <Legend />
        
        {/* RSI Line */}
        <Line type="monotone" dataKey="rsi_14" name="RSI 14" stroke="#00008B" dot={false} />

        {/* Overbought Zone Line */}
        <ReferenceLine y={70} stroke="red" strokeDasharray="6 6">
          <Label value="⚠ Overbought Zone" position="insideBottomRight" fill="red" style={{ fontWeight: "bold" }}/>
        </ReferenceLine>

        {/* Oversold Zone Line */}
        <ReferenceLine y={30} stroke="orange" strokeDasharray="6 6">
          <Label value="⚠ Oversold Zone" position="insideTopRight" fill="orange" style={{ fontWeight: "bold" }}/>
        </ReferenceLine>
      </LineChart>
    </ResponsiveContainer>
  </CardContent>
</Card>


        <Card>
  <CardHeader>
    <CardTitle>Moving Average Convergence Divergence (MACD)</CardTitle>
  </CardHeader>
  <CardContent>
    <ResponsiveContainer width="100%" height={400}>
      <ComposedChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="time" />
        <YAxis />
        <Tooltip />
        <Legend />
        
        {/* MACD & Signal Lines */}
        <Line type="monotone" dataKey="macd_line" name="MACD Line" stroke="#8B0000" dot={false} />
        <Line type="monotone" dataKey="signal_line" name="Signal Line" stroke="#006400" dot={false} />

        {/* Histogram Bars */}
        <Bar dataKey="macd_histogram" name="Histogram" fill="#00008B" opacity={2} />
      </ComposedChart>
    </ResponsiveContainer>
  </CardContent>
</Card>


      </div>
    </div>
  );
};

export default DetailedAnalysisPage;