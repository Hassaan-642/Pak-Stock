import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { ThumbsUp, Minus, ThumbsDown } from 'lucide-react';
import { dividendService } from '../../Services/api/dividendService';

const StockAnalysisCard = ({ stockSymbol, industry, days }) => {
  // Dividend States
  const [dividendData, setDividendData] = useState({
    dividend_amount: "Does not pay Dividend",
    dividend_yield: null,
    last_ex_date: null,
    last_pay_date: null
  });
  const [dividendLoading, setDividendLoading] = useState(true);
  const [dividendError, setDividendError] = useState(null);

  // Sentiment States
  const [sentimentData, setSentimentData] = useState({
    positive: 0,
    neutral: 0,
    negative: 0,
    positive_percentage: 0,
    neutral_percentage: 0,
    negative_percentage: 0,
  });
  const [sentimentLoading, setSentimentLoading] = useState(true);

  // Fetch Dividend Data
  useEffect(() => {
    const fetchDividendData = async () => {
      try {
        setDividendLoading(true);
        const data = await dividendService.fetchDividendData(stockSymbol);
        setDividendData(data);
      } catch (err) {
        setDividendError(err.message);
      } finally {
        setDividendLoading(false);
      }
    };

    if (stockSymbol) {
      fetchDividendData();
    }
  }, [stockSymbol]);

  // Fetch Sentiment Data
  useEffect(() => {
    const fetchSentimentData = async () => {
      setSentimentLoading(true);
      try {
        const response = await fetch(
          process.env.REACT_APP_BACKEND_BASE_URL +  `/api/sentiment?industry=${industry}&days=${days}`
        );
        const jsonData = await response.json();
        setSentimentData(jsonData);
      } catch (error) {
        setSentimentData({
          positive: 0,
          neutral: 5,
          negative: 1,
          positive_percentage: 0.0,
          neutral_percentage: 83.33333333333334,
          negative_percentage: 16.666666666666664,
        });
      } finally {
        setSentimentLoading(false);
      }
    };

    fetchSentimentData();
  }, [industry, days]);

  const formatPercentage = (value) => {
    return typeof value === 'number' ? value.toFixed(1) : '0.0';
  };

  const sentimentConfig = [
    {
      type: 'Positive',
      count: sentimentData.positive || 0,
      percentage: formatPercentage(sentimentData.positive_percentage),
      icon: ThumbsUp,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      borderColor: 'border-green-200'
    },
    {
      type: 'Neutral',
      count: sentimentData.neutral || 0,
      percentage: formatPercentage(sentimentData.neutral_percentage),
      icon: Minus,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
      borderColor: 'border-blue-200'
    },
    {
      type: 'Negative',
      count: sentimentData.negative || 0,
      percentage: formatPercentage(sentimentData.negative_percentage),
      icon: ThumbsDown,
      color: 'text-red-600',
      bgColor: 'bg-red-100',
      borderColor: 'border-red-200'
    },
  ];

  return (
    <Card className="w-full max-w-full mx-auto lg:ml-0 md:ml-0 sm:ml-0">
      <CardHeader>
        <CardTitle className="text-lg sm:text-xl font-semibold">Stock Analysis: {stockSymbol}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {/* Dividend Section */}
          <div className="space-y-3 md:space-y-4">
            <h3 className="text-base md:text-lg font-medium">Dividend Information</h3>
            {dividendLoading ? (
              <div className="animate-pulse space-y-3">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            ) : dividendError ? (
              <div className="text-red-500 text-sm md:text-base">Error: {dividendError}</div>
            ) : dividendService.isDescriptiveResponse(dividendData.dividend_amount) ? (
              <div className="p-3 md:p-4 bg-gray-50 rounded-lg text-sm md:text-base">{dividendData.dividend_amount}</div>
            ) : (
              <div className="grid gap-2 md:gap-3">
                {Object.entries(dividendData).map(([key, value]) => (
                  <div key={key} className="flex justify-between items-center p-2 md:p-3 bg-gray-50 rounded-lg text-sm md:text-base">
                    <span className="font-medium">{key.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}:</span>
                    <span>{value || "N/A"}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sentiment Section */}
          <div className="space-y-3 md:space-y-4">
            <h3 className="text-base md:text-lg font-medium flex flex-wrap items-center">
              <span>Sentiment Analysis for {industry}</span>
              <span className="text-xs md:text-sm text-gray-500 ml-1 md:ml-2">Last {days} days</span>
            </h3>
            {sentimentLoading ? (
              <div className="animate-pulse space-y-3">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            ) : (
              <div className="grid gap-2 md:gap-4">
                {sentimentConfig.map((item) => (
                  <div
                    key={item.type}
                    className={`flex items-center justify-between p-2 md:p-4 rounded-lg border ${item.borderColor} ${item.bgColor}`}
                  >
                    <div className="flex items-center space-x-2 md:space-x-3">
                      <item.icon className={`w-4 h-4 md:w-5 md:h-5 ${item.color}`} />
                      <span className="font-medium text-sm md:text-base">{item.type}</span>
                    </div>
                    <div className="flex items-center space-x-2 md:space-x-4 text-sm md:text-base">
                      <span className="font-bold">{item.count}</span>
                      <span className={`${item.color} font-medium`}>{item.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StockAnalysisCard;