import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged, updateProfile, updateEmail, updatePassword, signOut, signInWithEmailAndPassword } from 'firebase/auth';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { doc, updateDoc, getDoc, setDoc, getFirestore } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Label } from '../ui/Label';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const ProfileEditPage = () => {
  const auth = getAuth();
  const storage = getStorage();
  const firestore = getFirestore();
  const navigate = useNavigate();

  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [photoURL, setPhotoURL] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [uploadingImage, setUploadingImage] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [previewURL, setPreviewURL] = useState('');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        setDisplayName(currentUser.displayName || '');
        setEmail(currentUser.email || '');
        setPhotoURL(currentUser.photoURL || '');
        
        // Get the user document from Firestore
        try {
          const userDocRef = doc(firestore, 'users', currentUser.uid);
          const userDoc = await getDoc(userDocRef);
          
          if (userDoc.exists()) {
            const userData = userDoc.data();
            if (userData.displayName) setDisplayName(userData.displayName);
            if (userData.email) setEmail(userData.email);
            if (userData.photoURL) setPhotoURL(userData.photoURL);
          }
        } catch (error) {
          console.error("Error fetching user document:", error);
        }
      } else {
        // Redirect to login page
        navigate('/login');
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [auth, firestore, navigate]);

  // Handle file selection for profile image
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImageFile(file);
      
      // Create a preview URL
      const objectUrl = URL.createObjectURL(file);
      setPreviewURL(objectUrl);
      
      // Clean up the object URL when component unmounts or when preview changes
      return () => URL.revokeObjectURL(objectUrl);
    }
  };

  // Upload the selected image
  const uploadProfileImage = async () => {
    if (!imageFile || !user) return null;
    
    setUploadingImage(true);
    try {
      // Create a unique filename
      const fileName = `profile_${Date.now()}_${imageFile.name}`;
      const imageRef = ref(storage, `profileImages/${user.uid}/${fileName}`);
      
      // Upload the file
      const snapshot = await uploadBytes(imageRef, imageFile);
      
      // Get the download URL
      const downloadURL = await getDownloadURL(snapshot.ref);
      return downloadURL;
    } catch (error) {
      console.error('Upload error:', error);
      toast.error(`Failed to upload image: ${error.message}`);
      return null;
    } finally {
      setUploadingImage(false);
    }
  };

  // Handle profile update
  const handleUpdateProfile = async () => {
    if (!user) {
      toast.error('User not authenticated');
      return;
    }

    setSavingProfile(true);
    
    try {
      // Validate password inputs
      if (newPassword && newPassword !== confirmPassword) {
        toast.error('Passwords do not match');
        setSavingProfile(false);
        return;
      }
      
      // Upload profile image if a new one is selected
      let newPhotoURL = photoURL;
      if (imageFile) {
        const uploadedURL = await uploadProfileImage();
        if (uploadedURL) {
          newPhotoURL = uploadedURL;
        } else {
          // If upload failed but we're still here, inform the user but continue with other updates
          toast.warning('Profile image upload failed, continuing with other updates');
        }
      }

      // Sequence auth operations properly
      let needsReauthentication = (email !== user.email && email) || newPassword;
      
      // Re-authenticate user if needed (once, before any secured operations)
      if (needsReauthentication) {
        if (!currentPassword) {
          toast.error('Current password is required to change email or password');
          setSavingProfile(false);
          return;
        }
        
        try {
          await signInWithEmailAndPassword(auth, user.email, currentPassword);
        } catch (error) {
          toast.error(`Authentication failed: ${error.message}`);
          setSavingProfile(false);
          return;
        }
      }
      
      // Now perform the secured operations in sequence
      
      // 1. Update email if changed
      if (email !== user.email && email) {
        try {
          await updateEmail(auth.currentUser, email);
        } catch (error) {
          toast.error(`Failed to update email: ${error.message}`);
          // Continue with other updates
        }
      }

      // 2. Update password if provided
      if (newPassword) {
        try {
          await updatePassword(auth.currentUser, newPassword);
        } catch (error) {
          toast.error(`Failed to update password: ${error.message}`);
          // Continue with other updates
        }
      }
      
      // 3. Update profile (displayName and photoURL)
      try {
        await updateProfile(auth.currentUser, { 
          displayName,
          photoURL: newPhotoURL 
        });
      } catch (error) {
        toast.error(`Failed to update profile: ${error.message}`);
        // Continue with Firestore update
      }

      // 4. Update Firestore user document
      try {
        const userDocRef = doc(firestore, 'users', user.uid);
        const userDoc = await getDoc(userDocRef);
        
        const userData = {
          displayName,
          email,
          photoURL: newPhotoURL,
          updatedAt: new Date().toISOString()
        };
        
        if (userDoc.exists()) {
          await updateDoc(userDocRef, userData);
        } else {
          await setDoc(userDocRef, {
            ...userData,
            uid: user.uid,
            createdAt: new Date().toISOString()
          });
        }
      } catch (error) {
        toast.error(`Failed to update user document: ${error.message}`);
        setSavingProfile(false);
        return;
      }

      // Show success message
      toast.success('Profile updated successfully');
      
      // Clear sensitive data
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setImageFile(null);
      setPreviewURL('');
      
      // Redirect to dashboard after short delay
      setTimeout(() => {
        navigate('/dashboard');
      }, 1500);
      
    } catch (error) {
      toast.error(`Failed to update profile: ${error.message}`);
      console.error('Update error:', error);
    } finally {
      setSavingProfile(false);
    }
  };

  // Loading state
  if (isLoading) {
    return <div className="flex justify-center items-center h-40">
      <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2  border-blue-500"></div>
    </div>;
  }

  // No user
  if (!user) {
    return <div>Please log in to edit your profile</div>;
  }

  return (
    <Card className="w-full max-w-md mx-auto mt-8">
      <CardHeader>
        <CardTitle>Edit Profile</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Profile Image Upload */}
          <div className="flex flex-col items-center">
            {/* Show preview if available, otherwise show current photo or placeholder */}
            {previewURL ? (
              <div className="mb-4 relative">
                <img 
                  src={previewURL}
                  alt="Profile Preview" 
                  className="w-24 h-24 rounded-full object-cover border-2 border-blue-500"
                />
                <span className="absolute -top-2 -right-2 text-xs bg-blue-500 text-white px-2 py-1 rounded-full">
                  Preview
                </span>
              </div>
            ) : photoURL ? (
              <div className="mb-4">
                <img 
                  src={photoURL}
                  alt="Profile" 
                  className="w-24 h-24 rounded-full object-cover"
                />
              </div>
            ) : (
              <div className="mb-4 w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center">
                <span className="text-gray-500 text-2xl">
                  {displayName ? displayName[0].toUpperCase() : '?'}
                </span>
              </div>
            )}
            
            <Label className="cursor-pointer bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded transition-colors">
              {uploadingImage ? 'Uploading...' : 'Change Profile Picture'}
              <Input 
                type="file" 
                accept="image/*" 
                onChange={handleFileSelect} 
                className="hidden"
                disabled={uploadingImage || savingProfile}
              />
            </Label>
          </div>

          {/* Display Name */}
          <div>
            <Label htmlFor="displayName">Display Name</Label>
            <Input 
              id="displayName"
              value={displayName} 
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Enter display name"
              className="mt-2"
              disabled={savingProfile}
            />
          </div>

          {/* Email */}
          <div>
            <Label htmlFor="email">Email</Label>
            <Input 
              id="email"
              type="email"
              value={email} 
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter email"
              className="mt-2"
              disabled={savingProfile}
            />
          </div>

          {/* Current Password - Required for email/password changes */}
          <div>
            <Label htmlFor="currentPassword">
              Current Password {((email !== user.email) || newPassword) && 
                <span className="text-red-500">*</span>}
            </Label>
            <Input 
              id="currentPassword"
              type="password"
              value={currentPassword} 
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder={((email !== user.email) || newPassword) ? 
                "Required for email/password changes" : "Enter current password"}
              className="mt-2"
              disabled={savingProfile}
            />
          </div>

          {/* New Password */}
          <div>
            <Label htmlFor="newPassword">New Password (optional)</Label>
            <Input 
              id="newPassword"
              type="password"
              value={newPassword} 
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Enter new password"
              className="mt-2"
              disabled={savingProfile}
            />
          </div>

          {/* Confirm Password */}
          <div>
            <Label htmlFor="confirmPassword">Confirm New Password</Label>
            <Input 
              id="confirmPassword"
              type="password"
              value={confirmPassword} 
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm new password"
              className="mt-2"
              disabled={savingProfile}
            />
          </div>

          {/* Update Button */}
          <Button 
            onClick={handleUpdateProfile} 
            className="w-full mt-6"
            disabled={savingProfile || uploadingImage}
          >
            {savingProfile ? (
              <span className="flex items-center justify-center">
                <span className="mr-2 w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                {uploadingImage ? 'Uploading Image...' : 'Updating Profile...'}
              </span>
            ) : 'Update Profile'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProfileEditPage;