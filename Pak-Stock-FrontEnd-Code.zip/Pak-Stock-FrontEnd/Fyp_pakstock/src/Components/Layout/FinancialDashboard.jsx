import React from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, TrendingDown, LineChart, BarChart, AlertTriangle, Gauge } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/Card";
import { Button } from "../ui/Button";
import { ResponsiveContainer, LineChart as RechartLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import useFetchFinancialData from '../../Services/api/useFetchFinancialData';
import { useAuth } from '../../Services/ProtectedRoute';
import { getAuth } from 'firebase/auth';

const FinancialDashboard = ({ stock_symbol }) => {
  const navigate = useNavigate();
  const { data, isLoading } = useFetchFinancialData(stock_symbol);

  const handleDetailClick = () => {
    navigate(`/DetailRecommendationPage/${stock_symbol}`);
  };

  // Dynamic Icon Selection based on trend values
  const getTrendIcon = (trend) => {
    return trend?.toLowerCase() === 'bullish' ? TrendingUp : TrendingDown;
  };

  const StatCard = ({ title, value, icon: Icon }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-5 w-5 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );

  if (isLoading || !data) {
    return (
      <div className="p-4 w-full max-w-full lg:ml-0 md:ml-0 sm:ml-0">
        <h1 className="text-2xl md:text-3xl font-bold mb-4 md:mb-6">Recommendation</h1>
        <p>Loading...</p>
      </div>
    );
  }

  // Get the latest indicator data
  const latestIndicator = data.indicators[data.indicators.length - 1] || {};

  return (
    <div className="p-2 md:p-4 w-full max-w-full  lg:ml-0 md:ml-0 sm:ml-0 rounded-lg shadow-md">
      <h1 className="text-2xl md:text-3xl font-bold mb-4 md:mb-6">Recommendation</h1>
      <div className="flex justify-between items-center mb-4 md:mb-6">
        <Button onClick={handleDetailClick} className="text-sm md:text-base w-full md:w-auto">
          Detail Recommendation Report
        </Button>
      </div>
      
      {/* Responsive StatCards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-2 md:gap-3 mb-4 md:mb-6">
        <StatCard 
          title="Long-Term Trend" 
          value={latestIndicator.long_term_trend || 'N/A'} 
          icon={getTrendIcon(latestIndicator.long_term_trend)}
        />
        <StatCard 
          title="Short-Term Trend" 
          value={latestIndicator.short_term_trend || 'N/A'} 
          icon={getTrendIcon(latestIndicator.short_term_trend)}
        />
        <StatCard 
          title="SMA Signal" 
          value={latestIndicator.sma_signal || 'N/A'} 
          icon={LineChart} 
        />
        <StatCard 
          title="EMA Signal" 
          value={latestIndicator.ema_signal || 'N/A'} 
          icon={BarChart} 
        />
        <StatCard 
          title="RSI Signal" 
          value={latestIndicator.rsi_14_signal || 'N/A'} 
          icon={Gauge} 
        />
      </div>

      {/* Responsive Intraday Trading Chart */}
      <div className="mb-4 md:mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base md:text-lg">Intraday Trading</CardTitle>
          </CardHeader>
          <CardContent className="p-1 md:p-4">
            <div className="w-full h-48 md:h-64 lg:h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartLineChart data={data.dailyTradingData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="TIME" 
                    tickFormatter={(timeStr) => {
                      const time = new Date(timeStr);
                      return window.innerWidth < 768 ? 
                        time.getHours() + ':' + time.getMinutes().toString().padStart(2, '0') : 
                        time.toLocaleTimeString();
                    }}
                    tick={{ fontSize: 10 }}
                  />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip 
                    labelFormatter={(timeStr) => new Date(timeStr).toLocaleString()}
                    formatter={(value) => value?.toFixed(2) || 'N/A'}
                    contentStyle={{ fontSize: '12px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '10px', marginTop: '10px' }} />
                  <Line 
                    type="monotone" 
                    dataKey="CLOSE" 
                    name="Current Price"
                    stroke="#8884d8" 
                    dot={false}
                    strokeWidth={1.5} 
                  />
                </RechartLineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FinancialDashboard;