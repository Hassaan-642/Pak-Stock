import React from 'react';
import { Link } from 'react-router-dom';
import { Github, Linkedin, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-6 sm:py-8 md:py-12 text-xs sm:text-sm">
      <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row justify-between gap-8">
        <div className="w-full md:w-auto md:max-w-md mb-6 md:mb-0">
          {/* <img src="/api/placeholder/150/50" alt="Pakstock Logo" className="w-28 sm:w-36 mb-3 sm:mb-4" /> */}
          <p className="mb-4 sm:mb-6">
            PakStock is a stock analytics platform powered by AI. It helps investors pick the best stocks, optimize their portfolios, and make smart data-driven investment decisions.
          </p>
          {/* Social Icons - Uncomment if needed
          <div className="flex space-x-3 sm:space-x-4">
            <Twitter size={16} className="sm:w-5 sm:h-5 cursor-pointer hover:text-white" />
            <Linkedin size={16} className="sm:w-5 sm:h-5 cursor-pointer hover:text-white" />
            <Github size={16} className="sm:w-5 sm:h-5 cursor-pointer hover:text-white" />
          </div> */}
        </div>
       
        <div className="grid grid-cols-2 gap-4 sm:gap-6 md:gap-8 md:grid-cols-3">
          <div>
            <h4 className="font-semibold mb-2 sm:mb-3 md:mb-4 text-sm sm:text-base">Company</h4>
            <ul className="space-y-1 sm:space-y-2">
              <li>
                <Link to='/AboutUs' className="hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to='/AboutUs' className="hover:text-white transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
         
          <div>
            <h4 className="font-semibold mb-2 sm:mb-3 md:mb-4 text-sm sm:text-base">Resources</h4>
            <ul className="space-y-1 sm:space-y-2">
              <li>
                <Link to='/HelpCenter' className="hover:text-white transition-colors">
                  Help Center
                </Link>
              </li>
              <li>
                <Link to='/TermsOfUse' className="hover:text-white transition-colors">
                  Terms of Use
                </Link>
              </li>
              <li>
                <Link to='/PrivacyPolicy' className="hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to='/Disclaimer' className="hover:text-white transition-colors">
                  Disclaimer
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Empty third column to maintain grid structure on larger screens */}
          <div className="hidden md:block"></div>
        </div>
      </div>
     
      <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 mt-6 sm:mt-8 pt-4 sm:pt-6 md:pt-8 border-t border-gray-700">
        <p className="text-center text-xs sm:text-sm md:text-xs max-w-3xl mx-auto">
          © 2024 PakStock Technologies. All rights reserved. PakStock AI calculates probabilities based on past market behavior. It does not predict actual results. Use of our site constitutes acceptance of our Terms of Use, Privacy Policy, and Disclaimer.
        </p>
      </div>
    </footer>
  );
};

export default Footer;