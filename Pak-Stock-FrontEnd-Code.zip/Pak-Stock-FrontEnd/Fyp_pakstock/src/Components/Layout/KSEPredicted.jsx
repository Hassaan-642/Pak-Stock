import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';

const KSEPredictedChart = () => {
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // API method to fetch KSE predicted prices
  const fetchKSEPredictedPrices = async () => {
    try {
      const response = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL +  '/api/ksepredicted');
     
      // Transform data for better chart rendering
      const transformedData = response.data.map(item => ({
        ...item,
        date: new Date(item.date).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric'
        })
      }));
      setChartData(transformedData);
      setLoading(false);
    } catch (err) {
      setError('Failed to fetch KSE predicted prices');
      setLoading(false);
      console.error('Error fetching data:', err);
    }
  };
  
  useEffect(() => {
    fetchKSEPredictedPrices();
  }, []);
  
  if (loading) {
    return (
      <Card className="w-full mb-6">
        <CardContent className="h-64 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
        </CardContent>
      </Card>
    );
  }
  
  if (error) {
    return (
      <Card className="w-full mb-6">
        <CardContent className="p-4">
          <div className="bg-red-50 border border-red-200 rounded-lg text-red-700 p-4">
            {error}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="w-full mb-6">
      <CardHeader className="p-4">
        <CardTitle className="text-xl sm:text-2xl font-bold text-gray-900">
          KSE-100 Index Predicted Price
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="h-64 sm:h-80 md:h-96 lg:h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fill: '#6B7280', fontSize: '0.75rem' }}
                tickLine={{ stroke: '#6B7280' }}
              />
              <YAxis
                domain={['dataMin - 1000', 'dataMax + 1000']}
                tickFormatter={(value) => value.toLocaleString()}
                tick={{ fill: '#6B7280', fontSize: '0.75rem' }}
                tickLine={{ stroke: '#6B7280' }}
                width={50}
              />
              <Tooltip
                formatter={(value) => [value.toLocaleString(), 'Close Price']}
                contentStyle={{ fontSize: '0.875rem' }}
              />
              <Legend wrapperStyle={{ fontSize: '0.875rem' }} />
              <Line
                dot={false}
                type="monotone"
                dataKey="close"
                stroke="#8884d8"
                strokeWidth={2}
                activeDot={{ r: 6 }}
                name="Closing Price"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default KSEPredictedChart;