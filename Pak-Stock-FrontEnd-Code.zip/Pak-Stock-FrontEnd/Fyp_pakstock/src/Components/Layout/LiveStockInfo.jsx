// LiveStockInfo.js
import React from 'react';
import { Clock, DollarSign, BarChart2, Users, Percent } from 'lucide-react';
import styles from '../../assets/LiveStockInfo.module.css'; // Import the CSS module

const LiveStockInfo = ({ stockData }) => {
  const InfoItem = ({ icon, title, value, additionalInfo }) => (
    <div className={styles.infoItem}>
      <div className={styles.iconContainer}>{icon}</div>
      <div className={styles.infoContent}>
        <h4 className={styles.infoTitle}>{title}</h4>
        <p className={styles.infoValue}>{value}</p>
        {additionalInfo && <p className={styles.additionalInfo}>{additionalInfo}</p>}
      </div>
    </div>
  );

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2 className={styles.companyName}>{stockData.company}</h2>
        <div className={styles.liveIndicator}>
          <span className={styles.dot}></span>
          LIVE
        </div>
      </div>
      <div className={styles.mainInfo}>
        <h3 className={styles.closeQuote}>{stockData.close_quote}</h3>
        <p className={styles.time}>
          <Clock size={16} className={styles.timeIcon} />
          {new Date(stockData.time).toLocaleString()}
        </p>
      </div>
      <div className={styles.cardGrid}>
        <InfoItem 
          icon={<DollarSign size={24} color="#4CAF50" />}
          title="Market Cap"
          value={`Rs. ${stockData.market_cap}`}
        />
        <InfoItem 
          icon={<BarChart2 size={24} color="#2196F3" />}
          title="Shares"
          value={stockData.shares}
        />
        <InfoItem 
          icon={<Users size={24} color="#FF9800" />}
          title="Free Float Volume"
          value={stockData.free_float_volume}
        />
        <InfoItem 
          icon={<Percent size={24} color="#9C27B0" />}
          title="Free Float Percentage"
          value={stockData.free_float_percentage}
        />
      </div>
    </div>
  );
};

export default LiveStockInfo;
