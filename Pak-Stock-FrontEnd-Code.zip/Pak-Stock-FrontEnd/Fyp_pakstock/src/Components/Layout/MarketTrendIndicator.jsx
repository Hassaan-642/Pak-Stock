// src/Components/MarketTrendIndicator.js
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/Card";

const MarketTrendIndicator = ({trend }) => {
  const getArrowRotation = () => {
    switch (trend) {
      case 'Bearish': return -45;
      case 'Neutral': return 0;
      case 'Bullish': return 45;
      default: return 0;
    }
  };

  const getIndicatorColor = () => {
    switch (trend) {
      case 'Bearish': return 'rgb(239 68 68)';
      case 'Neutral': return 'rgb(234 179 8)';
      case 'Bullish': return 'rgb(34 197 94)';
      default: return 'rgb(234 179 8)';
    }
  };

  return (
    <Card className="">
      <CardHeader>
        <CardTitle>Market Trend Indicator</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center mt-4">
        <svg viewBox="0 0 200 100" className="w-full max-w-md">
          <path d="M10 90 A 90 90 0 0 1 190 90" fill="none" stroke="#e5e7eb" strokeWidth="20" />
          <path d="M10 90 A 90 90 0 0 1 190 90" fill="none" stroke={getIndicatorColor()} strokeWidth="20" strokeDasharray="180 180" 
                strokeDashoffset={trend.toLowerCase() === 'bearish' ? 120 : trend.toLowerCase() === 'neutral' ? 60 : 0} />
          <text x="15" y="20" className="text-sm font-semibold">Bearish</text>
          <text x="85" y="20" className="text-sm font-semibold">Neutral</text>
          <text x="160" y="20" className="text-sm font-semibold">Bullish</text>
          <g transform={`rotate(${getArrowRotation()}, 100, 90)`}>
            <path d="M100 10 L95 90 L100 85 L105 90 Z" fill="black" />
          </g>
        </svg>
      </CardContent>
    </Card>
  );
};

export default MarketTrendIndicator;
