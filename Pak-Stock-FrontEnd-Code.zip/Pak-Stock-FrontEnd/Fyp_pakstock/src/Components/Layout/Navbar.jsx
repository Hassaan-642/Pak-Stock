import React, { useState, useRef, useEffect } from 'react';
import { Search, User, Settings, LogOut, Bell, HelpCircle, Menu, X } from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { auth } from '../Firebase'; // Adjust the import path as needed
import { signOut } from 'firebase/auth';

const Navbar = ({ onStockSelect }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userProfile, setUserProfile] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchParams, setSearchParams] = useSearchParams();
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  
  const searchRef = useRef(null);
  const profileMenuRef = useRef(null);
  const mobileMenuRef = useRef(null);
  const navigate = useNavigate();

  const stockNames = [
    'ABL', 'AKBL', 'BAFL', 'BAHL', 'BIPL', 'BOP', 'FABL', 'HBL', 'HMB', 'MCB', 'MEBL', 'NBP', 'SCBPL', 'UBL',
    'ABOT', 'AGP', 'GLAXO', 'SEARL', 'AICL', 'EFUG', 'APL', 'ATRL', 'CNERGY', 'MARI', 'NRL', 'OGDC', 'POL',
    'PPL', 'PSO', 'SHEL', 'SNGP', 'SPWL', 'SML', 'SRVI', 'TGL', 'THALL', 'ARPL', 'EPCL', 'LCI', 'LOTCHEM',
    'BNWM', 'GADT', 'GATM', 'IBFL', 'ILP', 'NCL', 'NML', 'YOUW', 'BWCL', 'CHCC', 'DGKC', 'FCCL', 'LUCK',
    'MLCF', 'PIOC', 'COLG', 'FCEPL', 'NATF', 'NESTLE', 'POML', 'RMPL', 'UNITY', 'UPFL', 'FFBL', 'FFC',
    'FATIMA', 'EFERT', 'DAWH', 'ENGRO', 'DCR', 'JVDC', 'SYS', 'TRG', 'AVN', 'CEPB', 'PKGS', 'FHAM', 'HGFA',
    'PGLC', 'PSX', 'GHGL', 'HINOON', 'HCAR', 'INDU', 'MTL', 'HUBC', 'KAPCO', 'KEL', 'PKGP', 'INIL', 'ISL',
    'MUGHAL', 'PAEL', 'PSEL', 'PTC', 'PAKT', 'MUREB', 'PIBTL', 'SHFA'
  ];
  
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        setIsAuthenticated(true);
        setUserProfile({
          username: user.displayName || user.email.split('@')[0],
          email: user.email,
          photoURL: user.photoURL
        });
      } else {
        setIsAuthenticated(false);
        setUserProfile(null);
      }
    });

    return () => unsubscribe();
  }, []);
  
  useEffect(() => {
    const query = searchParams.get("query");
    if (query) {
      setSearchTerm(query);
      onStockSelect(query);  // Restore data when returning to the dashboard
    }
    else{
      setSearchTerm("HBL");
      setSearchParams({ query: "HBL" });
      onStockSelect("HBL");
    }
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setIsSearchFocused(false);
      }
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target)) {
        setIsProfileMenuOpen(false);
      }
      if (mobileMenuRef.current && !mobileMenuRef.current.contains(event.target)) {
        setIsMobileMenuOpen(false);
      }
    };

    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsMobileMenuOpen(false);
        setIsMobileSearchOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    window.addEventListener('resize', handleResize);
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const handleSearchFocus = () => {
    setIsSearchFocused(true);
    if (searchTerm === '') {
      setSearchResults(getRandomStocks(5));
    }
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    setSearchParams({ query: value });
    if (value) {
      setSearchResults(stockNames.filter(name => 
        name.toLowerCase().includes(value.toLowerCase())
      ));
    } else {
      setSearchResults(getRandomStocks(5));
    }
  };

  const handleResultClick = (name) => {
    setSearchTerm(name);
    setSearchParams({ query: name });
    setIsSearchFocused(false);
    setIsMobileSearchOpen(false);
    onStockSelect(name);
  };

  const handleSearchSubmit = () => {
    const stockName = searchTerm.trim();
    if (stockNames.includes(stockName)) {
      onStockSelect(stockName);
    } else {
      alert('Please select a valid stock from the list.');
    }
    setIsSearchFocused(false);
    setIsMobileSearchOpen(false);
  };

  const getRandomStocks = (count) => {
    return stockNames.sort(() => 0.5 - Math.random()).slice(0, count);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
    if (isMobileSearchOpen) setIsMobileSearchOpen(false);
  };

  const toggleMobileSearch = () => {
    setIsMobileSearchOpen(!isMobileSearchOpen);
    if (isMobileMenuOpen) setIsMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 right-0 left-0 md:left-[250px] z-10 bg-white shadow-sm">
      {/* Main Navbar */}
      <div className="flex items-center justify-between px-4 md:px-6 py-3">
        
        {/* Mobile Menu Toggle */}
        <div className="flex items-center md:hidden">
          <button 
            onClick={toggleMobileMenu} 
            className="text-gray-500 hover:text-gray-700 focus:outline-none"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Logo/Brand - visible on mobile when sidebar is hidden */}
        <div className="md:hidden font-bold text-lg text-blue-600">StockApp</div>

        {/* Desktop Search Section */}
        <div className="hidden md:flex items-center space-x-2 w-1/3" ref={searchRef}>
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="text-gray-400" size={20} />
            </div>
            <input
              type="text"
              placeholder="Search stocks..."
              value={searchTerm}
              onChange={handleSearchChange}
              onFocus={handleSearchFocus}
              className="pl-10 pr-3 py-2 w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {isSearchFocused && (
              <div className="absolute z-10 mt-1 w-full bg-white border rounded-lg shadow-lg">
                {searchResults.map((result, index) => (
                  <div
                    key={index}
                    className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                    onClick={() => handleResultClick(result)}
                  >
                    {result}
                  </div>
                ))}
              </div>
            )}
          </div>
          <button 
            onClick={handleSearchSubmit} 
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
          >
            Search
          </button>
        </div>

        {/* Mobile Search Button */}
        <div className="md:hidden">
          <button
            onClick={toggleMobileSearch}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            <Search size={20} />
          </button>
        </div>

        {/* Right Side Icons */}
        <div className="flex items-center space-x-2 md:space-x-4">
          {/* Login/Profile Section */}
          {isAuthenticated ? (
            <div className="relative" ref={profileMenuRef}>
              <button 
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="flex items-center space-x-2 hover:bg-gray-100 p-1 rounded-full transition-colors"
              >
                {userProfile?.photoURL ? (
                  <img 
                    src={userProfile.photoURL} 
                    alt="Profile" 
                    className="w-8 h-8 md:w-10 md:h-10 rounded-full" 
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
                    {userProfile?.username?.[0]?.toUpperCase()}
                  </div>
                )}
              </button>

              {isProfileMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white border rounded-lg shadow-lg overflow-hidden">
                  <div className="px-4 py-3 bg-gray-50 border-b">
                    <p className="text-sm font-medium text-gray-900">
                      {userProfile?.username}
                    </p>
                    <p className="text-xs text-gray-500 truncate">
                      {userProfile?.email}
                    </p>
                  </div>
                  <div className="py-1">
                    <Link 
                      to="/Userprofile" 
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      <User className="mr-3" size={16} />
                      Profile
                    </Link>
                    
                    <button 
                      onClick={handleLogout}
                      className="w-full text-left flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                    >
                      <LogOut className="mr-3" size={16} />
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <Link 
              to="/login" 
              className="bg-blue-500 text-white px-3 py-2 md:px-4 md:py-2 text-sm md:text-base rounded-lg hover:bg-blue-600 transition-colors flex items-center"
            >
              <User className="mr-1 md:mr-2" size={16} />
              <span className="hidden xs:inline">Login</span>
            </Link>
          )}
        </div>
      </div>

      {/* Mobile Search Bar */}
      {isMobileSearchOpen && (
        <div className="px-4 py-3 bg-white border-t border-gray-200" ref={searchRef}>
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="text-gray-400" size={20} />
            </div>
            <input
              type="text"
              placeholder="Search stocks..."
              value={searchTerm}
              onChange={handleSearchChange}
              onFocus={handleSearchFocus}
              className="pl-10 pr-3 py-2 w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              autoFocus
            />
            {isSearchFocused && (
              <div className="absolute z-10 mt-1 w-full bg-white border rounded-lg shadow-lg">
                {searchResults.map((result, index) => (
                  <div
                    key={index}
                    className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                    onClick={() => handleResultClick(result)}
                  >
                    {result}
                  </div>
                ))}
              </div>
            )}
          </div>
          <button 
            onClick={handleSearchSubmit}
            className="mt-2 w-full bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
          >
            Search
          </button>
        </div>
      )}

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div 
          className="md:hidden bg-white border-t border-gray-200 shadow-lg"
          ref={mobileMenuRef}
        >
          <div className="px-4 py-6 space-y-4">
            {isAuthenticated ? (
              <>
                <div className="flex items-center space-x-3 px-4 py-3 bg-gray-50 rounded-lg">
                  {userProfile?.photoURL ? (
                    <img 
                      src={userProfile.photoURL} 
                      alt="Profile" 
                      className="w-10 h-10 rounded-full" 
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white">
                      {userProfile?.username?.[0]?.toUpperCase()}
                    </div>
                  )}
                  <div>
                    <p className="font-medium">{userProfile?.username}</p>
                    <p className="text-sm text-gray-500 truncate">{userProfile?.email}</p>
                  </div>
                </div>
                
                <nav className="space-y-1">
                  <Link 
                    to="/Userprofile" 
                    className="flex items-center px-4 py-3 text-sm text-gray-700 hover:bg-gray-100 rounded-lg"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <User className="mr-3" size={18} />
                    Profile
                  </Link>
                  <Link 
                    to="/settings" 
                    className="flex items-center px-4 py-3 text-sm text-gray-700 hover:bg-gray-100 rounded-lg"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Settings className="mr-3" size={18} />
                    Settings
                  </Link>
                  <button 
                    onClick={() => {
                      handleLogout();
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full text-left flex items-center px-4 py-3 text-sm text-red-600 hover:bg-gray-100 rounded-lg"
                  >
                    <LogOut className="mr-3" size={18} />
                    Logout
                  </button>
                </nav>
              </>
            ) : (
              <div className="flex justify-center">
                <Link 
                  to="/login" 
                  className="w-full bg-blue-500 text-white px-4 py-3 rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <User className="mr-2" size={18} />
                  Login
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;