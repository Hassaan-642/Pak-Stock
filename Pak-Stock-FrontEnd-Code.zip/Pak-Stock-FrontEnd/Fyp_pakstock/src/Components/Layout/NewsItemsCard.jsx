import React, { useState, useEffect } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import NewsItem from './NewsItemsCard1 ';
import DashboardSidebar from './DashboardSidebar';
import { MessageCircle,Plus, ArrowRight, Calendar, User, ImageIcon } from 'lucide-react';
import './ArticlesGrid.css';
import HomepageSidebar from './HomePageSidebar';

const ArticlesGrid = () => {
  const navigate = useNavigate();
  const [articles, setArticles] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [user, setUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Toggle sidebar state
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  useEffect(() => {
    // Check authentication state
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthChecked(true);
    });

    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    // Only fetch articles if user is authenticated
    if (user) {
      const fetchArticlesAndImages = async () => {
        try {
          const articlesResponse = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  '/api/user-articles');
          if (!articlesResponse.ok) {
            throw new Error('Failed to fetch articles');
          }
          const articlesData = await articlesResponse.json();
         
          const articlesWithImages = await Promise.all(
            articlesData.map(async (article) => {
              try {
                const imageResponse = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/user-articles/images?article_id=${article.article_id}`);
                if (!imageResponse.ok) {
                  return { ...article, imageUrl: null };
                }
                const imageData = await imageResponse.json();
                return {
                  ...article,
                  imageUrl: imageData[0]?.image_url || null
                };
              } catch (err) {
                console.error(`Error fetching image for article ${article.article_id}:`, err);
                return { ...article, imageUrl: null };
              }
            })
          );
          setArticles(articlesWithImages);
        } catch (err) {
          setError(err.message);
        } finally {
          setIsLoading(false);
        }
      };

      fetchArticlesAndImages();
    }
  }, [user]);

  // Show loading state while checking authentication
  if (!authChecked) {
    return (
      <div className="articles-container">
        <div className="loading-container">
          <div className="loading-spinner"></div>
        </div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Check email verification
  if (user && !user.emailVerified) {
    return <Navigate to="/email-verification" replace />;
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="articles-container">
        <div className="error-container">
          <div className="error-message">
            Error: {error}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="articles-container">
      <HomepageSidebar onToggle={toggleSidebar} isOpen={isSidebarOpen} />
      <div className={`articles-layout ${isSidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
        <div className="articles-content">
          <div className={`articles-card`}>
            <div className="articles-header">
              <h2 className="articles-title">
                Blog Articles
              </h2>
              <button
                onClick={() => navigate('/ContentInput')}
                className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out"
              >
                <Plus className="mr-2 -ml-1 h-5 w-5" aria-hidden="true" />
                Create Your Blog
              </button>
            </div>
            <div className="articles-content-area">
              <div className="articles-grid">
                {articles.map(article => (
                  <NewsItem key={article.article_id} article={article} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticlesGrid;