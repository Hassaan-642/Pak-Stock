import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Calendar, Eye, ChevronRight, User } from 'lucide-react';

const NewsItem = ({ article }) => {
  const navigate = useNavigate();
  
  const { 
    article_id,
    title,
    content,
    username,
    date_created,
    view_count,
    imageUrl
  } = article;

  const handleReadMore = () => {
    navigate(`/ContentDisplay/${article_id}`);
  };

  return (
    <div className="w-full md:w-1/2 lg:w-1/3 xl:w-1/4 p-4">
      <Card className="h-full flex flex-col overflow-hidden transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1">
        <div className="relative">
          <div className="absolute left-0 top-0 z-10 m-2">
            <Badge variant="secondary" className="flex items-center space-x-1 bg-black bg-opacity-50 text-white">
              <Eye size={14} />
              <span>{view_count}</span>
            </Badge>
          </div>
          
          <img
            src={imageUrl || "/api/placeholder/400/200"}
            alt={title}
            className="w-full h-48 object-cover transition-transform duration-300 ease-in-out hover:scale-105"
            onError={(e) => {
              e.target.src = "/api/placeholder/400/200";
            }}
          />
        </div>
        <CardHeader className="p-4">
          <CardTitle className="text-xl font-bold line-clamp-2 hover:text-blue-600 transition-colors duration-200">
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 p-4">
          <p className="text-gray-600 mb-4 line-clamp-3">
            {content.replace(/<[^>]*>/g, '')}
          </p>
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <div className="w-full space-y-4">
            <div className="flex items-center justify-between text-sm text-gray-500">
              <div className="flex items-center space-x-2">
                <User size={14} />
                <span>{username}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar size={14} />
                <span>{new Date(date_created).toLocaleDateString()}</span>
              </div>
            </div>
            <Button
              variant="default"
              size="sm"
              onClick={handleReadMore}
              className="w-full group"
            >
              Read more
              <ChevronRight size={16} className="ml-2 transition-transform duration-200 group-hover:translate-x-1" />
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default NewsItem;