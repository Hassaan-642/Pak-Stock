import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card, CardHeader, CardContent } from '../../Components/ui/Card';
import { Button } from '../../Components/ui/Button';
import { Loader2, TrendingUp, CheckCircle2 } from 'lucide-react';
import useKmeansPredictedData from '../../Services/api/useKmeansPredictedData';
import useRandomforestPredictedData from '../../Services/api/useRandomforestPredictedData';
import axios from 'axios';

const Predicted = ({ stock_symbol }) => {
    const [selectedRange, setSelectedRange] = useState('W1');   
    const [accuracyData, setAccuracyData] = useState(null);
    const [accuracyDataRandomForest, setAccuracyDataRandomForest] = useState(null);
    const [accuracyLoading, setAccuracyLoading] = useState(true);
    const [accuracyLoadingRandomForest, setAccuracyLoadingRandomForest] = useState(true);

    // Use custom hooks for both charts
    const { chartData, isLoading, error } = useKmeansPredictedData(stock_symbol, selectedRange);
    const { chartData2, isLoading2, error2 } = useRandomforestPredictedData(stock_symbol, selectedRange);

    // Fetch accuracy data for K-Means
    useEffect(() => {
        const fetchAccuracyData = async () => {
            try {
                setAccuracyLoading(true);
                const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/stock-accuracy?stock_symbol=${stock_symbol}`);
                const data = await response.json();
                setAccuracyData(data);
            } catch (err) {
                setAccuracyData(null);
            } finally {
                setAccuracyLoading(false);
            }
        };

        fetchAccuracyData();
    }, [stock_symbol]);

    // Fetch accuracy data for Random Forest
    useEffect(() => {
        const fetchAccuracyDataRandomForest = async () => {
            try {
                setAccuracyLoadingRandomForest(true);
                const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/stock-accuracy-randomForest?stock_symbol=${stock_symbol}`);
                const data = await response.json();
                setAccuracyDataRandomForest(data);
            } catch (err) {
                setAccuracyDataRandomForest(null);
            } finally {
                setAccuracyLoadingRandomForest(false);
            }
        };

        fetchAccuracyDataRandomForest();
    }, [stock_symbol]);

    const ranges = [
        { label: 'D1', days: 1 },
        { label: 'W1', days: 7 },
        { label: 'M1', days: 30 },
        { label: 'M2', days: 60 },
        { label: 'M3', days: 90 },
    ];

    const renderChart = (stockSymbol, chartTitle, chartData, isLoading, error) => (
        <Card className="w-full h-auto lg:h-[500px] border border-gray-100">
            <CardHeader className="flex flex-col space-y-2 border-b border-gray-100 p-3 sm:p-4">
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                        <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 text-blue-500" />
                        <h2 className="text-sm sm:text-base md:text-lg font-semibold text-gray-800">{chartTitle}</h2>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="pt-2 sm:pt-4 p-2 sm:p-4">
                {isLoading ? (
                    <div className="flex justify-center items-center h-48 sm:h-64 md:h-80 lg:h-[400px]">
                        <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-blue-500" />
                    </div>
                ) : error ? (
                    <div className="flex justify-center items-center h-48 sm:h-64 md:h-80 lg:h-[400px] text-red-500 text-sm sm:text-base">
                        {error}
                    </div>
                ) : (
                    <div className="h-48 sm:h-64 md:h-80 lg:h-[400px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={chartData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                                <XAxis 
                                    dataKey="date" 
                                    tickFormatter={(tick) => {
                                        const date = new Date(tick);
                                        return window.innerWidth < 768 ? 
                                            `${date.getMonth()+1}/${date.getDate()}` : 
                                            date.toLocaleDateString();
                                    }}
                                    tick={{ fontSize: 10 }}
                                    interval="preserveStartEnd"
                                />
                                <YAxis 
                                    tick={{ fontSize: 10 }}
                                    tickFormatter={(value) => '$' + value.toFixed(0)}
                                    width={40}
                                />
                                <Tooltip 
                                    labelFormatter={(label) => new Date(label).toLocaleDateString()}
                                    formatter={(value) => ['$' + value.toFixed(2), 'Close']}
                                    contentStyle={{ 
                                        backgroundColor: 'white', 
                                        border: '1px solid #e0e0e0', 
                                        borderRadius: '8px',
                                        fontSize: '12px',
                                        padding: '8px'
                                    }}
                                />
                                <Line 
                                    type="monotone" 
                                    dot={false} 
                                    activeDot={{ r: 4, fill: '#8884d8', stroke: '#fff', strokeWidth: 2 }} 
                                    dataKey="close" 
                                    stroke="#8884d8" 
                                    strokeWidth={1.5}
                                />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                )}
            </CardContent>
        </Card>
    );

    const renderAccuracyTables = () => (
        <div className="flex flex-col md:flex-row md:space-x-4 space-y-4 md:space-y-0 items-stretch">
            {/* K-Means Accuracy Table */}
            <Card className="w-full md:w-1/2 border border-gray-100">
                <CardHeader className="flex flex-col space-y-2 border-b border-gray-100 p-3 sm:p-4">
                    <div className="flex items-center space-x-2">
                        <CheckCircle2 className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 text-green-500" />
                        <h2 className="text-sm sm:text-base md:text-lg font-semibold text-gray-800">
                            K-Means With Linear Regression
                            <br />
                            <span className="text-xs sm:text-sm text-gray-600 font-normal"></span>
                        </h2>
                    </div>
                </CardHeader>
                <CardContent className="pt-2 sm:pt-4 p-2 sm:p-4">
                    {accuracyLoading ? (
                        <div className="flex justify-center items-center h-32 sm:h-40 md:h-48">
                            <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-blue-500" />
                        </div>
                    ) : !accuracyData ? (
                        <div className="text-gray-500 text-center py-4 text-sm">
                            No K-Means accuracy data available
                        </div>
                    ) : (
                        <table className="w-full text-xs sm:text-sm">
                            <tbody>
                                <tr className="border-b">
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 font-medium text-gray-700">MAPE</td>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 text-orange-600">
                                        {accuracyData.mape_in_percentage != null 
                                            ? `${accuracyData.mape_in_percentage.toFixed(2)}%` 
                                            : 'N/A'}
                                    </td>
                                </tr>
                                <tr>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 font-medium text-gray-700">Accuracy</td>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 text-green-600 font-bold">
                                        {accuracyData.accuracy_in_percentage != null 
                                            ? `${accuracyData.accuracy_in_percentage.toFixed(2)}%` 
                                            : 'N/A'}
                                    </td>
                                </tr>
                                <tr>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 font-medium text-gray-700">Record Date</td>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 text-gray-600">
                                        {accuracyData.record_date 
                                            ? new Date(accuracyData.record_date).toLocaleDateString() 
                                            : 'N/A'}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    )}
                </CardContent>
            </Card>

            {/* Random Forest Accuracy Table */}
            <Card className="w-full md:w-1/2 border border-gray-100">
                <CardHeader className="flex flex-col space-y-2 border-b border-gray-100 p-3 sm:p-4">
                    <div className="flex items-center space-x-2">
                        <CheckCircle2 className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 text-green-500" />
                        <h2 className="text-sm sm:text-base md:text-lg font-semibold text-gray-800">
                            Random Forest Regressor
                            <br />
                            <span className="text-xs sm:text-sm text-gray-600 font-normal"></span>
                        </h2>
                    </div>
                </CardHeader>
                <CardContent className="pt-2 sm:pt-4 p-2 sm:p-4">
                    {accuracyLoadingRandomForest ? (
                        <div className="flex justify-center items-center h-32 sm:h-40 md:h-48">
                            <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-blue-500" />
                        </div>
                    ) : !accuracyDataRandomForest ? (
                        <div className="text-gray-500 text-center py-4 text-sm">
                            No Random Forest accuracy data available
                        </div>
                    ) : (
                        <table className="w-full text-xs sm:text-sm">
                            <tbody>
                                <tr className="border-b">
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 font-medium text-gray-700">MAPE</td>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 text-orange-600">
                                        {accuracyDataRandomForest.mape_in_percentage != null 
                                            ? `${accuracyDataRandomForest.mape_in_percentage.toFixed(2)}%` 
                                            : 'N/A'}
                                    </td>
                                </tr>
                                <tr>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 font-medium text-gray-700">Accuracy</td>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 text-green-600 font-bold">
                                        {accuracyDataRandomForest.accuracy_in_percentage != null 
                                            ? `${accuracyDataRandomForest.accuracy_in_percentage.toFixed(2)}%` 
                                            : 'N/A'}
                                    </td>
                                </tr>
                                <tr>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 font-medium text-gray-700">Record Date</td>
                                    <td className="py-1 sm:py-2 px-2 sm:px-4 text-gray-600">
                                        {accuracyDataRandomForest.record_date 
                                            ? new Date(accuracyDataRandomForest.record_date).toLocaleDateString() 
                                            : 'N/A'}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    )}
                </CardContent>
            </Card>
        </div>
    );

    return (
        <div className="w-full p-2 sm:p-4 md:ml-0 lg:ml-0">
            {/* Range selection buttons */}
            <div className="flex justify-center md:justify-end mb-4 overflow-x-auto">
                <div className="flex space-x-1 sm:space-x-2">
                    {ranges.map((range) => (
                        <Button
                            key={range.label}
                            variant={selectedRange === range.label ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setSelectedRange(range.label)}
                            className={`
                                px-2 sm:px-3 py-1 rounded-full text-xs transition-all duration-200 min-w-8
                                ${selectedRange === range.label 
                                    ? 'bg-blue-500 text-white hover:bg-blue-600' 
                                    : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-300'}
                            `}
                        >
                            {range.label}
                        </Button>
                    ))}
                </div>
            </div>

            <div className="flex flex-col lg:flex-row lg:space-x-4 space-y-4 lg:space-y-0">
                {/* First Chart */}
                <div className="w-full lg:w-1/2">
                    {renderChart(
                        stock_symbol, 
                        'K-Means With Linear Regression Prediction ', 
                        chartData, 
                        isLoading, 
                        error
                    )}
                </div>

                {/* Second Chart */}
                <div className="w-full lg:w-1/2 ">
                    {renderChart(
                        stock_symbol, 
                        'Random Forest Regressor Prediction', 
                        chartData2, 
                        isLoading2, 
                        error2
                    )}
                </div>
            </div>

            {/* Accuracy Tables */}
            <div className="mt-4 w-full">
                {renderAccuracyTables()}
            </div>
        </div>
    );
};

export default Predicted;