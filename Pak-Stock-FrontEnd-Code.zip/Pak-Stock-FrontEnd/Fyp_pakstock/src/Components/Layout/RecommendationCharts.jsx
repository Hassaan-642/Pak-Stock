// src/Components/RecommendationCharts.js
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/Card";

const   SMAChart = ({ indicators, detailedData }) => (
  <Card className="w-full mb-6">
    <CardHeader>
      <CardTitle>SMA (Simple Moving Average)</CardTitle>
    </CardHeader>
    <CardContent>
      <p>50-day SMA: {indicators.SMA_50_mean}</p>
      <p>200-day SMA: {indicators.SMA_200_mean}</p>
      <p>{indicators.SMA_50_vs_SMA_200}</p>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={detailedData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="TIME" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="CLOSE" stroke="#0A0A0A" dot={false} />
          <Line type="monotone" dataKey="SMA_50" stroke="#8B0000" dot={false} />
          <Line type="monotone" dataKey="SMA_200" stroke="#006400" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

const RSIChart = ({ indicators, detailedData }) => (
  <Card className="w-full mb-6">
    <CardHeader>
      <CardTitle>RSI (Relative Strength Index)</CardTitle>
    </CardHeader>
    <CardContent>
      <p>14-day RSI: {indicators.RSI_14_mean}</p>
      <p>{indicators.RSI_14_text}</p>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={detailedData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="TIME" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="RSI_14" stroke="#00008B" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

const MACDChart = ({ indicators, detailedData }) => (
  <Card className="w-full mb-6">
    <CardHeader>
      <CardTitle>MACD (Moving Average Convergence and Divergence)</CardTitle>
    </CardHeader>
    <CardContent>
      <p>MACD Line Mean: {indicators.MACD_Line_mean}</p>
      <p>Signal Line Mean: {indicators.Signal_Line_mean}</p>
      <p>MACD Histogram Mean: {indicators.MACD_Histogram_mean}</p>
      <p>{indicators.MACD_text}</p>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={detailedData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="TIME" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="MACD_Line" stroke="#8B0000" dot={false} />
          <Line type="monotone" dataKey="Signal_Line" stroke="#82ca9d" dot={false} />
          <Line type="monotone" dataKey="MACD_Histogram" stroke="#00008B" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

const BollingerBandsChart = ({ indicators, detailedData }) => (
  <Card className="w-full mb-6">
    <CardHeader>
      <CardTitle>Bollinger Bands</CardTitle>
    </CardHeader>
    <CardContent>
      <p>Bollinger Middle Band Mean: {indicators.Bollinger_Middle_Band_mean}</p>
      <p>Bollinger Upper Band Mean: {indicators.Bollinger_Upper_Band_mean}</p>
      <p>Bollinger Lower Band Mean: {indicators.Bollinger_Lower_Band_mean}</p>
      <p>{indicators.Bollinger_Bands_text}</p>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={detailedData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="TIME" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="CLOSE" stroke="#8B0000" dot={false} />
          <Line type="monotone" dataKey="Bollinger_Upper_Band" stroke="#0A0A0A" dot={false} />
          <Line type="monotone" dataKey="Bollinger_Middle_Band" stroke="#006400" dot={false} />
          <Line type="monotone" dataKey="Bollinger_Lower_Band" stroke="#00008B" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

export { SMAChart, RSIChart, MACDChart, BollingerBandsChart };
