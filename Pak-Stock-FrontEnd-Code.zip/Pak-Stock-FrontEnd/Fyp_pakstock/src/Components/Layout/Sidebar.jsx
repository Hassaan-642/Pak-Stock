import React from 'react';
import { Home, TrendingUp, BarChart2, PieChart, Settings } from 'lucide-react';

const Sidebar = () => {
  return (
    <div style={styles.sidebar}>
      <div style={styles.logo}>Stock Exchange</div>
      <ul style={styles.menu}>
        <li style={styles.menuItem}>
          <Home style={styles.icon} />
          <span>Dashboard</span>
        </li>
        <li style={styles.menuItem}>
          <TrendingUp style={styles.icon} />
          <span>Market</span>
        </li>
        <li style={styles.menuItem}>
          <BarChart2 style={styles.icon} />
          <span>Stocks</span>
        </li>
        <li style={styles.menuItem}>
          <PieChart style={styles.icon} />
          <span>Portfolio</span>
        </li>
        <li style={styles.menuItem}>
          <Settings style={styles.icon} />
          <span>Settings</span>
        </li>
      </ul>
    </div>
  );
};

const styles = {
  sidebar: {
    width: '250px',
    height: '100vh',
    backgroundColor: '#343a40',
    color: 'white',
    padding: '20px',
    position: 'fixed'
  },
  logo: {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '30px',
    textAlign: 'center',
  },
  menu: {
    listStyleType: 'none',
    padding: 0,
  },
  menuItem: {
    display: 'flex',
    alignItems: 'center',
    padding: '10px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    ':hover': {
      backgroundColor: '#495057',
    },
  },
  icon: {
    marginRight: '10px',
  },
};

export default Sidebar;