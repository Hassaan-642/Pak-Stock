import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card, CardHeader, CardContent } from '../ui/Card';
import { Clock, DollarSign, BarChart2, Users, Percent, ArrowUp, ArrowDown } from 'lucide-react';
import VolumeChart from './VolumeChart';

const LiveStockInfo = ({ stockData }) => {
  const [imageSrc, setImageSrc] = useState('');

  useEffect(() => {
    if (stockData?.image) {
      setImageSrc(`data:image/png;base64,${stockData.image}`);
    }
  }, [stockData]);

  const InfoItem = ({ icon, title, value }) => (
    <Card className="p-2 sm:p-4 flex items-center space-x-2 sm:space-x-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="text-primary text-[30px] sm:text-[50px]">{icon}</div>
      <div>
        <h4 className="font-semibold text-gray-600 text-xs sm:text-sm">{title}</h4>
        <p className="text-xs sm:text-sm font-bold text-gray-800">{value}</p>
      </div>
    </Card>
  );

  const StockChangeIndicator = ({ changePercentage, changeDirection }) => {
    const isUp = changeDirection === 'up';
    const color = isUp ? 'text-green-500' : 'text-red-500';
   
    return (
      <div className={`flex items-center ${color}`}>
        {isUp ? (
          <ArrowUp className="w-4 h-4 sm:w-5 sm:h-6 mr-1" />
        ) : (
          <ArrowDown className="w-4 h-4 sm:w-5 sm:h-6 mr-1" />
        )}
        <h1 className="text-sm sm:text-lg">{changePercentage}</h1>
      </div>
    );
  };
 
  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-2 sm:space-y-0">
        <div className="flex items-center space-x-2">
          <div>
            {imageSrc && <img src={imageSrc} alt="Company logo" className="w-20 h-20 sm:w-30 sm:h-30" />}
          </div>
        </div>
        <div className="text-left sm:text-right w-full sm:w-auto">
          <h2 className="text-lg sm:text-xl font-bold">{stockData?.close_quote || 'N/A'} Rs.</h2>
          <StockChangeIndicator
            changePercentage={stockData?.change_percentage}
            changeDirection={stockData?.change_direction}
          />
          <p className="text-xs text-gray-500 flex items-center sm:justify-end mt-1">
            <Clock size={12} className="mr-1" />
            {stockData?.time ? new Date(stockData.time).toLocaleString() : 'N/A'}
          </p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4">
        <InfoItem
          icon={<DollarSign size={24} className="sm:w-8 sm:h-8" />}
          title="Market Cap"
          value={`$${stockData?.market_cap || 'N/A'}`}
        />
        <InfoItem
          icon={<BarChart2 size={24} className="sm:w-8 sm:h-8" />}
          title="Shares"
          value={stockData?.shares || 'N/A'}
        />
        <InfoItem
          icon={<Users size={24} className="sm:w-8 sm:h-8" />}
          title="Free Float Volume"
          value={stockData?.free_float_volume || 'N/A'}
        />
        <InfoItem
          icon={<Percent size={24} className="sm:w-8 sm:h-8" />}
          title="Free Float Percentage"
          value={stockData?.free_float_percentage || 'N/A'}
        />
      </div>
    </div>
  );
};

const StockChart = ({ stockData, stock_symbol }) => {

  if(stockData){
    console.log('Stock Data is  for checking wala is : ',stockData);
  }
  return (
    <div className="flex-1 p-2 sm:p-4 min-h-screen ml-0 mt-[60px] sm:mt-[70px]">
      <Card className="w-full h-full min-h-[600px] sm:min-h-[800px]">
        <CardContent className="space-y-4 sm:space-y-6 pt-4 sm:pt-6">
          <LiveStockInfo stockData={stockData} />
          <VolumeChart stock_symbol={stock_symbol} />
        </CardContent>
      </Card>
    </div>
  );
};

export default StockChart;