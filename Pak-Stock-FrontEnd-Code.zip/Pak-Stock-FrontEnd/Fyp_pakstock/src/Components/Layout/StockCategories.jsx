import React, { useRef } from 'react';
import { Card, CardContent } from '../../Components/ui/Card';
import { ChevronRight, ChevronLeft } from 'lucide-react';

const dummyData = [
  { name: 'FFC', totalShares: '$310.40', totalReturn: '-1.10%', trend: 'down' },
  { name: 'UBL',  totalShares: '$140.45', totalReturn: '-0.10%', trend: 'down' },
  { name: 'ABL', totalShares: '$240.98', totalReturn: '+0.85%', trend: 'up' },
  { name: 'AGP', totalShares: '$99.12', totalReturn: '-0.04%', trend: 'down' },
  { name: 'FATIMA' , totalShares: '$180.75', totalReturn: '+1.20%', trend: 'up' },
  { name: 'FFCL',  totalShares: '$205.30', totalReturn: '-0.80%', trend: 'down' },
  { name: 'HBL', icon: '🏦', totalShares: '$205.30', totalReturn: '-0.80%', trend: 'down' },
];

const StockCategories = () => {
  const scrollContainerRef = useRef(null);

  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -200 : 200;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <Card className="w-[70%] mx-auto">
      <CardContent className="p-6">
        <div className="flex items-center">
          <button
            onClick={() => scroll('left')}
            className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors mr-4"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div
            ref={scrollContainerRef}
            className="flex-1 overflow-x-auto scrollbar-hide"
          >
            <div className="flex space-x-4">
              {dummyData.map((stock, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 w-48 bg-white rounded-lg shadow-md p-4 transition-transform hover:scale-105"
                >
                  <div className="flex items-center mb-2">
                    <span className="text-2xl mr-2">{stock.icon}</span>
                    <span className="font-semibold">{stock.name}</span>
                  </div>
                  <div className="text-sm text-gray-600 mb-1">Total Shares</div>
                  <div className="font-bold mb-2">{stock.totalShares}</div>
                  <div className="text-sm text-gray-600 mb-1">Total Return</div>
                  <div className={`font-bold ${stock.trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>
                    {stock.totalReturn}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={() => scroll('right')}
            className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors ml-4"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </CardContent>
    </Card>
  );
};

export default StockCategories;