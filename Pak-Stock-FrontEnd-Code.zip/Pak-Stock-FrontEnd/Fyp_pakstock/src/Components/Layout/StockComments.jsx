import React, { useState, useEffect } from 'react';
import { Send, MessageCircle, ThumbsUp, ThumbsDown, Edit2, Trash2 } from 'lucide-react';
import { getAuth, onAuthStateChanged } from "firebase/auth";
import { getFirestore } from 'firebase/firestore';

// Card component with responsive padding
const Card = ({ children }) => (
  <div className="bg-white rounded-lg shadow-md w-full">
    {children}
  </div>
);

// Comment component with responsive design
const Comment = ({ comment, onReply, onLike, onDislike, onDelete, onEdit, depth = 0, currentUserId, isAdmin }) => {
  const [showReplyInput, setShowReplyInput] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedText, setEditedText] = useState(comment.text || '');

  // Defensive checks for comment properties
  const author = comment.author || 'Anonymous';
  
  // Use the timestamp from the database, don't create a new date if it's missing
  const timestamp = comment.timestamp 
    ? new Date(comment.timestamp).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    })
    : 'Unknown date';

  const handleReplySubmit = () => {
    if (replyText.trim()) {
      onReply(comment.id, replyText);
      setReplyText('');
      setShowReplyInput(false);
    }
  };

  const handleEditSubmit = () => {
    if (editedText.trim()) {
      onEdit(comment.id, editedText);
      setIsEditing(false);
    }
  };

  // Check if the current user can edit/delete the comment
  // Allow delete if user is admin OR if they are the comment author
  const canDelete = isAdmin || currentUserId === comment.userId;
  // Edit functionality remains the same - only allow edit for the author
  const canEdit = currentUserId === comment.userId;

  // Calculate responsive indentation based on depth
  const indentClass = depth > 0 
    ? `ml-2 md:ml-4 lg:ml-8 pl-2 md:pl-3 border-l border-gray-200` 
    : '';

  return (
    <div className={`mb-4 ${indentClass}`}>
      <div className="flex items-start gap-2 md:gap-3">
        <div className="w-6 h-6 md:w-8 md:h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
          {author[0]?.toUpperCase() || 'A'}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-1 md:gap-2">
            <span className="font-semibold text-xs md:text-sm">{author}</span>
            <span className="text-xs text-gray-500">{timestamp}</span>
          </div>
          
          {isEditing ? (
            <div className="mt-2 flex flex-col md:flex-row gap-2">
              <input
                type="text"
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                className="flex-1 px-2 md:px-3 py-1 md:py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm w-full"
              />
              <div className="flex gap-2 mt-2 md:mt-0">
                <button
                  onClick={handleEditSubmit}
                  className="bg-blue-600 text-white px-3 py-1 md:px-4 md:py-2 rounded-lg hover:bg-blue-700 text-xs md:text-sm"
                >
                  Save
                </button>
                <button
                  onClick={() => setIsEditing(false)}
                  className="bg-gray-200 text-gray-700 px-3 py-1 md:px-4 md:py-2 rounded-lg hover:bg-gray-300 text-xs md:text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <p className="mt-1 text-gray-700 text-sm md:text-base break-words">{comment.text || 'No comment text'}</p>
          )}
          
          <div className="flex flex-wrap items-center gap-2 md:gap-4 mt-2">
            <div className="flex items-center gap-1 md:gap-2">
              <button 
                onClick={() => onLike(comment.id)}
                className="text-gray-500 hover:text-blue-600 p-1"
                aria-label="Like"
              >
                <ThumbsUp size={12} className="md:w-4 md:h-4" />
              </button>
              <button 
                onClick={() => onDislike(comment.id)}
                className="text-gray-500 hover:text-red-600 p-1"
                aria-label="Dislike"
              >
                <ThumbsDown size={12} className="md:w-4 md:h-4" />
              </button>
              <span className="text-xs md:text-sm text-gray-500">{comment.likes || 0}</span>
            </div>
            
            <button 
              onClick={() => setShowReplyInput(!showReplyInput)}
              className="text-xs md:text-sm text-gray-500 hover:text-blue-600 flex items-center gap-1"
            >
              <MessageCircle size={12} className="md:w-4 md:h-4" />
              Reply
            </button>
            
            {/* Show edit button only if user is the author */}
            {canEdit && (
              <button 
                onClick={() => setIsEditing(true)}
                className="text-xs md:text-sm text-gray-500 hover:text-green-600 flex items-center gap-1"
              >
                <Edit2 size={12} className="md:w-4 md:h-4" />
                Edit
              </button>
            )}
            
            {/* Show delete button if user is admin OR is the author */}
            {canDelete && (
              <button 
                onClick={() => onDelete(comment.id)}
                className="text-xs md:text-sm text-gray-500 hover:text-red-600 flex items-center gap-1"
              >
                <Trash2 size={12} className="md:w-4 md:h-4" />
                Delete
              </button>
            )}
          </div>
          
          {showReplyInput && (
            <div className="mt-3 flex flex-col md:flex-row gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Write a reply..."
                className="flex-1 px-2 md:px-3 py-1 md:py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs md:text-sm w-full"
              />
              <button
                onClick={handleReplySubmit}
                className="flex items-center justify-center gap-1 bg-blue-600 text-white px-3 py-1 md:px-4 md:py-2 rounded-lg hover:bg-blue-700 text-xs md:text-sm mt-2 md:mt-0"
              >
                <Send size={12} className="md:w-4 md:h-4" />
                Send
              </button>
            </div>
          )}
        </div>
      </div>
      
      {comment.replies?.length > 0 && comment.replies.map((reply) => (
        <Comment
          key={reply.id}
          comment={reply}
          onReply={onReply}
          onLike={onLike}
          onDislike={onDislike}
          onDelete={onDelete}
          onEdit={onEdit}
          currentUserId={currentUserId}
          isAdmin={isAdmin}
          depth={depth + 1}
        />
      ))}
    </div>
  );
};

const StockComments = ({ stockId }) => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [userId, setUserId] = useState(null);
  const [username, setUsername] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [userRole, setUserRole] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);

  // Firebase authentication setup
  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUserId(user.uid);
        setUsername(user.displayName || 'Anonymous');
        
        // Check if user is admin using Firestore
        try {
          // Import needed Firestore modules
          const { doc, getDoc , getFirestore} = await import('firebase/firestore');
          const  db  = getFirestore() // Adjust the path as needed
          
          const userDoc = doc(db, "Users", user.uid);
          const docSnap = await getDoc(userDoc);
          
          if (docSnap.exists()) {
            const userData = docSnap.data();
            setUserRole(userData.role || 'User');
            setIsAdmin(userData.role === 'Admin');
          } else {
            setUserRole('User');
            setIsAdmin(false);
          }
        } catch (error) {
          console.error("Error checking admin status:", error);
          setUserRole('User');
          setIsAdmin(false);
        }
      } else {
        setUserId(null);
        setUsername(null);
        setUserRole(null);
        setIsAdmin(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Fetch comments with nested structure
  useEffect(() => {
    const fetchComments = async () => {
      if (!stockId) {
        setIsLoading(false);
        return;
      }
    
      try {
        const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/stock-comments?stock_symbol=${stockId}`);
        if (!response.ok) throw new Error('Failed to fetch comments');
    
        const data = await response.json();
        
        // Organize comments into nested structure
        const organizeComments = (allComments) => {
          const commentMap = new Map();
          const topLevelComments = [];

          // First pass: create a map of all comments
          allComments.forEach(comment => {
            commentMap.set(comment.comment_id, {
              ...comment,
              id: comment.comment_id,
              author: comment.username || 'Anonymous',
              text: comment.content || '',
              timestamp: comment.date_created || null, // Don't create a new date here
              likes: comment.likes || 0,
              replies: [],
              userId: comment.user_id
            });
          });

          // Second pass: build nested structure
          allComments.forEach(comment => {
            const processedComment = commentMap.get(comment.comment_id);
            
            if (!comment.parent_comment_id) {
              // Top-level comment
              topLevelComments.push(processedComment);
            } else {
              // Find parent and add as reply
              const parentComment = commentMap.get(comment.parent_comment_id);
              if (parentComment) {
                parentComment.replies = parentComment.replies || [];
                parentComment.replies.push(processedComment);
              }
            }
          });

          return topLevelComments;
        };

        const transformedComments = organizeComments(data);
        setComments(transformedComments);
      } catch (error) {
        console.error('Error fetching comments:', error);
        setComments([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchComments();
  }, [stockId]);

  const handleAddComment = async () => {

    if (!newComment.trim() || !userId) return;

    const auth = getAuth();
    
    const user = auth.currentUser;
  
    if (!user) {
      console.error("User not logged in");
      return;
    }
  
    const token = await user.getIdToken();

    try {
      const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  '/api/stock-comments', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          stock_symbol: stockId,
          user_id: userId,
          username: username,
          parent_comment_id: null, // No parent for top-level comments
          content: newComment,
        })
      });

      if (!response.ok) throw new Error('Failed to add comment');

      const responseData = await response.json();
      
      // Add the comment with the ID from the backend
      // For new comments, we can use the current date as timestamp
      const newCommentObj = {
        id: responseData.comment_id,
        author: username,
        text: newComment,
        timestamp: new Date().toISOString(), // This is fine for newly created comments
        likes: 0,
        replies: [],
        userId: userId
      };

      setComments(prev => [newCommentObj, ...prev]);
      setNewComment('');
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  const handleReply = async (parentCommentId, replyText) => {
    if (!userId) return;

    const auth = getAuth();
    
    const user = auth.currentUser;
  
    if (!user) {
      console.error("User not logged in");
      return;
    }
  
    const token = await user.getIdToken();

    try {
      const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + '/api/stock-comments', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          stock_symbol: stockId,
          user_id: userId,
          username: username,
          parent_comment_id: parentCommentId,
          content: replyText,
        })
      });

      if (!response.ok) throw new Error('Failed to add reply');

      const responseData = await response.json();

      // Recursive function to add reply to nested structure
      const addReplyToComment = (comments, parentId, newReply) => {
        return comments.map(comment => {
          if (comment.id === parentId) {
            return {
              ...comment,
              replies: [
                ...(comment.replies || []),
                newReply
              ]
            };
          } else if (comment.replies && comment.replies.length > 0) {
            return {
              ...comment,
              replies: addReplyToComment(comment.replies, parentId, newReply)
            };
          }
          return comment;
        });
      };

      // Create new reply object
      // For new replies, using current date is fine
      const newReply = {
        id: responseData.comment_id,
        author: username,
        text: replyText,
        timestamp: new Date().toISOString(),
        likes: 0,
        userId: userId,
        replies: []
      };

      // Update comments with new reply
      setComments(prev => addReplyToComment(prev, parentCommentId, newReply));
    } catch (error) {
      console.error('Error adding reply:', error);
    }
  };

  const handleLike = async (commentId) => {
    try {
      await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/stock-comments/${commentId}/like`, {
        method: 'POST',
      });

      // Recursive function to update like count
      const updateLikeCount = (comments, targetId) => {
        return comments.map(comment => {
          if (comment.id === targetId) {
            return { ...comment, likes: (comment.likes || 0) + 1 };
          } else if (comment.replies && comment.replies.length > 0) {
            return {
              ...comment,
              replies: updateLikeCount(comment.replies, targetId)
            };
          }
          return comment;
        });
      };

      setComments(prev => updateLikeCount(prev, commentId));
    } catch (error) {
      console.error('Error liking comment:', error);
    }
  };

  const handleDislike = async (commentId) => {
    try {
      await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/stock-comments/${commentId}/dislike`, {
        method: 'POST',
      });

      // Recursive function to update like count
      const updateDislikeCount = (comments, targetId) => {
        return comments.map(comment => {
          if (comment.id === targetId) {
            return { ...comment, likes: Math.max(0, (comment.likes || 0) - 1) };
          } else if (comment.replies && comment.replies.length > 0) {
            return {
              ...comment,
              replies: updateDislikeCount(comment.replies, targetId)
            };
          }
          return comment;
        });
      };

      setComments(prev => updateDislikeCount(prev, commentId));
    } catch (error) {
      console.error('Error disliking comment:', error);
    }
  };

const handleDelete = async (commentId) => {
  // Remove this incorrect check 
  // if (!newComment.trim() || !userId) return;

  const auth = getAuth();
  
  const user = auth.currentUser;

  if (!user) {
    console.error("User not logged in");
    return;
  }

  const token = await user.getIdToken();
  
  try {
    const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + `/api/stock-comments?comment_id=${commentId}`, {
      method: 'DELETE',
      headers: {
        // 'Authorization': `Bearer ${token}`,  // Add the Authorization header with the token
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorResponse = await response.text();
      console.error('Delete failed:', errorResponse);
      throw new Error('Failed to delete comment');
    }
    
    // Recursive function to remove comment from nested structure
    const removeComment = (comments) => {
      return comments.filter(comment => {
        // If this is the comment to delete
        if (comment.id === commentId) return false;
        
        // If this comment has replies, filter them as well
        if (comment.replies) {
          comment.replies = removeComment(comment.replies);
        }
        
        return true;
      });
    };

    // Update comments, removing the deleted comment
    setComments(prev => removeComment(prev));
  } catch (error) {
    console.error('Error deleting comment:', error);
    alert('Failed to delete comment. Please try again.');
  }
};
  const handleEdit = async (commentId, newContent) => {
    const auth = getAuth();
    
    const user = auth.currentUser;
  
    if (!user) {
      console.error("User not logged in");
      return;
    }
  
    const token = await user.getIdToken();

    try {
      const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/stock-comments`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: user.uid,
          comment_id: commentId,
          content: newContent,
        })
      });

      if (!response.ok) {
        const errorResponse = await response.text();
        console.error('Edit failed:', errorResponse);
        throw new Error('Failed to edit comment');
      }

      // Recursive function to update comment in nested structure
      const updateComment = (comments) => {
        return comments.map(comment => {
          if (comment.id === commentId) {
            return { ...comment, text: newContent };
          }
          
          // If this comment has replies, update them recursively
          if (comment.replies) {
            comment.replies = updateComment(comment.replies);
          }
          
          return comment;
        });
      };

      // Update comments with the edited content
      setComments(prev => updateComment(prev));
    } catch (error) {
      console.error('Error editing comment:', error);
      alert('Failed to edit comment. Please try again.');
    }
  };

  if (isLoading) {
    return (
      <div className="px-4 sm:px-6 md:px-8 lg:pl-[250px]">
        <Card>
          <div className="p-4 md:p-6">Loading comments...</div>
        </Card>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 md:px-8 lg:pl-[250px] w-full max-w-full">
      <Card>
        <div className="p-4 md:p-6">
          <div className="mb-4 md:mb-6">
            <h3 className="text-lg font-semibold mb-3 md:mb-4">Discussion</h3>
            {userId ? (
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                  {username?.[0]?.toUpperCase() || 'A'}
                </div>
                <div className="flex-1">
                  <textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add to the discussion..."
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-y min-h-[60px]"
                  />
                  <div className="flex justify-end mt-2">
                    <button
                      onClick={handleAddComment}
                      className="flex items-center gap-1 bg-blue-600 text-white px-3 py-1 md:px-4 md:py-2 rounded-lg hover:bg-blue-700 text-sm"
                    >
                      <MessageCircle size={16} />
                      <span className="hidden xs:inline">Comment</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-gray-600 text-sm md:text-base">
                Please sign in to add comments
              </div>
            )}
          </div>

          <div className="space-y-4 md:space-y-6">
            {comments.length === 0 ? (
              <div className="text-center text-gray-500 py-6">No comments yet</div>
            ) : (
              comments.map(comment => (
                <Comment
                  key={comment.id}
                  comment={comment}
                  onReply={handleReply}
                  onLike={handleLike}
                  onDislike={handleDislike}
                  onDelete={handleDelete}
                  onEdit={handleEdit}
                  currentUserId={userId}
                  isAdmin={isAdmin}
                />
              ))
            )}
          </div>
        </div>
      </Card>
    </div>
  );
};

export default StockComments;