import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import { Button } from "../ui/Button";
import { Textarea } from "../ui/Textarea";
import { Input } from "../ui/Input";
import { Card, CardContent, CardFooter, CardHeader } from "../ui/Card";
import { Avatar, AvatarFallback } from "../ui/Avatar";
import { Separator } from "../ui/separator";
import { Badge } from "../ui/Badge";
import { MessageCircle, Send, Edit, Trash2, Reply, Calendar, User, AlertCircle, Loader2 } from 'lucide-react';

const StockDiscussion = () => {
  const { postId } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [comment, setComment] = useState("");
  const [picture, setPicture] = useState("");
  const [replyTexts, setReplyTexts] = useState({});
  const [openReplyCommentIds, setOpenReplyCommentIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingCommentId, setEditingCommentId] = useState(null);
  const [editedCommentText, setEditedCommentText] = useState("");
  const [userId, setUserId] = useState(null);
  const [username, setUsername] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState(null);

  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUserId(user.uid);
        setUsername(user.displayName || "Anonymous");
        try {
          // Import needed Firestore modules
          const { doc, getDoc, getFirestore } = await import("firebase/firestore");
          const db = getFirestore();

          const userDoc = doc(db, "Users", user.uid);
          const docSnap = await getDoc(userDoc);

          if (docSnap.exists()) {
            const userData = docSnap.data();
            setUserRole(userData.role || "User");
            setIsAdmin(userData.role === "Admin"); // Note: Case-sensitive match 'Admin' not 'admin'
            console.log("User role detected:", userData.role);
          } else {
            setUserRole("User");
            setIsAdmin(false);
            console.log("User document doesn't exist");
          }
        } catch (error) {
          console.error("Error checking admin status:", error);
          setUserRole("User");
          setIsAdmin(false);
        }
      } else {
        setUserId(null);
        setUsername(null);
        setUserRole(null);
        setIsAdmin(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Format date and time
  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
  };

  // Fetch post and comments
  useEffect(() => {
    const fetchPostDetails = async () => {
      try {
        if (!postId) {
          throw new Error("No post ID provided");
        }

        const postResponse = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + `/api/user-post?post_id=${postId}`);
        const commentsResponse = await fetch(
          process.env.REACT_APP_BACKEND_BASE_URL + `/api/user-post-comment?post_id=${postId}`
        );
        const pictureResponse = await fetch(
          process.env.REACT_APP_BACKEND_BASE_URL + `/api/user-post/image?post_id=${postId}`
        );

        if (!postResponse.ok) {
          throw new Error("Failed to fetch post or comments");
        }

        const postData = await postResponse.json();
        const commentsData = await commentsResponse.json();
        const pictureData = await pictureResponse.json();

        setPost(postData);
        setComments(commentsData.comments || []);
        setPicture(pictureData);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchPostDetails();
  }, [postId]);

  // Handle main comment submission
  const handleComment = async () => {
    if (!comment.trim()) return;

    const auth = getAuth();
    const user = auth.currentUser;

    if (!user) {
      console.error("User not logged in");
      return;
    }

    const token = await user.getIdToken();

    try {
      const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + "/api/user-post-comment", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          post_id: postId,
          user_id: userId,
          username: username,
          content: comment,
          parent_comment_id: null,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to post comment");
      }

      // Refetch comments to get the updated list
      const commentsResponse = await fetch(
        process.env.REACT_APP_BACKEND_BASE_URL + `/api/user-post-comment?post_id=${postId}`
      );
      const commentsData = await commentsResponse.json();
      setComments(commentsData.comments || []);
      setComment("");
    } catch (err) {
      console.error("Error posting comment:", err);
      alert("Failed to post comment. Please try again.");
    }
  };

  // Handle reply submission
  const handleReply = async (parentCommentId) => {
    const replyText = replyTexts[parentCommentId];
    if (!replyText || !replyText.trim()) return;

    const auth = getAuth();
    const user = auth.currentUser;

    if (!user) {
      console.error("User not logged in");
      return;
    }

    const token = await user.getIdToken();

    try {
      const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + "/api/user-post-comment", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          post_id: postId,
          user_id: userId,
          username: username,
          content: replyText,
          parent_comment_id: parentCommentId,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to post reply");
      }

      // Refetch comments to get the updated list with nested replies
      const commentsResponse = await fetch(
        process.env.REACT_APP_BACKEND_BASE_URL + `/api/user-post-comment?post_id=${postId}`
      );
      const commentsData = await commentsResponse.json();
      setComments(commentsData.comments || []);

      // Clear reply text and close reply box for the specific comment
      setReplyTexts((prev) => ({ ...prev, [parentCommentId]: "" }));
      setOpenReplyCommentIds((prev) => prev.filter((id) => id !== parentCommentId));
    } catch (err) {
      console.error("Error posting reply:", err);
      alert("Failed to post reply. Please try again.");
    }
  };

  // Handle comment editing
  const handleEditComment = async (commentId) => {
    if (!editedCommentText.trim()) return;

    const auth = getAuth();
    const user = auth.currentUser;

    if (!user) {
      console.error("User not logged in");
      return;
    }

    const token = await user.getIdToken();

    try {
      const response = await fetch(
        process.env.REACT_APP_BACKEND_BASE_URL + `/api/user-post-comment?comment_id=${commentId}`,
        {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            user_id: userId,
            content: editedCommentText,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to edit comment");
      }

      const data = await response.json();

      // Update the comment in the local state
      setComments((prevComments) =>
        prevComments.map((comment) =>
          comment.comment_id === commentId ? { ...comment, content: data.new_comment.content } : comment
        )
      );

      // Reset edit mode
      setEditingCommentId(null);
      setEditedCommentText("");
    } catch (err) {
      console.error("Error editing comment:", err);
      alert("Failed to edit comment. Please try again.");
    }
  };

  const handleDeletePost = async () => {
    // Confirm deletion
    if (!window.confirm("Are you sure you want to delete this Post? This action cannot be undone.")) {
      return;
    }

    setDeleteLoading(true);
    setDeleteError(null);

    try {
      const response = await fetch(
        `https://pakstock-deployed-backend-production.up.railway.app/api/user-post?post_id=${postId}`,
        {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
          },
          // Include cookies for authentication
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete Post");
      }

      // On successful deletion, navigate back to articles list
      navigate("/Community", { replace: true });
      // Optionally show a success message
      alert("Post deleted successfully");
    } catch (err) {
      setDeleteError(err.message || "Failed to delete Post");
    } finally {
      setDeleteLoading(false);
    }
  };

  // Handle comment deletion
  const handleDeleteComment = async (commentId) => {
    try {
      const auth = getAuth();
      const user = auth.currentUser;

      if (!user) {
        console.error("User not logged in");
        return;
      }

      const token = await user.getIdToken();

      const response = await fetch(
        process.env.REACT_APP_BACKEND_BASE_URL + `/api/user-post-comment?comment_id=${commentId}&user_id=${userId}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete comment");
      }

      // Remove the deleted comment from the local state
      setComments((prevComments) => prevComments.filter((comment) => comment.comment_id !== commentId));
    } catch (err) {
      console.error("Error deleting comment:", err);
      alert("Failed to delete comment. Please try again.");
    }
  };

  // Toggle reply box
  const toggleReplyBox = (commentId) => {
    setOpenReplyCommentIds((prev) =>
      prev.includes(commentId) ? prev.filter((id) => id !== commentId) : [...prev, commentId]
    );
  };

  // Function to format text with markdown-style markup
  const renderFormattedText = (text) => {
    if (!text) return "";

    // Replace markdown-style formatting with HTML tags
    const formattedText = text
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/__(.*?)__/g, "<u>$1</u>")
      // Handle bullet lists - convert "- Item" to list items
      .replace(/- (.*?)(\n|$)/g, "<li>$1</li>")
      // Preserve line breaks
      .replace(/\n/g, "<br />");

    // If there are list items, wrap them in a ul tag
    if (formattedText.includes("<li>")) {
      return formattedText.replace(/(<li>.*?<\/li>)+/g, (match) => `<ul class="list-disc pl-6 mt-2 mb-2">${match}</ul>`);
    }

    return formattedText;
  };

  // Get initials for avatar fallback
  const getInitials = (name) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  // Recursive function to render comments and their nested replies
  const renderComments = (commentsList, parentCommentId = null) => {
    return commentsList
      .filter((comment) => comment.parent_comment_id === parentCommentId)
      .map((comment) => (
        <Card
          key={comment.comment_id}
          className={`mb-4 ${parentCommentId ? "ml-8 border-l-4 border-l-primary/20" : ""}`}
        >
          <CardHeader className="p-4 pb-2 flex flex-row items-center justify-between space-y-0">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarFallback className="bg-primary/10 text-primary">{getInitials(comment.username)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium">{comment.username}</div>
                <div className="text-xs text-muted-foreground flex items-center gap-1">
                  <Calendar size={12} />
                  {formatDateTime(comment.date_created)}
                </div>
              </div>
            </div>

            {(userId === comment.user_id || isAdmin) && (
              <div className="flex gap-2">
                {userId === comment.user_id && (
                  <Button
                    onClick={() => {
                      setEditingCommentId(comment.comment_id);
                      setEditedCommentText(comment.content);
                    }}
                    variant="ghost"
                    size="sm"
                    className="h-8 text-muted-foreground hover:text-primary"
                  >
                    <Edit size={16} className="mr-1" /> Edit
                  </Button>
                )}
                <Button
                  onClick={() => handleDeleteComment(comment.comment_id)}
                  variant="ghost"
                  size="sm"
                  className="h-8 text-muted-foreground hover:text-destructive"
                >
                  <Trash2 size={16} className="mr-1" /> Delete
                </Button>
              </div>
            )}
          </CardHeader>

          <CardContent className="p-4 pt-2">
            {editingCommentId === comment.comment_id ? (
              <div className="mt-2">
                <Textarea
                  value={editedCommentText}
                  onChange={(e) => setEditedCommentText(e.target.value)}
                  className="w-full min-h-[100px]"
                  placeholder="Edit your comment..."
                />
                <div className="flex gap-2 mt-3">
                  <Button onClick={() => handleEditComment(comment.comment_id)} size="sm">
                    Save Changes
                  </Button>
                  <Button
                    onClick={() => {
                      setEditingCommentId(null);
                      setEditedCommentText("");
                    }}
                    variant="outline"
                    size="sm"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div
                className="prose prose-sm max-w-none dark:prose-invert"
                dangerouslySetInnerHTML={{ __html: renderFormattedText(comment.content) }}
              ></div>
            )}
          </CardContent>

          <CardFooter className="px-4 py-2 flex flex-col items-start gap-3">
            {/* Reply button */}
            {userId && (
              <Button
                onClick={() => toggleReplyBox(comment.comment_id)}
                variant="ghost"
                size="sm"
                className="h-8 text-muted-foreground hover:text-primary"
              >
                <Reply size={16} className="mr-1" /> Reply
              </Button>
            )}

            {/* Reply input box */}
            {openReplyCommentIds.includes(comment.comment_id) && (
              <div className="w-full mt-1 pl-4 border-l-2 border-primary/20">
                <div className="flex gap-2 items-center">
                  <Input
                    placeholder="Write a reply..."
                    value={replyTexts[comment.comment_id] || ""}
                    onChange={(e) =>
                      setReplyTexts((prev) => ({
                        ...prev,
                        [comment.comment_id]: e.target.value,
                      }))
                    }
                    className="flex-grow"
                  />
                  <Button onClick={() => handleReply(comment.comment_id)} size="sm" className="whitespace-nowrap">
                    <Send size={14} className="mr-1" /> Post Reply
                  </Button>
                </div>
              </div>
            )}

            {/* Nested replies */}
            <div className="w-full mt-2">{renderComments(commentsList, comment.comment_id)}</div>
          </CardFooter>
        </Card>
      ));
  };

  // Loading and error states
  if (loading) {
    return (
      <div className="w-full max-w-4xl mx-auto p-6 flex flex-col items-center justify-center min-h-[300px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
        <p className="text-muted-foreground">Loading discussion...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full max-w-4xl mx-auto p-6 flex flex-col items-center justify-center min-h-[300px] text-destructive">
        <AlertCircle className="h-8 w-8 mb-4" />
        <p className="font-medium">Error: {error}</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate("/Community")}>
          Return to Community
        </Button>
      </div>
    );
  }

  // Main render
  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-6">
      {/* Post details */}
      {post && (
        <Card className="mb-8 overflow-hidden">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-2xl font-bold">{post.title}</h2>
                <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                  <User size={14} />
                  <span>{post.username}</span>
                  <span>•</span>
                  <Calendar size={14} />
                  <span>{formatDateTime(post.date_created)}</span>
                </div>
              </div>

              {isAdmin && (
                <Button variant="destructive" size="sm" onClick={handleDeletePost} disabled={deleteLoading}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  {deleteLoading ? "Deleting..." : "Delete Post"}
                </Button>
              )}
            </div>
          </CardHeader>

          <CardContent className="pb-4">
            {picture && picture.image_url && (
              <div className="mb-6 -mx-6 overflow-hidden">
                <img
                  src={picture.image_url }
                  alt=""
                  className="w-full h-auto max-h-[500px] object-cover rounded-md"
                />
              </div>
            )}

            {/* Render post content with formatting */}
            <div
              className="prose prose-sm md:prose-base max-w-none dark:prose-invert"
              dangerouslySetInnerHTML={{ __html: renderFormattedText(post.content) }}
            ></div>
          </CardContent>
        </Card>
      )}

      {/* Comments section */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Comments
            <Badge variant="secondary" className="ml-1">
              {comments.length}
            </Badge>
          </h3>
        </div>

        <Separator className="mb-6" />

        {/* Comment input */}
        {userId ? (
          <Card className="mb-8">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <Avatar className="hidden sm:block">
                  <AvatarFallback className="bg-primary/10 text-primary">{getInitials(username)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <Textarea
                    placeholder="Share your thoughts..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    className="min-h-[100px] mb-3"
                  />
                  <Button onClick={handleComment} className="ml-auto" disabled={!comment.trim()}>
                    <Send className="mr-2 h-4 w-4" />
                    Post Comment
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="mb-8 bg-muted/50">
            <CardContent className="p-6 text-center">
              <User className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-muted-foreground">Please sign in to join the discussion</p>
            </CardContent>
          </Card>
        )}

        {/* Comments list */}
        {comments && comments.length > 0 ? (
          <div>{renderComments(comments)}</div>
        ) : (
          <Card className="bg-muted/30">
            <CardContent className="p-8 text-center">
              <MessageCircle className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
              <p className="text-muted-foreground">No comments yet. Be the first to share your thoughts!</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default StockDiscussion; 