import React, { useState, useEffect } from 'react';
import { ArrowUp, ArrowDown, TrendingUp, TrendingDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "../ui/Card";
import { Badge } from "../ui/Badge";

const categories = [
  'banking', 'pharmaceuticals', 'insurance', 'energy', 
  'industrial_manufacturing', 'chemicals', 'textiles', 'cement', 'consumer_goods', 'fertilizer', 
  'diversified_enterprises', 'real_estate', 'technology', 'paper_packaging', 'financial_services', 
  'glass', 'power', 'steel', 'electronics', 'telecommunications', 'tobacco', 'healthcare', 'beverages', 'logistics'
];

const StockListWithNews = ({ onIndustrySelect }) => {
  const [selectedCategory, setSelectedCategory] = useState('Banking');
  const [stockData, setStockData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [articles, setArticles] = useState([]);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Handle responsive layout detection
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    // Set initial value
    handleResize();
    
    // Add event listener for window resize
    window.addEventListener('resize', handleResize);
    
    // Clean up
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    fetchStockData(selectedCategory);
    fetchArticles(selectedCategory);
  }, [selectedCategory]);

  const fetchStockData = async (industry) => {
    setIsLoading(true);
    try {
      const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/detailed-category-information?industry=${industry.toLowerCase()}`);
      const data = await response.json();
      setStockData(data);
    } catch (error) {
      console.error('Error fetching stock data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchArticles = async (industry) => {
    try {
      const response = await fetch(`/api/articles?industry=${industry.toLowerCase()}&days=7`);
      const data = await response.json();
      setArticles(data);
    } catch (error) {
      console.error('Error fetching articles:', error);
    }
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    if (onIndustrySelect) {
      onIndustrySelect(category);
    }
  };

  // Render mobile view of the table
  const renderMobileTable = () => (
    <div className="space-y-4">
      {stockData.map((stock, index) => (
        <div key={index} className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center mb-2">
            {stock.image && (
              <img 
                src={`data:image/png;base64,${stock.image}`}
                alt={`${stock.label} logo`}
                className="w-10 h-10 object-contain rounded-full mr-3"
              />
            )}
            <div>
              <div className="font-medium text-gray-900">{stock.symbol}</div>
              <div className="text-sm text-gray-500 truncate max-w-full" title={stock.label}>
                {stock.label}
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="text-gray-500">Close Quote:</div>
            <div className="text-right font-medium">{stock.close_quote}</div>
            
            <div className="text-gray-500">Change:</div>
            <div className={`text-right font-medium flex items-center justify-end ${stock.change_direction === 'up' ? 'text-green-600' : 'text-red-600'}`}>
              {stock.change_direction === 'up' ? <ArrowUp size={16} className="mr-1" /> : <ArrowDown size={16} className="mr-1" />}
              {stock.change_value} ({stock.change_percentage}%)
            </div>
            
            <div className="text-gray-500">Market Cap:</div>
            <div className="text-right">{stock.market_cap}</div>
            
            <div className="text-gray-500">Shares:</div>
            <div className="text-right">{stock.shares}</div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <Card className="w-full max-w-full  mx-auto lg:ml-[5%]">
      <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-4 md:p-6">
        <CardTitle className="text-xl md:text-2xl lg:text-3xl font-bold">
          Pakistan Stock Exchange - {selectedCategory} Sector
        </CardTitle>
      </CardHeader>
      <CardContent className="p-2 sm:p-4 md:p-6 mt-2 md:mt-4">
        <div className="flex flex-wrap gap-1 sm:gap-2 mb-4 md:mb-6 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => handleCategoryChange(category)}
              className={`px-2 py-1 sm:px-3 md:px-4 sm:py-2 rounded-full text-xs sm:text-sm font-medium transition-colors duration-200 flex-shrink-0 ${
                selectedCategory.toLowerCase() === category
                  ? 'bg-blue-500 text-white shadow-md'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {category.replace('_', ' ').charAt(0).toUpperCase() + category.replace('_', ' ').slice(1)}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-32 sm:h-64">
            <div className="animate-spin rounded-full h-8 w-8 sm:h-12 sm:w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <>
            {/* Mobile view */}
            {isMobile ? (
              renderMobileTable()
            ) : (
              /* Desktop view */
              <div className="overflow-x-auto">
                <table className="w-full table-auto border-collapse bg-white text-xs sm:text-sm md:text-base">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Logo</th>
                      <th className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Symbol</th>
                      <th className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
                      <th className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Close</th>
                      <th className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Change</th>
                      <th className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Market Cap</th>
                      <th className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Shares</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {stockData.map((stock, index) => (
                      <tr 
                        key={index} 
                        className="hover:bg-gray-50 transition-colors duration-200 cursor-pointer"
                      >
                        <td className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 whitespace-nowrap">
                          {stock.image && (
                            <img 
                              src={`data:image/png;base64,${stock.image}`}
                              alt={`${stock.label} logo`}
                              className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 object-contain rounded-full"
                            />
                          )}
                        </td>
                        <td className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 whitespace-nowrap font-medium text-gray-900">{stock.symbol}</td>
                        <td className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 whitespace-nowrap text-gray-500 truncate max-w-[100px] sm:max-w-[150px] md:max-w-xs" title={stock.label}>
                          {stock.label}
                        </td>
                        <td className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 whitespace-nowrap text-gray-900 text-right">{stock.close_quote}</td>
                        <td className={`py-2 px-1 sm:py-3 sm:px-2 md:px-4 whitespace-nowrap font-medium text-right ${stock.change_direction === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                          <span className="flex items-center justify-end">
                            {stock.change_direction === 'up' ? <ArrowUp size={16} className="mr-1" /> : <ArrowDown size={16} className="mr-1" />}
                            {stock.change_value} ({stock.change_percentage}%)
                          </span>
                        </td>
                        <td className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 whitespace-nowrap text-gray-500 text-right">{stock.market_cap}</td>
                        <td className="py-2 px-1 sm:py-3 sm:px-2 md:px-4 whitespace-nowrap text-gray-500 text-right">{stock.shares}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default StockListWithNews;