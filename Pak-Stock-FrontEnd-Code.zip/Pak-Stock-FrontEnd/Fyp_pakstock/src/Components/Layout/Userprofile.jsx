import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../Firebase';
import { toast } from 'react-toastify';
import './ProfilePage.css';
import { getDoc, doc } from 'firebase/firestore';

const UserProfile = () => {
    const [userData, setUserData] = useState({
        displayName: '',
        email: '',
        photoURL: '',
        emailVerified: false,
        createdAt: '',
        lastSignIn: '',
    });
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUserData = async () => {
            const unsubscribe = auth.onAuthStateChanged(async (user) => {
                if (user) {
                    console.log("User logged in:", user.uid);

                    try {
                        // Fetch the document corresponding to the user's UID
                        const docRef = doc(db, "Users", user.uid);
                        const docSnap = await getDoc(docRef);

                        if (docSnap.exists()) {
                            const userProfile = docSnap.data();
                            console.log("User profile data:", userProfile);

                            setUserData({
                                displayName: userProfile.name || 'N/A',
                                email: userProfile.email || 'N/A',
                                photoURL: userProfile.photoURL || 'https://via.placeholder.com/150',
                                emailVerified: user.emailVerified,
                                createdAt: userProfile.createdAt || user.metadata.creationTime,
                                lastSignIn: userProfile.lastSignIn || user.metadata.lastSignInTime,
                            });
                        } else {
                            console.error("No document for user:", user.uid);
                            toast.warning("No profile data found. Please update your profile.");
                        }
                    } catch (error) {
                        console.error("Error fetching user data:", error);
                        if (error.code === 'permission-denied') {
                            toast.error("Permission denied. Please check your Firestore rules.");
                        } else {
                            toast.error("Failed to load profile data.");
                        }
                    }

                    setLoading(false);
                } else {
                    console.log("No user signed in.");
                    navigate('/login');
                }
            });

            return () => unsubscribe();
        };

        fetchUserData();
    }, [navigate]);

    // Handle user logout
    const handleLogOut = async () => {
        try {
            await auth.signOut();
            toast.success("User logged out successfully");
            navigate('/login');
        } catch (error) {
            console.error("Error logging out:", error);
            toast.error("Error logging out. Please try again.");
        }
    };

    if (loading) {
        return (
            <div className="profile-container">
                <div className="loading-spinner">Loading...</div>
            </div>
        );
    }

    return (
        <div className="profile-container">
            <div className="profile-card">
                <div className="profile-header">
                    <img
                        src={userData.photoURL}
                        alt="Profile"
                        className="profile-avatar"
                        onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = 'https://via.placeholder.com/150';
                        }}
                    />
                    <h1 className="profile-name">{userData.displayName}</h1>
                    <p className="profile-email">{userData.email}</p>
                    {userData.emailVerified ? (
                        <span className="verification-badge verified">Email Verified</span>
                    ) : (
                        <span className="verification-badge not-verified">Email Not Verified</span>
                    )}
                </div>

                <div className="profile-details">
                    <div className="detail-item">
                        <label>Account Created:</label>
                        <span>{new Date(userData.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div className="detail-item">
                        <label>Last Sign In:</label>
                        <span>{new Date(userData.lastSignIn).toLocaleDateString()}</span>
                    </div>
                </div>

                <div className="profile-actions">
                    <button
                        className="edit-profile-btn"
                        onClick={() => navigate('/EditProfile')}
                    >
                        Edit Profile
                    </button>
                    <button
                        className="change-password-btn"
                        onClick={handleLogOut}
                    >
                        Logout
                    </button>
                </div>
            </div>
        </div>
    );
};

export default UserProfile;
