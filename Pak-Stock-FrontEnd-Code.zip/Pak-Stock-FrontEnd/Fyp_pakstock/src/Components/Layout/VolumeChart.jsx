// VolumeChart.js
import React, { useState } from 'react';
import CanvasJSReact from '@canvasjs/react-charts';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { Loader2 } from 'lucide-react';
import useVolumeChartData from '../../Services/api/useVolumeChartData'; // Import the custom hook

const CanvasJSChart = CanvasJSReact.CanvasJSChart;

const VolumeChart = ({ stock_symbol }) => {
  const [selectedRange, setSelectedRange] = useState('1M');

  const { dataPoints, isLoading, error } = useVolumeChartData(stock_symbol, selectedRange); // Use custom hook

  const rangeOptions = [
    { label: '1W', days: 7 },
    { label: '1M', days: 30 },
    { label: '6M', days: 180 },
    { label: '1Y', days: 365 },
    { label: '5Y', days: 1825 },
    { label: '10Y', days: 3650 },
    { label: '15Y', days: 5475 },
  ];

  const options = {
    zoomEnabled: true,
    animationEnabled: true,
    theme: 'light2',
    title: {
      fontFamily: 'Poppins, sans-serif',
      fontWeight: 'bold',
      fontSize: 20,
      margin: 20,
    },
    axisX: {
      title: 'Date',
      valueFormatString: selectedRange === '1W' ? 'DD MM' : 'YYYY',
      labelAngle: -45,
      gridThickness: 1,
      gridColor: '#e0e0e0',
      titleFontFamily: 'Poppins, sans-serif',
      titleFontWeight: 'bold',
      titleFontSize: 16,
      labelFontFamily: 'Poppins, sans-serif',
      labelFontSize: 14,
    },
    axisY: {
      title: 'Close Price',
      includeZero: false,
      gridThickness: 1,
      gridColor: '#e0e0e0',
      titleFontFamily: 'Poppins, sans-serif',
      titleFontWeight: 'bold',
      titleFontSize: 16,
      labelFontFamily: 'Poppins, sans-serif',
      labelFontSize: 14,
    },
    data: [
      {
        type: 'line',
        lineColor: '#4A90E2',
        markerType: "none",
        dataPoints: dataPoints,
        toolTipContent: "<span style='font-size:14px; font-weight:bold;'>📅 Date:</span> {x} <br/>" +
                        "<span style='font-size:14px; font-weight:bold; color:#2ECC71;'>📈 Closing Price:</span> <span style='color:#2ECC71;'>{y}</span> <br/>" +
                        "<span style='font-size:14px; font-weight:bold; color:#F39C12;'>📊 Volume:</span> <span style='color:#F39C12;'>{volume}</span>",

      },
    ],
  };

  return (
    <div className="rounded-lg shadow-md z-0 overflow-hidden">
      <Card>
        <CardHeader>
          <CardTitle>{`Historical Chart for ${stock_symbol || 'Unknown Stock'}`}</CardTitle>
          <div className="flex space-x-2 overflow-x-auto pb-2">
            {rangeOptions.map((option) => (
              <Button
                key={option.label}
                onClick={() => setSelectedRange(option.label)}
                variant={selectedRange === option.label ? 'default' : 'outline'}
                className={`
                  px-4 py-2 rounded-md transition-colors duration-200
                  ${selectedRange === option.label 
                    ? 'bg-blue-500 text-white hover:bg-blue-600' 
                    : 'bg-white text-gray-800 hover:bg-gray-100 border border-gray-300'}
                `}
              >
                {option.label}
              </Button>
            ))}
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="animate-spin h-8 w-8 text-gray-500" />
            </div>
          ) : error ? (
            <div className="text-red-500 flex justify-center items-center h-64">
              {error}
            </div>
          ) : (
            <CanvasJSChart options={options} />
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default VolumeChart;
