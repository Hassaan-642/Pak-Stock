// VolumeChart.js
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Mock data for charts
const data = [
  { name: 'Jan', price: 4000, volume: 2400, market: 2400 },
  { name: 'Feb', price: 3000, volume: 1398, market: 2210 },
  { name: 'Mar', price: 2000, volume: 9800, market: 2290 },
  { name: 'Apr', price: 2780, volume: 3908, market: 2000 },
  { name: 'May', price: 1890, volume: 4800, market: 2181 },
  { name: 'Jun', price: 2390, volume: 3800, market: 2500 },
  { name: 'Jul', price: 3490, volume: 4300, market: 2100 },
];

const VolumeChart = () => (
  <div style={styles.chartContainer}>
    <h3 style={styles.chartTitle}>Volume</h3>
    <ResponsiveContainer width="100%" height={600}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="volume" stroke="#82ca9d" />
      </LineChart>
    </ResponsiveContainer>
  </div>
);

const styles = {
  chartContainer: {
    backgroundColor: '#f8f9fa',
    borderRadius: '4px',
    padding: '10px',
  },
  chartTitle: {
    fontSize: '16px',
    fontWeight: 'bold',
    marginBottom: '10px',
    textAlign: 'center',
  },
};

export default VolumeChart;
