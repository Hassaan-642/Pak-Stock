// ChatList.js - Component to display the list of contacts
import React, { useState, useEffect } from 'react';
import { collection, query, where, orderBy, limit, onSnapshot, getDocs, getDoc, doc } from 'firebase/firestore';
import { db } from '../../Firebase';
import './ChatList.css';

const ChatList = ({ contacts, selectedContact, onSelectContact, currentUser }) => {
  const [lastMessages, setLastMessages] = useState({});
  const [unreadCounts, setUnreadCounts] = useState({});

  // Fetch last message for each contact
  useEffect(() => {
    const unsubscribers = [];

    contacts.forEach(contact => {
      const chatId = [currentUser.id, contact.id].sort().join('_');
      const messagesRef = collection(db, 'Chats', chatId, 'messages');
      const lastMessageQuery = query(
        messagesRef,
        orderBy('timestamp', 'desc'),
        limit(1)
      );

      const unsubscribe = onSnapshot(lastMessageQuery, (snapshot) => {
        if (!snapshot.empty) {
          const lastMessage = snapshot.docs[0].data();
          setLastMessages(prev => ({
            ...prev,
            [contact.id]: lastMessage
          }));
        }
      });

      unsubscribers.push(unsubscribe);
    });

    return () => {
      unsubscribers.forEach(unsubscribe => unsubscribe());
    };
  }, [contacts, currentUser.id]);

  // Fetch unread message counts
  useEffect(() => {
    const unsubscribers = [];

    contacts.forEach(contact => {
      const chatId = [currentUser.id, contact.id].sort().join('_');
      const messagesRef = collection(db, 'Chats', chatId, 'messages');
      const unreadQuery = query(
        messagesRef,
        where('readBy', 'array-contains-any', [currentUser.id]),
        where('senderId', '!=', currentUser.id)
      );

      const unsubscribe = onSnapshot(unreadQuery, (snapshot) => {
        setUnreadCounts(prev => ({
          ...prev,
          [contact.id]: snapshot.docs.length
        }));
      });

      unsubscribers.push(unsubscribe);
    });

    return () => {
      unsubscribers.forEach(unsubscribe => unsubscribe());
    };
  }, [contacts, currentUser.id]);

  // Format timestamp
  const formatTime = (timestamp) => {
    if (!timestamp) return '';
    
    const date = timestamp.toDate();
    const now = new Date();
    
    // Same day - show time
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    // Within last week - show day name
    const daysDiff = (now - date) / (1000 * 60 * 60 * 24);
    if (daysDiff < 7) {
      return date.toLocaleDateString([], { weekday: 'short' });
    }
    
    // Otherwise show date
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="chat-list">
      <div className="chat-list-header">
        <h2>Conversations</h2>
      </div>
      <div className="contacts-container">
        {contacts.length === 0 ? (
          <div className="no-contacts">
            <p>No contacts available</p>
          </div>
        ) : (
          contacts.map(contact => {
            const lastMessage = lastMessages[contact.id];
            const unreadCount = unreadCounts[contact.id] || 0;
            const isSelected = selectedContact && selectedContact.id === contact.id;
            
            return (
              <div 
                key={contact.id} 
                className={`contact-item ${isSelected ? 'selected' : ''}`}
                onClick={() => onSelectContact(contact)}
              >
                <div className="contact-avatar">
                  {contact.photoUrl ? (
                    <img src={contact.photoUrl} alt={contact.name} />
                  ) : (
                    <div className="avatar-placeholder">{contact.name.charAt(0)}</div>
                  )}
                </div>
                <div className="contact-details">
                  <div className="contact-name-time">
                    <span className="contact-name">{contact.name}</span>
                    {lastMessage && (
                      <span className="contact-time">{formatTime(lastMessage.timestamp)}</span>
                    )}
                  </div>
                  <div className="contact-preview">
                    {lastMessage ? (
                      <p className="message-preview">
                        {lastMessage.text.length > 30 
                          ? lastMessage.text.substring(0, 30) + '...' 
                          : lastMessage.text}
                      </p>
                    ) : (
                      <p className="no-messages">No messages yet</p>
                    )}
                    {unreadCount > 0 && (
                      <span className="unread-badge">{unreadCount}</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default ChatList;
