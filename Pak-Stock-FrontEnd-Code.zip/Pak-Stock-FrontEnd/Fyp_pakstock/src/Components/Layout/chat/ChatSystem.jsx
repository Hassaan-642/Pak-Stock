// ChatSystem.js - Enhanced React component for chat functionality
import React, { useState, useEffect, useRef, } from 'react';
import {Info, ArrowLeft } from 'lucide-react'
import { collection, query, where, onSnapshot, addDoc, updateDoc, doc, getDoc, serverTimestamp, orderBy } from 'firebase/firestore';
import { useNavigate, Link } from 'react-router-dom';
import ChatList from './ChatList';
import ChatWindow from './ChatWindow';
import './ChatSystem.css';
import { db, auth } from '../../Firebase';

const ChatSystem = () => {
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [contacts, setContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
const navigate = useNavigate();
  const handleBackClick = () => {
    navigate(-1);
  };

  // Fetch current user data
  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged(async (user) => {
      if (user) {
        try {
          const userDoc = await getDoc(doc(db, 'Users', user.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setCurrentUser({
              id: user.uid,
              ...userData
            });
            setUserRole(userData.role);
            console.log("User role:", userData.role);
          } else {
            setError('User profile not found');
          }
        } catch (err) {
          setError('Error fetching user data: ' + err.message);
        }
      } else {
        setCurrentUser(null);
        setUserRole(null);
      }
      setLoading(false);
    });

    return () => unsubscribeAuth();
  }, []);

  // Fetch contacts based on user role
  useEffect(() => {
    if (!currentUser) return;

    let unsubscribeContacts;

    const fetchContacts = async () => {
      try {
        
        if (userRole === 'User' || userRole === 'Admin') {
          // For users and admins, get all brokers from their contact history
          const contactHistoryRef = collection(db, 'ContactHistory');
          const contactQuery = query(contactHistoryRef, where('userId', '==', currentUser.id));
          
          unsubscribeContacts = onSnapshot(contactQuery, async (snapshot) => {
            if (!snapshot.empty) {
              const contactDoc = snapshot.docs[0];
              const contactData = contactDoc.data();
              const brokerIds = contactData.brokerIds || [];
              
              // Fetch broker details
              const brokerPromises = brokerIds.map(id => getDoc(doc(db, 'Users', id)));
              const brokerDocs = await Promise.all(brokerPromises);
              
              const brokerList = brokerDocs
                .filter(doc => doc.exists())
                .map(doc => ({
                  id: doc.id,
                  ...doc.data(),
                  lastMessage: {
                    text: 'Click to view conversation',
                    timestamp: new Date()
                  }
                }));
              
              setContacts(brokerList);
              
              // If we have contacts but no selection, select the first one
              if (brokerList.length > 0 && !selectedContact) {
                setSelectedContact(brokerList[0]);
              }
            }
          });
        } else if (userRole === 'Broker') {
          // For brokers, get all users that have this broker in their brokerIds
          const contactHistoryRef = collection(db, 'ContactHistory');
          console.log("Current user:", currentUser.id);
          const contactsQuery = query(contactHistoryRef, where('brokerIds', 'array-contains', currentUser.id));
          console.log("Contacts query:", contactsQuery);
          
          unsubscribeContacts = onSnapshot(contactsQuery, async (snapshot) => {
            const userIds = snapshot.docs.map(doc => doc.data().userId);
            
            // Fetch user details
            const userPromises = userIds.map(id => getDoc(doc(db, 'Users', id)));
            const userDocs = await Promise.all(userPromises);
            
            const userList = userDocs
              .filter(doc => doc.exists())
              .map(doc => ({
                id: doc.id,
                ...doc.data(),
                lastMessage: {
                  text: 'Click to view conversation',
                  timestamp: new Date()
                }
              }));
            
            setContacts(userList);
            
            // If we have contacts but no selection, select the first one
            if (userList.length > 0 && !selectedContact) {
              setSelectedContact(userList[0]);
            }
          });
        }
      } catch (err) {
        setError('Error fetching contacts: ' + err.message);
      }
    };

    fetchContacts();
    return () => {
      if (unsubscribeContacts) {
        unsubscribeContacts();
      }
    };
  }, [currentUser, userRole, selectedContact]);

  // Handle chat selection
  const handleSelectContact = (contact) => {
    setSelectedContact(contact);
  };

  // Filter contacts based on search query
  const filteredContacts = contacts.filter(contact => 
    contact.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) || 
    contact.lastName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) return (
    <div className="loading">
      Loading chat system...
    </div>
  );
  
  if (error) return (
    <div className="error">
      {error}
    </div>
  );
  
  if (!currentUser) return (
    <div className="error">
      Please log in to access the chat system
      <Link className='btn btn-primary mt-3' to={'/login'}>Login </Link>
    </div>
  );

  return (
    <div className="chat-system">
      <div className="chat-container">
        <div className="chat-list">
          <div className="chat-list-header">
            <button className='mb-3' onClick={handleBackClick}><ArrowLeft size={30}/></button>
            
            <h2 >Messages</h2>
            <div className="chat-list-search">
              <input 
                type="text" 
                placeholder="Search contacts..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <ChatList 
            contacts={filteredContacts} 
            selectedContact={selectedContact}
            onSelectContact={handleSelectContact}
            currentUser={currentUser}
          />
        </div>
        
        {selectedContact ? (
          <ChatWindow 
            currentUser={currentUser} 
            contactUser={selectedContact}
            userRole={userRole}
          />
        ) : (
          <div className="empty-chat">
            <p>Select a {userRole === 'User' ? 'broker' : 'user'} to start chatting</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatSystem;