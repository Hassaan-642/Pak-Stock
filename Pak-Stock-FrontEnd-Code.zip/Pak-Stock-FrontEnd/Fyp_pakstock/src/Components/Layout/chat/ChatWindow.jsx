"use client"

import { useState, useEffect, useRef } from "react"
import {
  collection,
  query,
  orderBy,
  addDoc,
  updateDoc,
  doc,
  onSnapshot,
  getDocs,
  where,
  serverTimestamp,
} from "firebase/firestore"
import { ref as storageRefFirebase, uploadBytesResumable, getDownloadURL } from "firebase/storage"
import { db, storage } from "../../Firebase" // Adjust path as needed
import { Send, Paperclip, X, Check, CheckCheck } from "lucide-react"
import "./ChatWindow.css"

const ChatWindow = ({ currentUser, contactUser, userRole }) => {
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const [file, setFile] = useState(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const messagesEndRef = useRef(null)
  const fileInputRef = useRef(null)
  const chatId = [currentUser.id, contactUser.id].sort().join("_")

  // Fetch messages
  useEffect(() => {
    const messagesRef = collection(db, "Chats", chatId, "messages")
    const messagesQuery = query(messagesRef, orderBy("timestamp", "asc"))

    const unsubscribe = onSnapshot(messagesQuery, (snapshot) => {
      const messageList = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))
      setMessages(messageList)
      setLoading(false)
    })

    return () => unsubscribe()
  }, [chatId])

  // Mark messages as read
  useEffect(() => {
    const markMessagesAsRead = async () => {
      try {
        const messagesRef = collection(db, "Chats", chatId, "messages")
        const unreadQuery = query(
          messagesRef,
          where("senderId", "==", contactUser.id),
          where("readBy", "not-array-contains", currentUser.id),
        )

        const unreadSnapshot = await getDocs(unreadQuery)

        unreadSnapshot.docs.forEach(async (document) => {
          const messageRef = doc(db, "Chats", chatId, "messages", document.id)
          await updateDoc(messageRef, {
            readBy: [...(document.data().readBy || []), currentUser.id],
          })
        })
      } catch (error) {
        console.error("Error marking messages as read:", error)
      }
    }

    if (messages.length > 0) {
      markMessagesAsRead()
    }
  }, [messages, chatId, contactUser.id, currentUser.id])

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Handle file selection
  const handleFileChange = (e) => {
    if (e.target.files[0]) {
      setFile(e.target.files[0])
    }
  }

  // Open file picker
  const openFilePicker = () => {
    fileInputRef.current.click()
  }

  // Upload file to Firebase Storage
  const uploadFile = async () => {
    if (!file) return null

    const timestamp = new Date().getTime()
    const fileExtension = file.name.split(".").pop()
    const fileName = `${chatId}_${timestamp}.${fileExtension}`
    const storageRef = storageRefFirebase(storage, `chat_files/${fileName}`)

    setIsUploading(true)

    try {
      const uploadTask = uploadBytesResumable(storageRef, file)

      return new Promise((resolve, reject) => {
        uploadTask.on(
          "state_changed",
          (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100
            setUploadProgress(progress)
          },
          (error) => {
            console.error("Error uploading file:", error)
            setIsUploading(false)
            reject(null)
          },
          async () => {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref)
            setIsUploading(false)
            setUploadProgress(0)
            setFile(null)
            resolve({
              url: downloadURL,
              name: file.name,
              type: file.type,
              size: file.size,
            })
          },
        )
      })
    } catch (error) {
      console.error("Error uploading file:", error)
      setIsUploading(false)
      return null
    }
  }

  // Send message
  const sendMessage = async (e) => {
    e.preventDefault()

    if (newMessage.trim() === "" && !file) return

    try {
      const messagesRef = collection(db, "Chats", chatId, "messages")

      let fileData = null

      if (file) {
        fileData = await uploadFile()
      }

      await addDoc(messagesRef, {
        text: newMessage,
        senderId: currentUser.id,
        senderName: currentUser.name,
        receiverId: contactUser.id,
        timestamp: serverTimestamp(),
        readBy: [currentUser.id],
        fileAttachment: fileData,
      })

      setNewMessage("")
    } catch (error) {
      console.error("Error sending message:", error)
    }
  }

  // Format timestamp
  const formatMessageTime = (timestamp) => {
    if (!timestamp) return ""
    const date = timestamp.toDate()
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // Format file size
  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + " B"
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB"
    else return (bytes / 1048576).toFixed(1) + " MB"
  }

  // Get file icon based on file type
  const getFileIcon = (fileType) => {
    if (fileType.startsWith("image/")) return "🖼️"
    else if (fileType.startsWith("video/")) return "🎥"
    else if (fileType.startsWith("audio/")) return "🎵"
    else if (fileType.includes("pdf")) return "📄"
    else if (fileType.includes("doc") || fileType.includes("word")) return "📝"
    else if (fileType.includes("xls") || fileType.includes("sheet")) return "📊"
    else if (fileType.includes("ppt") || fileType.includes("presentation")) return "📑"
    else return "📎"
  }

  if (loading)
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )

  return (
    <div className="chat-window">
      <div className="chat-header">
        <div className="contact-info">
          <div className="contact-avatar">
            {contactUser.photoUrl ? (
              <img src={contactUser.photoUrl || "/placeholder.svg"} alt={contactUser.name} />
            ) : (
              <div className="avatar-placeholder">{contactUser.name.charAt(0)}</div>
            )}
          </div>
          <div className="contact-name-role">
            <h3>{contactUser.name}</h3>
            <span className="role-badge">{contactUser.role}</span>
          </div>
        </div>
      </div>

      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="no-messages-yet">
            <div className="empty-state-icon">💬</div>
            <p>No messages yet. Start the conversation!</p>
          </div>
        ) : (
          messages.map((message) => {
            const isCurrentUser = message.senderId === currentUser.id

            return (
              <div key={message.id} className={`message ${isCurrentUser ? "sent" : "received"}`}>
                <div className="message-bubble">
                  {message.text && <div className="message-text">{message.text}</div>}

                  {message.fileAttachment && (
                    <div className="file-attachment">
                      <a
                        href={message.fileAttachment.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="file-link"
                      >
                        <div className="file-preview">
                          {message.fileAttachment.type.startsWith("image/") ? (
                            <img
                              src={message.fileAttachment.url || "/placeholder.svg"}
                              alt={message.fileAttachment.name}
                              className="image-preview"
                            />
                          ) : (
                            <div className="file-icon">{getFileIcon(message.fileAttachment.type)}</div>
                          )}
                        </div>
                        <div className="file-info">
                          <div className="file-name">{message.fileAttachment.name}</div>
                          <div className="file-size">{formatFileSize(message.fileAttachment.size)}</div>
                        </div>
                      </a>
                    </div>
                  )}

                  <div className="message-meta">
                    <span className="message-time">{formatMessageTime(message.timestamp)}</span>
                    {isCurrentUser && (
                      <span className="message-status">
                        {message.readBy && message.readBy.includes(contactUser.id) ? (
                          <CheckCheck size={14} className="read-icon" />
                        ) : (
                          <Check size={14} className="sent-icon" />
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {isUploading && (
        <div className="upload-progress-wrapper">
          <div className="upload-progress-container">
            <div className="upload-progress-bar" style={{ width: `${uploadProgress}%` }}></div>
          </div>
          <div className="upload-progress-text">
            Uploading {file?.name} - {Math.round(uploadProgress)}%
          </div>
        </div>
      )}

      <form className="message-form" onSubmit={sendMessage}>
        {file && !isUploading && (
          <div className="file-preview-container">
            <div className="file-icon">{getFileIcon(file.type)}</div>
            <div className="file-preview-name">{file.name}</div>
            <button type="button" className="remove-file-button" onClick={() => setFile(null)} aria-label="Remove file">
              <X size={16} />
            </button>
          </div>
        )}

        <div className="message-input-container">
          <button type="button" className="attachment-button" onClick={openFilePicker} aria-label="Attach file">
            <Paperclip size={20} />
          </button>
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            className="message-input"
          />
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            style={{ display: "none" }}
            aria-hidden="true"
          />
          <button
            type="submit"
            className="send-button"
            disabled={isUploading || (newMessage.trim() === "" && !file)}
            aria-label="Send message"
          >
            <Send size={18} className="send-icon" />
            <span>Send</span>
          </button>
        </div>
      </form>
    </div>
  )
}

export default ChatWindow
