import React from 'react';

const Disclaimer = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Disclaimer</h1>
      <div className="space-y-4">
        <section>
          <h2 className="text-2xl font-semibold mb-2">1. No Financial Advice</h2>
          <p>The information provided on PakStock is for general informational purposes only and should not be considered as financial advice. Always consult with a qualified financial advisor before making any investment decisions.</p>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">2. Accuracy of Information</h2>
          <p>While we strive to keep the information up to date and correct, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose.</p>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">3. Investment Risks</h2>
          <p>Investing in financial instruments involves risks, including the potential loss of principal. Past performance is not indicative of future results. Users of PakStock are solely responsible for their investment decisions and should carefully consider their financial situation and risk tolerance before investing.</p>
        </section>
      </div>
    </div>
  );
};

export default Disclaimer;