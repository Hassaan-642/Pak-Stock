const dummyPosts = [
    {
      id: 1,
      title: "AAPL Q4 Earnings Analysis",
      content: "Apple's latest earnings report shows strong iPhone sales and services growth. The company reported revenue of $89.5B, beating analyst estimates. What are your thoughts on their performance and future outlook?",
      author: "TechInvestor",
      stockSymbol: "AAPL",
      timestamp: "2024-01-15T10:30:00Z",
      commentCount: 8,
      comments: [
        {
          id: 101,
          text: "The services revenue growth is particularly impressive. Shows their ecosystem strategy is working.",
          author: "ValueSeeker",
          timestamp: "2024-01-15T11:00:00Z",
          replies: [
            {
              id: 1011,
              text: "Agreed! Services margin is also much higher than hardware.",
              author: "MarketWatcher",
              timestamp: "2024-01-15T11:30:00Z"
            }
          ]
        },
        {
          id: 102,
          text: "Concerned about China market share loss. Could impact future quarters.",
          author: "GlobalTrader",
          timestamp: "2024-01-15T12:00:00Z",
          replies: []
        }
      ]
    },
    {
      id: 2,
      title: "TSLA New Factory Announcement",
      content: "Tesla just announced plans for a new Gigafactory. This could significantly boost their production capacity. What impact do you think this will have on their market position?",
      author: "EVEnthusiast",
      stockSymbol: "TSLA",
      timestamp: "2024-01-14T15:45:00Z",
      commentCount: 5,
      comments: [
        {
          id: 201,
          text: "Great move for expanding their global footprint.",
          author: "FutureInvestor",
          timestamp: "2024-01-14T16:00:00Z",
          replies: []
        }
      ]
    },
    {
      id: 3,
      title: "MSFT AI Integration Analysis",
      content: "Microsoft's latest AI integration across their product suite looks promising. The Copilot pricing strategy could be a game-changer for their revenue model.",
      author: "TechAnalyst",
      stockSymbol: "MSFT",
      timestamp: "2024-01-13T09:15:00Z",
      commentCount: 12,
      comments: [
        {
          id: 301,
          text: "The enterprise adoption rate is exceeding expectations.",
          author: "CloudExpert",
          timestamp: "2024-01-13T10:00:00Z",
          replies: []
        }
      ]
    }
  ];
  
  const dummyStocks = [
    { id: "AAPL", name: "Apple Inc." },
    { id: "TSLA", name: "Tesla, Inc." },
    { id: "MSFT", name: "Microsoft Corporation" },
    { id: "GOOGL", name: "Alphabet Inc." },
    { id: "AMZN", name: "Amazon.com, Inc." }
  ];
  
  export { dummyPosts, dummyStocks };