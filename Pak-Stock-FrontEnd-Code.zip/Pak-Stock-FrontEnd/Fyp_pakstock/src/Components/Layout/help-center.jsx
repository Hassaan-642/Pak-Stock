import React from 'react';

const HelpCenter = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Help Center</h1>
      <div className="space-y-4">
        <section>
          <h2 className="text-2xl font-semibold mb-2">Frequently Asked Questions</h2>
          <ul className="list-disc pl-5">
            <li>How do I create an account?</li>
            <li>How can I reset my password?</li>
            <li>What are the main features of PakStock?</li>
            <li>How do I contact customer support?</li>
          </ul>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">Contact Us</h2>
          <p>If you need further assistance, please don't hesitate to contact our support team:</p>
          <p>Email: support@pakstock.com</p>
          <p>Phone: +92 123 456 7890</p>
        </section>
      </div>
    </div>
  );
};

export default HelpCenter;