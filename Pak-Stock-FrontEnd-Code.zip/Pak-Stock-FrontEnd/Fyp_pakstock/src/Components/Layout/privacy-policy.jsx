import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
      <div className="space-y-4">
        <section>
          <h2 className="text-2xl font-semibold mb-2">1. Information We Collect</h2>
          <p>We collect information you provide directly to us, such as when you create or modify your account, request services, contact customer support, or otherwise communicate with us.</p>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">2. How We Use Your Information</h2>
          <p>We use the information we collect to provide, maintain, and improve our services, to process and complete transactions, and to send you related information including confirmations, invoices, technical notices, updates, security alerts, and support and administrative messages.</p>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">3. Information Sharing and Disclosure</h2>
          <p>We do not share personal information with companies, organizations, or individuals outside of PakStock unless one of the following circumstances applies: with your consent, for legal reasons, or to protect rights, property or safety.</p>
        </section>
      </div>
    </div>
  );
};

export default PrivacyPolicy;