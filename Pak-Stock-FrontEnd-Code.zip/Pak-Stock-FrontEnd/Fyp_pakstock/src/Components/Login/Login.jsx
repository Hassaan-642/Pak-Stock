import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
    signInWithEmailAndPassword,
    GoogleAuthProvider,
    signInWithPopup,
    sendEmailVerification 
} from "firebase/auth";
import { auth, db } from '../Firebase';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { setDoc, doc, getDoc, getDocs, collection, query, where } from "firebase/firestore";

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [rememberMe, setRememberMe] = useState(false);
    const [showVerificationWarning, setShowVerificationWarning] = useState(false);

    const navigate = useNavigate();

    // Populate contact history with user ID and broker IDs (or empty array)
    const populateContactHistory = async (userId) => {
        try {
            // First check if contact history already exists
            const contactHistoryRef = doc(db, "ContactHistory", userId);
            const contactHistorySnap = await getDoc(contactHistoryRef);
            
            // Only create contact history if it doesn't already exist
            if (!contactHistorySnap.exists()) {
                // Query for brokers
                const brokersQuery = query(collection(db, "Users"), where("role", "==", "Broker"));
                const querySnapshot = await getDocs(brokersQuery);
                
                // Extract broker IDs or create empty array if none
                const brokerIds = querySnapshot.empty ? [] : querySnapshot.docs.map(doc => doc.id);
                
                // Save the document with userId and brokerIds array
                await setDoc(contactHistoryRef, {
                    userId: userId,
                    brokerIds: brokerIds,
                    lastUpdated: new Date()
                });
                
                console.log(`Contact history created for user ${userId} with ${brokerIds.length} brokers`);
            }
        } catch (error) {
            console.error("Error populating contact history:", error);
            toast.error("Failed to create contact records. Some features may be limited.");
            
            // Even if there's an error, try to create the collection with an empty document
            try {
                const contactHistoryDoc = doc(db, "ContactHistory", userId);
                await setDoc(contactHistoryDoc, {
                    userId: userId,
                    brokerIds: [],
                    lastUpdated: new Date()
                });
            } catch (secondaryError) {
                console.error("Failed to create fallback document:", secondaryError);
            }
        }
    };

    const handleGoogleSignIn = async () => {
        try {
            setLoading(true);
            const provider = new GoogleAuthProvider();
            const result = await signInWithPopup(auth, provider);
            const user = result.user;

            // Check if the user already exists in Firestore
            const userDocRef = doc(db, "Users", user.uid);
            const userDoc = await getDoc(userDocRef);
            
            if (userDoc.exists()) {
                // If user exists, update only necessary fields but preserve their role
                await setDoc(userDocRef, {
                    email: user.email,
                    name: user.displayName,
                    photoURL: user.photoURL,
                    // Do not set role here to preserve existing value
                }, { merge: true });
            } else {
                // If user is new, set all fields including default role
                await setDoc(userDocRef, {
                    email: user.email,
                    name: user.displayName,
                    photoURL: user.photoURL,
                    role: 'User' // Default role for new users only
                });
            }
            
            // Always check and populate contact history for all users
            await populateContactHistory(user.uid);

            toast.success("Successfully signed in with Google!", {
                position: 'top-center',
            });
            
            navigate('/dashboard');
        } catch (error) {
            console.error("Error signing in with Google:", error);
            handleFirebaseError(error);
        } finally {
            setLoading(false);
        }
    };

    const handleResendVerification = async () => {
        try {
            if (auth.currentUser) {
                await sendEmailVerification(auth.currentUser);
                toast.success('Verification email sent! Please check your inbox.');
            }
        } catch (error) {
            console.error('Error sending verification email:', error);
            toast.error('Error sending verification email. Please try again later.');
        }
    };

    const handleFirebaseError = (error) => {
        console.log("Firebase error code:", error.code);
        
        switch (error.code) {
            case 'auth/invalid-email':
                toast.error('Invalid email address');
                break;
            case 'auth/user-disabled':
                toast.error('This account has been disabled');
                break;
            case 'auth/user-not-found':
                toast.error('No account found with this email');
                break;
            case 'auth/wrong-password':
                toast.error('Incorrect password');
                break;
            case 'auth/too-many-requests':
                toast.error('Too many failed attempts. Please try again later');
                break;
            case 'auth/invalid-credential':
                toast.error('Invalid credentials. Please check your email and password');
                break;
            case 'auth/invalid-login-credentials':
                toast.error('Invalid login credentials. Please check your email and password');
                break;    
            case 'auth/network-request-failed':
                toast.error('Network error. Please check your internet connection');
                break;
            case 'auth/popup-closed-by-user':
                toast.error('Google sign-in was cancelled');
                break;    
            default:
                toast.error(`Login error: ${error.message || 'Unknown error occurred'}`);
        }
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        
        if (!email.trim() || !password.trim()) {
            toast.error('Please fill in all fields');
            return;
        }
        
        try {
            setLoading(true);
            
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;
    
            // Check and populate contact history for email/password login too
            await populateContactHistory(user.uid);
    
            // Show warning if email is not verified, but don't prevent login
            if (!user.emailVerified) {
                navigate('/email-verification'); // A dedicated page for verification reminders
                return;
            }
    
            // Handle remember me
            if (rememberMe) {
                localStorage.setItem('rememberMe', 'true');
            }
    
            // Always show success and navigate
            toast.success('Login successful!');
            navigate('/dashboard');
    
        } catch (error) {
            console.error('Login error:', error);
            // Pass the error object directly to handleFirebaseError
            handleFirebaseError(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-container">
            <div className="form-container">
                <h1 className="title">Welcome back!</h1>
                <p className="subtitle">Enter your Credentials to access your account</p>
                
                {showVerificationWarning && (
                    <div className="warning-banner">
                        <p className="warning-text">
                            Your email is not verified. Some features may be limited.
                            <button 
                                onClick={handleResendVerification}
                                className="resend-button"
                            >
                                Resend verification email
                            </button>
                        </p>
                    </div>
                )}

                <form onSubmit={handleLogin} className="form">
                    <div className="input-group">
                        <label htmlFor="email" className="label">Email address</label>
                        <input
                            id="email"
                            type="email"
                            placeholder="Enter your email"
                            value={email}
                            onChange={(event) => setEmail(event.target.value)}
                            className="input"
                        />
                    </div>
                    <div className="input-group">
                        <label htmlFor="password" className="label">Password</label>
                        <input
                            id="password"
                            type="password"
                            placeholder="Enter your password"
                            value={password}
                            onChange={(event) => setPassword(event.target.value)}
                            className="input"
                        />
                        <Link to="/forgot-password" className="forgot-password">forgot password</Link>
                    </div>
                    
                    <button 
                        type="submit" 
                        className={`button `}
                        disabled={loading}
                    >
                        {loading ? 'Logging in...' : 'Login'}
                    </button>
                </form>
                
                <div className="divider">
                    <span className="divider-text">Or</span>
                </div>
                
                <div className="social-buttons">
                    <button 
                        className={`google-button`}
                        onClick={handleGoogleSignIn}
                        disabled={loading}
                    >
                        <img 
                            src="https://cdn1.iconfinder.com/data/icons/google-s-logo/150/Google_Icons-09-512.png" 
                            alt="Google logo" 
                            className="social-icon" 
                        />
                        Sign in with Google
                    </button>
                </div>
                
                <p className="signup-link">
                    Don't have an account? <Link to="/register" className="link">Sign Up</Link>
                </p>
            </div>
            <div className="image-container">
                <img 
                    src="https://plus.unsplash.com/premium_photo-1681487769650-a0c3fbaed85a?q=80&w=1910&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" 
                    alt="Login background" 
                    className="background-image" 
                />
            </div>
            <ToastContainer />

            {/* CSS styles remain unchanged */}
            <style jsx>{`
                /* CSS Reset and Base Styles */
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                }

                /* Main Container */
                .login-container {
                    display: flex;
                    flex-direction: row;
                    min-height: 100vh;
                    background-color: #f0f2f5;
                }

                /* Form Container */
                .form-container {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    padding: 2rem;
                    background-color: #ffffff;
                }

                /* Image Container */
                .image-container {
                    display: none; /* Hidden on mobile by default */
                }

                /* Title */
                .title {
                    font-size: 28px;
                    font-weight: 700;
                    margin-bottom: 0.5rem;
                    color: #333;
                    text-align: center;
                }

                /* Subtitle */
                .subtitle {
                    font-size: 16px;
                    color: #666;
                    margin-bottom: 1.5rem;
                    text-align: center;
                }

                /* Form */
                .form {
                    display: flex;
                    flex-direction: column;
                    gap: 1.25rem;
                }

                /* Input Groups */
                .input-group {
                    display: flex;
                    flex-direction: column;
                    position: relative;
                }

                /* Labels */
                .label {
                    font-size: 14px;
                    font-weight: 600;
                    margin-bottom: 0.5rem;
                    color: #333;
                }

                /* Inputs */
                .input {
                    padding: 0.75rem;
                    font-size: 16px;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    transition: border-color 0.3s ease;
                }

                .input:focus {
                    outline: none;
                    border-color: #4CAF50;
                    box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.2);
                }

                /* Remember Me Checkbox */
                .remember-me {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin-top: -0.5rem;
                }

                .remember-me input {
                    margin: 0;
                }

                .remember-me label {
                    font-size: 14px;
                    color: #666;
                }

                /* Forgot Password Link */
                .forgot-password {
                    align-self: flex-end;
                    font-size: 14px;
                    color: #1890ff;
                    text-decoration: none;
                    margin-top: 0.5rem;
                    text-align: right;
                    display: block;
                }

                .forgot-password:hover {
                    text-decoration: underline;
                }

                /* Button */
                .button {
                    background-color: #4CAF50;
                    color: #fff;
                    border: none;
                    padding: 0.75rem;
                    font-size: 16px;
                    font-weight: 600;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                    margin-top: 0.5rem;
                    width: 100%;
                    position: relative;
                    overflow: hidden;
                    height: 48px; /* Fixed height */
                }

                .button:hover {
                    background-color: #45a049;
                }

                .button.loading {
                    opacity: 0.7;
                    cursor: not-allowed;
                }

                /* Divider */
                .divider {
                    display: flex;
                    align-items: center;
                    margin: 1.5rem 0;
                    position: relative;
                    text-align: center;
                }

                .divider::before, .divider::after {
                    content: '';
                    flex-grow: 1;
                    background-color: #ddd;
                    height: 1px;
                }

                .divider-text {
                    padding: 0 10px;
                    color: #666;
                    background-color: #fff;
                }

                /* Social Buttons */
                .social-buttons {
                    display: flex;
                    justify-content: center;
                    gap: 1rem;
                }

                .google-button {
                    flex: 1;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 0.75rem;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    background-color: #fff;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                    width: 100%;
                    height: 48px; /* Fixed height */
                    position: relative;
                }

                .google-button:hover {
                    background-color: #f5f5f5;
                }

                .google-button.loading {
                    opacity: 0.7;
                    cursor: not-allowed;
                }

                .social-icon {
                    margin-right: 8px;
                    width: 24px;
                    height: 24px;
                }

                /* Signup Link */
                .signup-link {
                    margin-top: 1.5rem;
                    font-size: 14px;
                    color: #666;
                    text-align: center;
                }

                .link {
                    color: #1890ff;
                    text-decoration: none;
                    font-weight: 600;
                }

                .link:hover {
                    text-decoration: underline;
                }

                /* Warning Banner */
                .warning-banner {
                    background-color: #fffbe6;
                    border: 1px solid #ffe58f;
                    border-radius: 8px;
                    padding: 0.75rem;
                    margin-bottom: 1.25rem;
                }

                .warning-text {
                    color: #d48806;
                    margin: 0;
                    font-size: 14px;
                    display: flex;
                    flex-direction: column;
                    gap: 0.5rem;
                }

                .resend-button {
                    background-color: transparent;
                    border: none;
                    color: #1890ff;
                    cursor: pointer;
                    text-decoration: underline;
                    padding: 0.25rem 0.5rem;
                    font-size: 14px;
                    align-self: flex-end;
                }

                /* Tablet Styles */
                @media screen and (min-width: 768px) {
                    .form-container {
                        padding: 2rem 4rem;
                    }

                    .title {
                        font-size: 30px;
                        text-align: left;
                    }

                    .subtitle {
                        text-align: left;
                    }

                    .google-button {
                        padding: 0.75rem 1.5rem;
                    }

                    .social-icon {
                        width: 28px;
                        height: 28px;
                    }

                    .warning-text {
                        flex-direction: row;
                        align-items: center;
                        justify-content: space-between;
                    }
                }

                /* Desktop Styles */
                @media screen and (min-width: 1024px) {
                    .image-container {
                        display: block; /* Show on desktop */
                        flex: 1;
                        overflow: hidden;
                        border-radius: 0 30px 30px 0;
                    }

                    .background-image {
                        width: 100%;
                        height: 100%;
                        object-fit: cover;
                    }

                    .form-container {
                        padding: 0 10%;
                        border-radius: 30px 0 0 30px;
                    }

                    .title {
                        font-size: 32px;
                    }
                }

                /* Large Desktop Styles */
                @media screen and (min-width: 1440px) {
                    .form-container {
                        padding: 0 15%;
                    }
                }
            `}</style>
        </div>
    );
};

export default Login;