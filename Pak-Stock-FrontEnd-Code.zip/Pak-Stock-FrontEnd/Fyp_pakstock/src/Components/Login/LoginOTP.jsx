import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';

const LoginOTP = () => {
  const [otp, setOTP] = useState(['', '', '', '', '', '']);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const inputRefs = useRef([]);
  const navigate = useNavigate();
  const location = useLocation();
  const otpType = location.state?.type || '2fa';

  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  const handleChange = (element, index) => {
    if (isNaN(element.value)) return false;
    setOTP([...otp.map((d, idx) => (idx === index ? element.value : d))]);
    if (element.nextSibling) {
      element.nextSibling.focus();
    }
  };

  const handleBackspace = (e, index) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const newOtp = [...otp];
      newOtp[index - 1] = '';
      setOTP(newOtp);
      inputRefs.current[index - 1].focus();
    }
  };

  const handleSubmit = async () => {
    const otpValue = otp.join('');
    if (otpValue.length !== 6) {
      setError('Please enter a 6-digit OTP.');
      return;
    }

    try {
      const jwt = sessionStorage.getItem('jwt');
      const response = await axios.post(process.env.REACT_APP_BACKEND_BASE_URL + '/api/verify-2fa', 
        { otp: otpValue },
        {
          headers: {
            'Authorization': `Bearer ${jwt}`
          }
        }
      );

      if (response.status === 200) {
        const { confirmed, jwt: newJwt, ...userData } = response.data;
        setSuccess(true);
        setError('');
        // Update the JWT token in session storage
        sessionStorage.setItem('jwtToken', newJwt);
        // Store user data in session storage
        sessionStorage.setItem('userData', JSON.stringify(userData));
        
        if (confirmed) {
          // Navigate to dashboard immediately if confirmed
          navigate('/dashboard');
        } else {
          // If not confirmed, wait before redirecting (you may want to handle this differently)
          // setTimeout(() => navigate('/dashboard'), 1500);
        }
      }
    } catch (err) {
      if (err.response) {
        setError(err.response.data.detail || 'Failed to verify OTP. Please try again.');
      } else {
        setError('An error occurred. Please try again.');
      }
    }
  };

  const resendOTP = async () => {
    try {
      const jwt = sessionStorage.getItem('jwt');
      if (otpType === '2fa') {
        await axios.post(process.env.REACT_APP_BACKEND_BASE_URL +  '/api/send-2fa-otp', {}, {
          headers: {
            'Authorization': `Bearer ${jwt}`
          }
        });
      } else {
        await axios.post(process.env.REACT_APP_BACKEND_BASE_URL +  '/api/send-verification-otp', {}, {
          headers: {
            'Authorization': `Bearer ${jwt}`
          }
        });
      }
      setError('');
      setSuccess(false);
      setOTP(['', '', '', '', '', '']);
    } catch (err) {
      setError(err.response?.data.detail || 'Failed to resend OTP. Please try again.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="p-8 bg-white rounded-lg shadow-md">
        <h1 className="text-2xl font-bold mb-4 text-center">Enter OTP</h1>
        <p className="text-sm text-gray-600 mb-6 text-center">
          We've sent a 6-digit code to your {otpType === '2fa' ? 'registered mobile number' : 'email address'}.
        </p>
       
        <div className="flex justify-center mb-6">
          {otp.map((data, index) => (
            <React.Fragment key={index}>
              <input
                className="w-12 h-12 border-2 rounded-lg mx-1 text-center text-xl"
                type="text"
                name="otp"
                maxLength="1"
                value={data}
                onChange={e => handleChange(e.target, index)}
                onKeyDown={e => handleBackspace(e, index)}
                ref={el => inputRefs.current[index] = el}
              />
              {index === 2 && <span className="mx-2 text-xl">-</span>}
            </React.Fragment>
          ))}
        </div>
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span className="block sm:inline">{error}</span>
          </div>
        )}
        {success && (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span className="block sm:inline">OTP verified successfully! Redirecting to dashboard...</span>
          </div>
        )}
        <button
          onClick={handleSubmit}
          className={`w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
            otp.join('').length === 6 && !success
              ? 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
              : 'bg-gray-300 cursor-not-allowed'
          }`}
          disabled={otp.join('').length !== 6 || success}
        >
          Verify OTP
        </button>
        <p className="text-sm text-gray-600 mt-4 text-center">
          Didn't receive the code? <a href="#" onClick={resendOTP} className="text-blue-600 hover:underline">Resend OTP</a>
        </p>
      </div>
    </div>
  );
};

export default LoginOTP;