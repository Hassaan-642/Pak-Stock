import React from "react";
import { useNavigate } from 'react-router-dom';
import { sendEmailVerification } from "firebase/auth";
import { auth } from "../Firebase";
import { toast } from "react-toastify";

const EmailVerificationPage = () => {
    const navigate = useNavigate();
    const handleResendVerification = async () => {
        try {
            if (auth.currentUser) {
                await sendEmailVerification(auth.currentUser);
                toast.success("Verification email sent!");
            }
        } catch (error) {
            toast.error("Failed to send verification email. Try again later.");
        }
    };

    return (
        <div style={{ textAlign: "center", marginTop: "20px" }}>
            <h1>Please Verify Your Email</h1>
            <p>
                A verification email has been sent to your registered email address.
                Please verify it to access all features.
            </p>
            <button className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out" onClick={handleResendVerification}>Resend Verification Email</button>
            <button 
            onClick={() => navigate('/login')}
            className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out"
          >
            Verification Done
          </button>
        </div>
    );
};

export default EmailVerificationPage;
