import React from 'react';

// Simple utility function to join classNames
const cn = (...classes) => classes.filter(Boolean).join(' ');

const alertVariants = {
  default: "bg-blue-100 border-blue-500 text-blue-700",
  destructive: "bg-red-100 border-red-500 text-red-700",
};

const Alert = React.forwardRef(({ className, variant = "default", children, ...props }, ref) => (
  <div
    ref={ref}
    role="alert"
    className={cn(
      "relative w-full rounded-lg border p-4",
      alertVariants[variant],
      className
    )}
    {...props}
  >
    {children}
  </div>
));

const AlertTitle = React.forwardRef(({ className, ...props }, ref) => (
  <h5
    ref={ref}
    className={cn("mb-1 font-medium", className)}
    {...props}
  />
));

const AlertDescription = React.forwardRef(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("text-sm", className)}
    {...props}
  />
));

Alert.displayName = "Alert";
AlertTitle.displayName = "AlertTitle";
AlertDescription.displayName = "AlertDescription";

export { Alert, AlertTitle, AlertDescription };

// Example usage
const AlertExample = () => {
  return (
    <Alert variant="destructive">
      <AlertTitle>Error</AlertTitle>
      <AlertDescription>There was an error fetching the data.</AlertDescription>
    </Alert>
  );
};

export default AlertExample;