import React from 'react';
import classNames from 'classnames'; // Optional, for conditional styling

// Skeleton Component
export const Skeleton = ({ className }) => {
  return (
    <div className={classNames("animate-pulse bg-gray-300 rounded", className)}></div>
  );
};


