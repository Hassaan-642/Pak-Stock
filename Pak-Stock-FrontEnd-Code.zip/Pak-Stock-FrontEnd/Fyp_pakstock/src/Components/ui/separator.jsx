import React from 'react';

const Separator = ({ className, orientation = "horizontal", ...props }) => {
  const baseStyles = "shrink-0 bg-gray-200";
  const orientationStyles = orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]";
  const combinedClassName = `${baseStyles} ${orientationStyles} ${className || ''}`.trim();

  return <div className={combinedClassName} role="separator" {...props} />;
};

export { Separator };