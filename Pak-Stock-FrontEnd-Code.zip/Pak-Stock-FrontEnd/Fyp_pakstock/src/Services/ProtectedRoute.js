import React, { useState, useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import axios from 'axios';

const ProtectedRoute = ({ children, jwtToken }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const verifyToken = async () => {
      try {
        const response = await axios.post(process.env.REACT_APP_BACKEND_BASE_URL + '/api/verify-jwt', {}, {
          headers: {
            Authorization: `Bearer ${jwtToken}`
          }
        });
        console.log("verify-jwt response :", response.data);
        setIsAuthenticated(response.data === true);
      } catch (error) {
        console.error('Error verifying JWT:', error);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };
    verifyToken();
  }, [jwtToken]);

  if (isLoading) {
    return <div>Loading...</div>; // Or a proper loading spinner component
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
};

export default ProtectedRoute;