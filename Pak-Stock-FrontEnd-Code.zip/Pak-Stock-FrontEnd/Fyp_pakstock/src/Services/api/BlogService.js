import axios from 'axios';

export const blogService = {
  async fetchBlogArticle(articleId) {
    if (!articleId) {
      throw new Error('No article ID provided');
    }

    try {
      // Fetch blog article data
      const articleResponse = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/user-article?article_id=${articleId}`);
      
      // Fetch article images
      const imagesResponse = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/user-articles/images?article_id=${articleId}`);
      
      // Combine article data with images
      return {
        ...articleResponse.data,
        images: imagesResponse.data
      };
    } catch (error) {
      console.error('Error fetching blog data:', error);
      throw new Error('Failed to fetch blog post');
    }
  }
};

export default blogService;