import axios from 'axios';
import { getAuth } from 'firebase/auth';

export const blogCreationService = {
  async createBlogPost(title, content) {
    const auth = getAuth();
    const currentUser = auth.currentUser;
    
    if (!currentUser) {
      throw new Error('No user logged in');
    }

    const token = await currentUser.getIdToken(true);

    const formData = {
      user_id: currentUser.uid,
      username: currentUser.displayName || currentUser.email,
      title: title,
      content: content.replace(/"/g, '\\"')
    };

    try {
      const response = await axios.post(process.env.REACT_APP_BACKEND_BASE_URL + '/api/user-articles', formData, {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      });
      return response.data;
    } catch (error) {
      console.error('Error submitting blog post:', error);
      throw new Error('Failed to submit blog post. Please try again.');
    }
  }
};

export default blogCreationService;