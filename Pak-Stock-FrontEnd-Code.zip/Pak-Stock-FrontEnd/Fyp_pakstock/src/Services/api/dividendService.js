import axios from 'axios';

export const dividendService = {
  async fetchDividendData(stockSymbol) {
    if (!stockSymbol) {
      throw new Error('Stock symbol is required');
    }

    try {
      const response = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL + `/api/dividend-data`, {
        params: { stock_symbol: stockSymbol }
      });
      
      // Return default structure if no dividend data is received
      if (!response.data || !response.data.dividend_amount) {
        return {
          dividend_amount: "Does not pay Dividend",
          dividend_yield: null,
          last_ex_date: null,
          last_pay_date: null
        };
      }
      
      return response.data;
    } catch (error) {
      console.error('Error fetching dividend data:', error);
      throw error;
    }
  },

  // Helper function to check if response is descriptive
  isDescriptiveResponse(dividendAmount) {
    return (
      dividendAmount.includes('not paid') || 
      dividendAmount.includes('Have not') || 
      !/^[\d.]+ ?[A-Z]{3}$/.test(dividendAmount)
    );
  }
};

export default dividendService;