// src/services/recommendationService.js
import axios from 'axios';
import { getAuth } from "firebase/auth";


export const fetchRecommendation = async (stock_symbol) => {
  try {
    const auth = getAuth();
    const user = auth.currentUser;
  
    if (!user) {
      console.error("User not logged in");
      return;
    }
  
    const token = await user.getIdToken();

    const response = await fetch("https://your-api.com/secure/recommendation", {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    });
    
    return response.data;
  } 
  
  catch (error) {
    throw new Error('Failed to fetch data');
  }
};
