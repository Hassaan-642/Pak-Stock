    // useDashboardData.js
    import { useState } from 'react';
    import axios from 'axios';

    const useDashboardData = () => {
        const [stockName, setStockName] = useState('HBL');
        const [companyData, setCompanyData] = useState({
            company_information: '',
            ceo_name: '',
            chairperson_name: '',
            company_secretary_name: '',
            address: '',
            website: '',
            registrar: '',
            auditor: '',
            fiscal_year_end: '',
            market_cap: '',
            shares: '',
            free_float_of_shares: '',
            free_float_percentage: '',
            stock_name: '',
        });
        
        const [stockData, setStockData] = useState({
            company: '',
            time: '',
            close_quote: '',
            change_direction: '',
            change_value: '',
            change_percentage: '',
            market_cap: '',
            shares: '',
            free_float_volume: '',
            free_float_percentage: '',
            image:''
        });
        
        const [loading, setLoading] = useState(false);
        const [error, setError] = useState('');

        
        const handleFetchCompanyInfo = async (selectedStockName) => {
            setStockName(selectedStockName);
            setLoading(true);
            console.log(`Fetching data for stock symbol: ${selectedStockName}`);
        
            try {
                console.log('Attempting to fetch company information...');
                const companyResponse = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL + `/api/company-information`, {
                    params: { stock_symbol: selectedStockName }
                });
                console.log('Company information response:', companyResponse);
        
                const companyResponseData = Array.isArray(companyResponse.data) && companyResponse.data.length > 0
                    ? companyResponse.data[0]
                    : companyResponse.data;
                console.log('Parsed company data:', companyResponseData);
        
                setCompanyData({
                    company_information: companyResponseData.company_information || 'No information available',
                    ceo_name: companyResponseData.ceo_name || 'N/A',
                    chairperson_name: companyResponseData.chairperson_name || 'N/A',
                    company_secretary_name: companyResponseData.company_secretary_name || 'N/A',
                    address: companyResponseData.address || 'N/A',
                    website: companyResponseData.website || 'N/A',
                    registrar: companyResponseData.registrar || 'N/A',
                    auditor: companyResponseData.auditor || 'N/A',
                    fiscal_year_end: companyResponseData.fiscal_year_end || 'N/A',
                    market_cap: companyResponseData.market_cap || 'N/A',
                    shares: companyResponseData.shares || 'N/A',
                    free_float_of_shares: companyResponseData.free_float_of_shares || 'N/A',
                    free_float_percentage: companyResponseData.free_float_percentage || 'N/A',
                    stock_name: companyResponseData.stock_name || selectedStockName,
                });
                console.log('Company data set successfully');
        
                console.log('Attempting to fetch live stock data...');
                const liveResponse = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL + `/api/live-company-data`, {
                    params: { company: selectedStockName }
                });
                console.log('Live stock data response:', liveResponse);
        
                const liveResponseData = liveResponse.data;
                console.log('Parsed live stock data:', liveResponseData);
                const Picture = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL + `/api/stock-image`, {
                    params: { stock_symbol: selectedStockName },
                    responseType: 'arraybuffer'  // Important for handling binary data
                });
                const base64 = btoa(
                    new Uint8Array(Picture.data).reduce((data, byte) => data + String.fromCharCode(byte), '')
                );



                setStockData({
                    id:liveResponseData.id||null,
                    company: liveResponseData.company || selectedStockName,
                    time: liveResponseData.time || 'N/A',
                    close_quote: liveResponseData.close_quote || 'N/A',
                    change_direction: liveResponseData.change_direction || 'N/A',
                    change_value: liveResponseData.change_value || 'N/A',
                    change_percentage: liveResponseData.change_percentage || 'N/A',
                    market_cap: liveResponseData.market_cap || 'N/A',
                    shares: liveResponseData.shares || 'N/A',
                    free_float_volume: liveResponseData.free_float_volume || 'N/A',
                    free_float_percentage: liveResponseData.free_float_percentage || 'N/A',
                    image:  base64 || 'N/A',

                });
                console.log('Stock data set successfully');
        
                setLoading(false);
                console.log('Data fetching completed successfully');


               
        // console.log('Image data fetched successfully');
                
                // console.log('Picture data set successfully');
        
                setLoading(false);
                console.log('Picture data completed successfully');
 
            } catch (err) {
                console.error('Error fetching data:', err);
                console.error('Error details:', {
                    message: err.message,
                    stack: err.stack,
                    response: err.response ? {
                        status: err.response.status,
                        statusText: err.response.statusText,
                        data: err.response.data
                    } : 'No response data'
                });
                setError('Error fetching data. Please try again.');
                setLoading(false);
            }
        };

        return {
            stockName,
            companyData,
            stockData,
            loading,
            error,
            handleFetchCompanyInfo
        };
    };

    export default useDashboardData;
