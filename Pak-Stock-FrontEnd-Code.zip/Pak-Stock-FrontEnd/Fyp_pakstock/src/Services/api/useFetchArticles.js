// useFetchArticles.js
import { useState, useEffect } from 'react';

const useFetchArticles = (industry, days) => {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const fetch_url = process.env.REACT_APP_BACKEND_BASE_URL + `/api/articles?industry=${industry}&days=${days}`;
        console.log('Fetch URL:', fetch_url);
        const response = await fetch(fetch_url, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });
        const data = await response.json();
        console.log('Fetched articles:', data);
        setArticles(data); // Directly set the fetched data as articles
      } catch (error) {
        console.error('Error fetching articles:', error);
        setArticles([]); // Set articles to empty array if fetch fails
      }
    };

    fetchArticles();
  }, [industry, days]);

  console.log("Articles data is:", articles);
  return articles; // Return articles directly
};

export default useFetchArticles;