// useFetchArticles.js
import { useState, useEffect } from 'react';

const useFetchArticles = (industry, days) => {
  const [articles, setArticles] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + `/api/articles`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ industry, days }),
        });
        const data = await response.json();
        setArticles(data.articles || []); // Set articles to empty if none found
      } catch (error) {
        console.error('Error fetching articles:', error);
        setError(error); // Capture error
        setArticles([]); // Reset articles in case of error
      }
    };

    fetchArticles();
  }, [industry, days]);

  return { articles, error }; // Return articles and error for use in the component
};

export default useFetchArticles;
