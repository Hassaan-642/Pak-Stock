// useFetchFinancialData.js
import { useState, useEffect, useCallback } from 'react';

// Dummy data for fallback
const dummyData = {
  indicators: {
    SMA_50_mean: 150.25,
    SMA_200_mean: 145.75,
    RSI_14_mean: 55.5,
    MACD_Line_mean: 2.35,
    Bollinger_Middle_Band_mean: 148.5,
    detailed_data: Array.from({ length: 30 }, (_, i) => ({
      TIME: new Date(2024, 0, i + 1).toISOString().split('T')[0],
      CLOSE: 140 + Math.random() * 20
    })),
  },
  dailyTradingData: [] // Placeholder for daily trading data
};

const useFetchFinancialData = (stock_symbol) => {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = useCallback(async () => {
    console.log('Fetching data for stock symbol:', stock_symbol);
    setIsLoading(true);
    try {
      // Fetch financial indicators
      const indicatorsUrl = process.env.REACT_APP_BACKEND_BASE_URL + `/api/recommendation?stock_symbol=${stock_symbol}`;
      const indicatorsResponse = await fetch(indicatorsUrl)
      if (!indicatorsResponse.ok) {
        throw new Error('Network response was not ok');
      }
      const indicatorsResult = await indicatorsResponse.json();

      // Fetch daily trading data
      const tradingUrl = process.env.REACT_APP_BACKEND_BASE_URL + `/api/live-DayToDayTrading?stock_name=${stock_symbol}`;
      const tradingResponse = await fetch(tradingUrl);
      if (!tradingResponse.ok) {
        throw new Error('Network response was not ok');
      }
      const tradingResult = await tradingResponse.json();

      // Combine both results
      setData({
        indicators: indicatorsResult,
        dailyTradingData: tradingResult,
      });
    } catch (error) {
      console.error('Error fetching data:', error);
      // Use dummy data if API call fails
      setData(dummyData);
    } finally {
      setIsLoading(false);
    }
  }, [stock_symbol]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, isLoading }; // Return data and loading state
};

export default useFetchFinancialData;