// useFetchUserDetails.js
import { useState, useEffect } from 'react';
import axios from 'axios';

const useFetchUserDetails = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const token = localStorage.getItem('authToken'); // Get the token from localStorage
        
        if (!token) {
          throw new Error("Token not found. Please log in.");
        }
  
        const response = await axios.get(process.env.REACT_APP_BACKEND_BASE_URL + '/profile', {
          headers: {
            'Authorization': `Bearer ${token}`, // Include the token in the Authorization header
          },
          withCredentials: true,
        });
  
        if (response.data && response.data.username) {
          setUsername(response.data.username);
          setEmail(response.data.email);
        } else {
          console.warn('Username not found in response:', response.data);
        }
      } catch (error) {
        setError(error.response ? error.response.data : error.message);
      }
    };
  
    fetchUserDetails();
  }, []);

  return { username, email, error };
};

export default useFetchUserDetails;
