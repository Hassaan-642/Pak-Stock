// usePredictedData.js
import { useState, useEffect } from 'react';

const useRandomforestPredictedData = (stock_symbol, selectedRange) => {
    const [chartData2, setChartData] = useState([]);
    const [isLoading2, setIsLoading] = useState(false);
    const [error2, setError] = useState(null);

    const ranges = [
        { label: 'D1', days: 1 },
        { label: 'W1', days: 7 },
        { label: 'M1', days: 30 },
        { label: 'M2', days: 60 },
        { label: 'M3', days: 90 },
    ];

    useEffect(() => {
        const fetchData = async () => {
            if (!stock_symbol) {
                setError('No stock symbol provided');
                return;
            }

            setIsLoading(true);
            setError(null);

            try {
                const days = ranges.find(range => range.label === selectedRange).days;

                const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + `/api/predicted?stock_symbol=${stock_symbol}&days=${days}&model_type=RandomForestRegressor`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const data = await response.json();
                
                console.log('Raw data from API:', data);  // Log raw data

                if (!Array.isArray(data) || data.length === 0) {
                    throw new Error('Invalid data received from server');
                }

                const formattedData = data.map(item => ({
                    date: item.TIME,
                    close: parseFloat(item.CLOSE),
                }));

                console.log('Formatted data:', formattedData);  // Log formatted data

                setChartData(formattedData);
            } catch (err) {
                console.error('Error fetching data:', err);
                setError('Failed to fetch data. Please try again later.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, [stock_symbol, selectedRange]);

    return { chartData2, isLoading2, error2 };
};

export default useRandomforestPredictedData;
