// useVolumeChartData.js
import { useState, useEffect } from 'react';

const useVolumeChartData = (stock_symbol, selectedRange) => {
  const [dataPoints, setDataPoints] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const rangeOptions = [
    { label: '1W', days: 7 },
    { label: '1M', days: 30 },
    { label: '6M', days: 180 },
    { label: '1Y', days: 365 },
    { label: '5Y', days: 1825 },
    { label: '10Y', days: 3650 },
    { label: '15Y', days: 5475 },
  ];

  useEffect(() => {
    const fetchData = async () => {
      if (!stock_symbol) {
        setError('No stock symbol provided');
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      setError(null);

      try {
        let days = rangeOptions.find(option => option.label === selectedRange).days;

        const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + `/api/historical?stock_symbol=${encodeURIComponent(stock_symbol)}&days=${days}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }

        const data = await response.json();

        if (!Array.isArray(data) || data.length === 0) {
          throw new Error('Invalid data received from server');
        }

        const chartData = data.map((point) => ({
          x: new Date(point.TIME),
          y: parseFloat(point.CLOSE),
          volume: parseFloat(point.VOLUME)
        }));

        setDataPoints(chartData);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to fetch data. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [stock_symbol, selectedRange]);

  return { dataPoints, isLoading, error };
};

export default useVolumeChartData;
