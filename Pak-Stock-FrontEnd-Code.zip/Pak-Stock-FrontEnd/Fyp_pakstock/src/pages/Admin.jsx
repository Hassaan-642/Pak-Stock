import React, { useState, useEffect, useRef } from 'react';
import { Table, Button, Modal, Form, Input, message, Popconfirm, Typography, Layout, Avatar, Badge, Card, Row, Col, Select, Spin } from 'antd';
import { UserOutlined, SearchOutlined, LoadingOutlined } from '@ant-design/icons';
import { PlusCircle, UserPlus, UserMinus, Edit, Users, UserX, UserCheck, Settings, LogOut, Menu, X } from 'lucide-react';
import { db } from '../Components/Firebase';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, getDoc, query, where } from 'firebase/firestore';
import { getAuth, onAuthStateChanged, signOut } from 'firebase/auth';
import { Navigate, useNavigate, Link } from 'react-router-dom';
import HomepageSidebar from '../Components/Layout/HomePageSidebar';

const { Header, Content } = Layout;
const { Title } = Typography;
const { Option } = Select;

function StatCard({ icon, title, value, color }) {
  return (
    <Card hoverable className="stat-card" style={{ borderTop: `4px solid ${color}` }}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-lg font-semibold text-gray-600">{title}</p>
          <h2 className="text-3xl font-bold">{value}</h2>
        </div>
        <div className={`p-3 rounded-full`} style={{ backgroundColor: `${color}20` }}>
          {icon}
        </div>
      </div>
    </Card>
  );
}

const AdminPanel = () => {
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [form] = Form.useForm();
  const [searchTerm, setSearchTerm] = useState('');
  const [editingUser, setEditingUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminVerifying, setAdminVerifying] = useState(true); // Added state for admin verification
  const [currentUser, setCurrentUser] = useState(null);
  const [mobileView, setMobileView] = useState(window.innerWidth <= 768);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Profile menu state (from Navbar)
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [userProfile, setUserProfile] = useState(null);
  const profileMenuRef = useRef(null);

  const auth = getAuth();
  const usersCollectionRef = collection(db, "Users");
  const contactHistoryCollectionRef = collection(db, "ContactHistory");

  // Handle responsive layout changes
  useEffect(() => {
    const handleResize = () => {
      setMobileView(window.innerWidth <= 768);
      if (window.innerWidth > 768) {
        setIsSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize(); // Initial check
    
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Check if current user is admin and set user profile
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        
        // Set user profile (from Navbar)
        setUserProfile({
          username: user.displayName || user.email.split('@')[0],
          email: user.email,
          photoURL: user.photoURL
        });
        
        // Get user's role from Firestore
        const userDoc = doc(db, "Users", user.uid);
        try {
          setAdminVerifying(true); // Start admin verification
          const docSnap = await getDoc(userDoc);
          if (docSnap.exists()) {
            const userData = docSnap.data();
            setIsAdmin(userData.role === 'Admin');
          } else {
            setIsAdmin(false);
          }
        } catch (error) {
          console.error("Error checking admin status:", error);
          setIsAdmin(false);
        } finally {
          setAdminVerifying(false); // End admin verification
          setLoading(false);
        }
      } else {
        setCurrentUser(null);
        setUserProfile(null);
        setIsAdmin(false);
        setAdminVerifying(false);
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Handle click outside profile menu
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target)) {
        setIsProfileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Fetch users from Firebase
  useEffect(() => {
    if (isAdmin && !adminVerifying) {
      const getUsers = async () => {
        try {
          const data = await getDocs(usersCollectionRef);
          const usersData = data.docs.map(doc => ({
            ...doc.data(),
            id: doc.id
          }));
          setUsers(usersData);
        } catch (error) {
          console.error("Error fetching users:", error);
          message.error('Failed to fetch users');
        }
      };

      getUsers();
    }
  }, [isAdmin, adminVerifying]);

  // Function to handle component change from sidebar
  const handleComponentChange = (component) => {
    // Handle component change if needed
    console.log("Component changed to:", component);
  };

  // Toggle sidebar for mobile view
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Handle logout function from Navbar
  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

    /**
   * Updates brokerIds in ContactHistory documents based on role changes
   * 
   * When action is 'add': Used when a user becomes a "Broker" - adds the brokerId to all other users' ContactHistory
   * When action is 'remove': Used when a user is no longer a "Broker" - removes the brokerId from all ContactHistory documents
   * 
   * @param {string} brokerId - The ID of the user who is becoming/was a broker
   * @param {string} action - Either 'add' (user changed TO broker) or 'remove' (user changed FROM broker)
   * @returns {Promise<void>} 
   */
  const updateBrokerIdsInContactHistory = async (brokerId, action) => {
    try {
      if (action !== 'add' && action !== 'remove') {
        throw new Error("Action must be either 'add' or 'remove'");
      }
      
      let contactHistoryQuery;
      
      if (action === 'add') {
        // When a user becomes a Broker, update all ContactHistory docs EXCEPT their own
        console.log(`User ${brokerId} became a Broker. Adding to all other users' ContactHistory.`);
        
        // Query all ContactHistory documents except the one belonging to this user
        contactHistoryQuery = query(
          contactHistoryCollectionRef,
          where("userId", "!=", brokerId)
        );
        
      } else { // action === 'remove'
        // When a user is no longer a Broker, remove their ID from all ContactHistory docs
        console.log(`User ${brokerId} is no longer a Broker. Removing from all ContactHistory documents.`);
        
        // Query all ContactHistory documents that have this user's ID in their brokerIds array
        contactHistoryQuery = query(
          contactHistoryCollectionRef,
          where("brokerIds", "array-contains", brokerId)
        );
      }
      
      const querySnapshot = await getDocs(contactHistoryQuery);
      
      if (!querySnapshot.empty) {
        // Process all matching documents in parallel
        const updatePromises = querySnapshot.docs.map(async (docSnapshot) => {
          const contactHistoryDoc = doc(db, "ContactHistory", docSnapshot.id);
          const contactHistoryData = docSnapshot.data();
          let brokerIds = contactHistoryData.brokerIds || [];
          
          if (action === 'add') {
            // Only add if not already present
            if (!brokerIds.includes(brokerId)) {
              brokerIds.push(brokerId);
              await updateDoc(contactHistoryDoc, { brokerIds });
              console.log(`Added broker ${brokerId} to ContactHistory for user ${contactHistoryData.userId}`);
            }
          } else { // action === 'remove'
            // Filter out this brokerId
            const updatedBrokerIds = brokerIds.filter(id => id !== brokerId);
            
            // Only update if there was a change
            if (updatedBrokerIds.length !== brokerIds.length) {
              await updateDoc(contactHistoryDoc, { brokerIds: updatedBrokerIds });
              console.log(`Removed broker ${brokerId} from ContactHistory for user ${contactHistoryData.userId}`);
            }
          }
        });
        
        // Wait for all updates to complete
        await Promise.all(updatePromises);
        
        console.log(`Successfully ${action === 'add' ? 'added' : 'removed'} broker ${brokerId} ${action === 'add' ? 'to' : 'from'} ContactHistory documents`);
      } else {
        console.log(`No ContactHistory documents found to ${action} broker ${brokerId}`);
      }
    } catch (error) {
      console.error(`Error updating brokerIds in ContactHistory: ${error}`);
      throw error;
    }
  };

  /**
   * Usage examples:
   * 
   * // When a user is changed to Broker role:
   * await updateBrokerIdsInContactHistory('user123', 'add');
   * 
   * // When a user is changed from Broker role to something else:
   * await updateBrokerIdsInContactHistory('user123', 'remove');
   */

  // Show loading spinner while verifying admin status
  if (adminVerifying) {
    return (
      <Layout style={{ minHeight: '100vh' }}>
        <Content style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '16px' }}>
          <Card style={{ width: '100%', maxWidth: '500px', textAlign: 'center' }}>
            <Spin 
              indicator={<LoadingOutlined style={{ fontSize: 36 }} spin />} 
              tip="Verifying administrator access..." 
            />
            <p style={{ marginTop: '20px' }}>Please wait while we verify your credentials.</p>
          </Card>
        </Content>
      </Layout>
    );
  }

  // If not admin, show access denied message
  if (!isAdmin && !adminVerifying) {
    return (
      <Layout style={{ minHeight: '100vh' }}>
        <Content style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '16px' }}>
          <Card style={{ width: '100%', maxWidth: '500px' }}>
            <Title level={3} style={{ color: '#ff4d4f' }}>Access Denied</Title>
            <p>You do not have administrator privileges to access this Admin panel.</p>
            <Button type="primary" onClick={() => navigate('/dashboard')}>
              Return to Dashboard
            </Button>
          </Card>
        </Content>
      </Layout>
    );
  }

  // Rest of the component code remains the same
  const showModal = (user = null) => {
    setEditingUser(user);
    if (user) {
      form.setFieldsValue(user);
    } else {
      form.resetFields();
    }
    setIsModalVisible(true);
  };

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      
      if (editingUser) {
        const userDoc = doc(db, "Users", editingUser.id);
        await updateDoc(userDoc, values);
        
        // Check if user role was changed to "Broker"
        if (values.role === 'Broker' && editingUser.role !== 'Broker') {
          await updateBrokerIdsInContactHistory(editingUser.id, 'add');
        }
        // Check if user role was changed from "Broker" to something else
        else if (editingUser.role === 'Broker' && values.role !== 'Broker') {
          await updateBrokerIdsInContactHistory(editingUser.id, 'remove');
        }
        
        setUsers(users.map(user => 
          user.id === editingUser.id ? { ...user, ...values } : user
        ));
        message.success('User updated successfully');
      } else {
        const docRef = await addDoc(usersCollectionRef, values);
        const newUser = { id: docRef.id, ...values };
        
        // If the new user is a broker, update ContactHistory for all users
        if (values.role === 'Broker') {
          await updateBrokerIdsInContactHistory(docRef.id, 'add');
        }
        
        setUsers([...users, newUser]);
        message.success('User added successfully');
      }
      setIsModalVisible(false);
    } catch (error) {
      console.error("Error handling user:", error);
      message.error(editingUser ? 'Failed to update user' : 'Failed to add user');
    }
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const deleteUser = async (userId) => {
    try {
      // Get user data before deletion to check if it's a broker
      const userDoc = doc(db, "Users", userId);
      const userSnapshot = await getDoc(userDoc);
      const userData = userSnapshot.data();
      
      // Delete the user
      await deleteDoc(userDoc);
      
      // If deleted user was a broker, update ContactHistory documents
      if (userData && userData.role === 'Broker') {
        await updateBrokerIdsInContactHistory(userId, 'remove');
      }
      
      setUsers(users.filter(user => user.id !== userId));
      message.success('User deleted successfully');
    } catch (error) {
      console.error("Error deleting user:", error);
      message.error('Failed to delete user');
    }
  };

  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      render: (text, record) => (
        <div className="flex items-center">
          <Avatar icon={<UserOutlined />} className="mr-2" />
          <span>{text}</span>
        </div>
      ),
      ellipsis: true,
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
      ellipsis: true,
      responsive: ['md'],
    },
    {
      title: 'Role',
      dataIndex: 'role',
      key: 'role',
      render: (text) => (
        <Badge color={text === 'Admin' ? 'red' : text === 'Manager' ? 'blue' : text === 'Broker' ? 'purple' : 'green'} text={text} />
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <div className="action-buttons" style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
          <Button 
            type="link" 
            onClick={() => showModal(record)} 
            style={{ padding: mobileView ? '4px 8px' : '4px 15px' }}
            icon={<Edit className="h-4 w-4" />}
          >
            {!mobileView && 'Edit'}
          </Button>
          <Popconfirm
            title="Are you sure you want to delete this user?"
            onConfirm={() => deleteUser(record.id)}
            okText="Yes"
            cancelText="No"
          >
            <Button 
              type="link" 
              danger 
              style={{ padding: mobileView ? '4px 8px' : '4px 15px' }}
              icon={<UserMinus className="h-4 w-4" />}
            >
              {!mobileView && 'Delete'}
            </Button>
          </Popconfirm>
        </div>
      ),
    },
  ];

  // Mobile-specific columns
  const mobileColumns = columns.filter(col => col.dataIndex !== 'email' || col.key === 'actions');

  if (loading) {
    return (
      <Layout style={{ minHeight: '100vh' }}>
        <Content style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '16px' }}>
          <Card style={{ width: '100%' }}>
            <div>Loading...</div>
          </Card>
        </Content>
      </Layout>
    );
  }

  return (
    <Layout style={{ minHeight: '100vh' }}>
      {/* Dashboard Sidebar */}
      <HomepageSidebar
        onComponentChange={handleComponentChange} 
        isOpen={isSidebarOpen} 
        onToggle={toggleSidebar} 
      />

      <Layout className="site-layout" style={{ 
        marginLeft: mobileView ? 0 : '250px', // Match the width of DashboardSidebar
        transition: 'margin-left 0.3s ease'
      }}>
        <Header 
          className="site-layout-background" 
          style={{ 
            padding: 0, 
            background: '#fff', 
            boxShadow: '0 2px 8px #f0f1f2',
            position: 'sticky',
            top: 0,
            zIndex: 999,
            width: '100%', 
            display: 'flex',
            justifyContent: 'space-between', // Changed from flex-end to space-between
            alignItems: 'center'
          }}
        >
          {/* Mobile Menu Toggle */}
          <div className="flex items-center md:hidden pl-4">
            <button 
              onClick={toggleSidebar} 
              className="text-gray-500 hover:text-gray-700 focus:outline-none"
            >
              {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
          
          {/* Header Title - visible on both mobile and desktop */}
          <div className="flex-1 text-center md:text-left md:pl-6">
            <span className="font-bold text-lg text-blue-600">Admin Panel</span>
          </div>
          
          {/* Profile Menu - from Navbar component */}
          <div className="pr-4 md:pr-6">
            <div className="relative" ref={profileMenuRef}>
              <button 
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="flex items-center space-x-2 hover:bg-gray-100 p-1 rounded-full transition-colors"
              >
                {userProfile?.photoURL ? (
                  <img 
                    src={userProfile.photoURL} 
                    alt="Profile" 
                    className="w-8 h-8 md:w-10 md:h-10 rounded-full" 
                  />
                ) : (
                  <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-blue-500 flex items-center justify-center text-white">
                    {userProfile?.username?.[0]?.toUpperCase()}
                  </div>
                )}
              </button>

              {isProfileMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white border rounded-lg shadow-lg overflow-hidden z-50">
                  <div className="px-4 py-3 bg-gray-50 border-b">
                    <p className="text-sm font-medium text-gray-900">
                      {userProfile?.username}
                    </p>
                    <p className="text-xs text-gray-500 truncate">
                      {userProfile?.email}
                    </p>
                  </div>
                  <div className="py-1">
                    <Link 
                      to="/Userprofile" 
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      <UserOutlined className="mr-3" style={{ fontSize: '16px' }} />
                      Profile
                    </Link>
                    <Link 
                      to="/settings" 
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      <Settings className="mr-3" size={16} />
                      Settings
                    </Link>
                    <button 
                      onClick={handleLogout}
                      className="w-full text-left flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                    >
                      <LogOut className="mr-3" size={16} />
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </Header>
        
        <Content style={{ margin: mobileView ? '8px' : '16px' }}>
          <div 
            className="site-layout-background" 
            style={{ 
              padding: mobileView ? '12px' : '24px', 
              minHeight: 360,
              background: '#fff',
              borderRadius: '8px'
            }}
          >
            <Title level={mobileView ? 3 : 2} style={{ marginBottom: mobileView ? '16px' : '24px' }}>Dashboard</Title>
            
            <Row gutter={[16, 16]} style={{ marginBottom: mobileView ? '16px' : '24px' }}>
              <Col xs={24} sm={12} lg={8}>
                <StatCard icon={<Users size={24} color="#1890ff" />} title="Total Users" value={users.length} color="#1890ff" />
              </Col>
              <Col xs={24} sm={12} lg={8}>
                <StatCard icon={<UserCheck size={24} color="#52c41a" />} title="Verified Users" value={users.filter(user => user.role === 'Admin' || user.role === 'Broker').length} color="#52c41a" />
              </Col>
              <Col xs={24} sm={12} lg={8}>
                <StatCard icon={<UserX size={24} color="#722ed1" />} title="Regular Users" value={users.filter(user => user.role === 'User').length} color="#722ed1" />
              </Col>
            </Row>
            
            <div 
              style={{ 
                marginBottom: '16px', 
                display: 'flex', 
                flexDirection: mobileView ? 'column' : 'row',
                gap: mobileView ? '12px' : '0',
                justifyContent: 'space-between', 
                alignItems: mobileView ? 'stretch' : 'center' 
              }}
            >
              <Input
                placeholder="Search users..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={{ width: mobileView ? '100%' : 200 }}
                prefix={<SearchOutlined />}
              />
              <Button 
                type="primary" 
                onClick={() => showModal()} 
                icon={<UserPlus size={16} />}
                style={{ width: mobileView ? '100%' : 'auto' }}
              >
                Add New User
              </Button>
            </div>
            
            <div className="table-responsive" style={{ overflowX: 'auto' }}>
              <Table 
                columns={mobileView ? mobileColumns : columns} 
                dataSource={filteredUsers} 
                rowKey="id"
                loading={loading}
                pagination={{ 
                  pageSize: mobileView ? 5 : 10,
                  responsive: true,
                  size: mobileView ? 'small' : 'default'
                }}
                style={{ 
                  background: 'white', 
                  borderRadius: '8px', 
                  overflow: 'hidden' 
                }}
                scroll={{ x: mobileView ? 400 : 800 }}
                size={mobileView ? 'small' : 'middle'}
              />
            </div>
          </div>
        </Content>
      </Layout>

      <Modal
        title={editingUser ? "Edit User" : "Add New User"}
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        width={mobileView ? '95%' : '520px'}
        footer={[
          <Button key="back" onClick={handleCancel}>
            Cancel
          </Button>,
          <Button key="submit" type="primary" onClick={handleOk} icon={<PlusCircle size={16} />}>
            {editingUser ? "Update User" : "Add User"}
          </Button>,
        ]}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            name="name"
            label="Name"
            rules={[{ required: true, message: 'Please input the name!' }]}
          >
            <Input prefix={<UserOutlined />} />
          </Form.Item>
          <Form.Item
            name="email"
            label="Email"
            rules={[
              { required: true, message: 'Please input the email!' },
              { type: 'email', message: 'Please enter a valid email!' }
            ]}
          >
            <Input prefix={<SearchOutlined />} />
          </Form.Item>
          <Form.Item
            name="role"
            label="Role"
            rules={[{ required: true, message: 'Please select a role!' }]}
          >
            <Select placeholder="Select a role">
              <Option value="Admin">Admin</Option>
              <Option value="User">User</Option>
              <Option value="Broker">Broker</Option>
            </Select>
          </Form.Item>
        </Form>
      </Modal>
    </Layout>
  );
};

export default AdminPanel;