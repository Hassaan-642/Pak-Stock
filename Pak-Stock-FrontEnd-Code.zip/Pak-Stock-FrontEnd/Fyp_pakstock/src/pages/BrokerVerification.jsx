import { useState } from 'react';

export default function BrokerVerificationForm() {
  const [formData, setFormData] = useState({
    legal_name: "",
    license_number: "",
    brokerage_type: "",
    registration_number: "",
    office_address: "",
    contact_phone: "",
    professional_email: "",
    website_url: "",
    secp_registration_details: "",
    aml_compliance_details: "",
    kyc_procedures_details: "",
    capital_adequacy_ratio_details: "",
    financial_statements_details: "",
    trading_platforms_details: "",
    trading_tools_details: "",
    secp_license_details: "",
    iso_certification_details: "",
    other_certifications: "",
    investment_products: "",
    fee_structure_details: "",
    client_testimonials: "",
    security_measures: "",
    privacy_policy_details: "",
    verification_notes: ""
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState({ type: '', text: '' });
  
  const validateField = (name, value) => {
    // Clear previous error for this field
    const newErrors = { ...errors };
    delete newErrors[name];
    
    // Check if field is empty
    if (!value.trim()) {
      newErrors[name] = 'This field is required';
      return newErrors;
    }
    
    // Check character limit (100 characters)
    if (value.length > 100) {
      newErrors[name] = 'Maximum 100 characters allowed';
      return newErrors;
    }
    
    // Specific validations
    switch (name) {
      case 'professional_email':
        // Email validation
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(value)) {
          newErrors[name] = 'Please enter a valid email address';
        }
        break;
        
      case 'contact_phone':
        // Phone validation (international format)
        const phoneRegex = /^\+?[0-9]{10,15}$/;
        if (!phoneRegex.test(value.replace(/\s/g, ''))) {
          newErrors[name] = 'Please enter a valid phone number (10-15 digits)';
        }
        break;
        
      case 'website_url':
        // URL validation
        if (value) { // Only validate if not empty
          const urlRegex = /^(https?:\/\/)?(www\.)?[a-zA-Z0-9-]+(\.[a-zA-Z]{2,})+([/a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=]*)?$/;
          if (!urlRegex.test(value)) {
            newErrors[name] = 'Please enter a valid website URL';
          }
        }
        break;
        
      case 'license_number':
      case 'registration_number':
        // Alphanumeric validation
        const alphanumericRegex = /^[a-zA-Z0-9-]+$/;
        if (!alphanumericRegex.test(value)) {
          newErrors[name] = 'Only letters, numbers, and hyphens are allowed';
        }
        break;
        
      default:
        // No specific validation for other fields
        break;
    }
    
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // Update form data
    setFormData({ ...formData, [name]: value });
    
    // Validate the field
    const newErrors = validateField(name, value);
    setErrors(newErrors);
  };

  const validateForm = () => {
    let formIsValid = true;
    let newErrors = {};
    
    // Validate all fields
    Object.entries(formData).forEach(([name, value]) => {
      const fieldErrors = validateField(name, value);
      
      if (Object.keys(fieldErrors).length > 0) {
        newErrors = { ...newErrors, ...fieldErrors };
        formIsValid = false;
      }
    });
    
    setErrors(newErrors);
    return formIsValid;
  };

  const handleSubmit = async () => {
    // Validate all fields before submitting
    if (!validateForm()) {
      setSubmitMessage({ 
        type: 'error', 
        text: 'Please fill in all required fields correctly' 
      });
      return;
    }
    
    setIsSubmitting(true);
    setSubmitMessage({ type: '', text: '' });
    
    try {
      const response = await fetch('process.env.REACT_APP_BACKEND_BASE_URL/api/broker-verification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      if (response.ok) {
        setSubmitMessage({ 
          type: 'success', 
          text: 'Broker verification information submitted successfully!' 
        });
        // Optional: Reset form
        // setFormData({ legal_name: "", ... })
      } else {
        const errorData = await response.json();
        setSubmitMessage({ 
          type: 'error', 
          text: `Submission failed: ${errorData.message || response.statusText}` 
        });
      }
    } catch (error) {
      setSubmitMessage({ 
        type: 'error', 
        text: `Error connecting to server: ${error.message}` 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Group form fields for better organization
  const formGroups = [
    {
      title: "Basic Information",
      fields: [
        { name: "legal_name", label: "Legal Name", type: "text" },
        { name: "license_number", label: "License Number", type: "text" },
        { name: "brokerage_type", label: "Brokerage Type", type: "text" },
        { name: "registration_number", label: "Registration Number", type: "text" },
      ]
    },
    {
      title: "Contact Information",
      fields: [
        { name: "office_address", label: "Office Address", type: "textarea" },
        { name: "contact_phone", label: "Contact Phone", type: "tel" },
        { name: "professional_email", label: "Professional Email", type: "email" },
        { name: "website_url", label: "Website URL", type: "url" },
      ]
    },
    {
      title: "Regulatory Compliance",
      fields: [
        { name: "secp_registration_details", label: "Security Exchange Commision Of Pakistan (SECP) Registration Details", type: "textarea" },
        { name: "aml_compliance_details", label: "Anti Money Laundering Law (AML) Compliance Details", type: "textarea" },
        { name: "kyc_procedures_details", label: "Know Your Customers (KYC) Procedures Details", type: "textarea" },
        { name: "capital_adequacy_ratio_details", label: "Capital Adequacy Ratio Details", type: "textarea" },
      ]
    },
    {
      title: "Financial & Operations",
      fields: [
        { name: "financial_statements_details", label: "Financial Statements Details", type: "textarea" },
        { name: "trading_platforms_details", label: "Trading Platforms Details", type: "textarea" },
        { name: "trading_tools_details", label: "Trading Tools Details", type: "textarea" },
      ]
    },
    {
      title: "Certifications & Licenses",
      fields: [
        { name: "secp_license_details", label: "SECP License Details", type: "textarea" },
        { name: "iso_certification_details", label: "ISO Certification Details", type: "textarea" },
        { name: "other_certifications", label: "Other Certifications", type: "textarea" },
      ]
    },
    {
      title: "Services & Policies",
      fields: [
        { name: "investment_products", label: "Investment Products", type: "textarea" },
        { name: "fee_structure_details", label: "Fee Structure Details", type: "textarea" },
        { name: "client_testimonials", label: "Client Testimonials", type: "textarea" },
        { name: "security_measures", label: "Security Measures", type: "textarea" },
        { name: "privacy_policy_details", label: "Privacy Policy Details", type: "textarea" },
      ]
    }
  ];

  return (
    <div className="bg-gray-50 min-h-screen p-6">
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6 text-center">Broker Verification Form</h1>
        
        {submitMessage.text && (
          <div className={`mb-6 p-4 rounded ${submitMessage.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {submitMessage.text}
          </div>
        )}
        
        <div className="space-y-8">
          {formGroups.map((group, groupIndex) => (
            <div key={groupIndex} className="border rounded-lg p-4">
              <h2 className="text-xl font-semibold mb-4 text-gray-700">{group.title}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {group.fields.map((field) => (
                  <div key={field.name} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
                    <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor={field.name}>
                      {field.label} <span className="text-red-500">*</span>
                    </label>
                    {field.type === 'textarea' ? (
                      <textarea
                        id={field.name}
                        name={field.name}
                        value={formData[field.name] || ''}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors[field.name] ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        rows="3"
                        maxLength="100"
                        required
                      />
                    ) : (
                      <input
                        type={field.type}
                        id={field.name}
                        name={field.name}
                        value={formData[field.name] || ''}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors[field.name] ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        maxLength="100"
                        required
                        placeholder={field.type === 'tel' ? '+1234567890' : ''}
                      />
                    )}
                    {errors[field.name] && (
                      <p className="mt-1 text-sm text-red-600">{errors[field.name]}</p>
                    )}
                    {field.name === 'contact_phone' && !errors[field.name] && (
                      <p className="mt-1 text-xs text-gray-500">Format: +1234567890 (10-15 digits)</p>
                    )}
                    <div className="mt-1 text-xs text-gray-500 flex justify-between">
                      <span>Required</span>
                      <span>{(formData[field.name] || '').length}/100</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
          
          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-blue-300"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Verification'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}