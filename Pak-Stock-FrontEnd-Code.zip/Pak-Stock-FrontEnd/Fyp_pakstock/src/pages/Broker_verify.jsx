import {
  Mail,
  Building2,
  Phone,
  FileCheck,
  BarChart4,
  MonitorSmartphone,
  Award,
  BarChart3,
  Shield,
  ArrowRight,
} from "lucide-react"
import { Link } from "react-router-dom"

const BrokerVerification = () => {
  return (
    <div>
      <div className="rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-8 mb-10 shadow-xl">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-center">Broker Verification Process</h1>
        <p className="text-lg text-blue-100 max-w-3xl mx-auto text-center leading-relaxed">
          If you're interested in becoming a broker on our platform, please first create a standard user account.
          Then, submit the required details listed below to our team for review. After successful verification,
          we will upgrade your account to broker status and notify you via email.
        </p>
        
        <div className="mt-8 bg-white/10 rounded-xl p-6 border border-white/20 shadow-lg max-w-2xl mx-auto">
          <p className="text-blue-50 text-center">Please fill the below mentioned details in this form </p>
          <a
            href="/Broker-verification-form"
            className="flex items-center justify-center gap-2 text-white font-medium text-lg mt-2 hover:text-blue-200 transition-colors group"
          >
            <button>Broker Verifcation form</button>
            </a>
          <div className="mt-6 flex items-center justify-center gap-2 text-sm text-blue-100">
            <div className="h-10 w-10 rounded-full bg-blue-500/30 flex items-center justify-center">
              <span className="font-bold">3-4</span>
            </div>
            <p>Business days for verification after submission</p>
          </div>
        </div>
      </div>

      {/* Requirements Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-4">
        {/* Section 1 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-4 flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <Building2 className="text-white h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Broker Information</h2>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {[
                "Full Legal Name of the Broker / Brokerage Firm",
                "License Number issued by the Securities and Exchange Commission of Pakistan (SECP)",
                "Type of Brokerage (e.g., Full-Service, Discount, Online-Only)",
                "Official Registration Number",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Section 2 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
          <div className="bg-gradient-to-r from-indigo-500 to-indigo-600 p-4 flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <Phone className="text-white h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Contact Details</h2>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {[
                "Physical Office Address",
                "Contact Phone Number",
                "Professional Email Address",
                "Official Website URL",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-5 w-5 text-indigo-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Section 3 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
          <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-4 flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <FileCheck className="text-white h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Regulatory Compliance</h2>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {[
                "Proof of Registration with the SECP (SECP Registration Certificate)",
                "Confirmation of adherence to Anti-Money Laundering (AML) laws",
                "Details of Know Your Customer (KYC) procedures",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-5 w-5 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Section 4 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
          <div className="bg-gradient-to-r from-cyan-500 to-cyan-600 p-4 flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <BarChart4 className="text-white h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Financial Information</h2>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {[
                "Statement confirming compliance with Capital Adequacy Ratio requirements",
                "Most recent Audited Financial Statements",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-5 w-5 text-cyan-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Section 5 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
          <div className="bg-gradient-to-r from-teal-500 to-teal-600 p-4 flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <MonitorSmartphone className="text-white h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Trading Platforms & Tools</h2>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {[
                "Information on trading platforms (web and mobile) offered by the broker",
                "Details of available trading tools and features",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-5 w-5 text-teal-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Section 6 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
          <div className="bg-gradient-to-r from-amber-500 to-amber-600 p-4 flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <Award className="text-white h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Licenses & Certifications</h2>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {[
                "SECP License or Approval Letter",
                "Any relevant ISO or industry-specific certifications (if applicable)",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Section 7 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
          <div className="bg-gradient-to-r from-rose-500 to-rose-600 p-4 flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <BarChart3 className="text-white h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Broker Services</h2>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {[
                "List of investment products available for clients (e.g., stocks, bonds, commodities)",
                "Detailed breakdown of brokerage fees, commissions, and charges",
                "Client reviews or testimonials highlighting service quality",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-5 w-5 text-rose-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Section 8 */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
          <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 p-4 flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <Shield className="text-white h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Security and Privacy</h2>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {[
                "Description of data security measures in place (e.g., encryption, two-factor authentication)",
                "Copy of Privacy Policy outlining data handling and protection procedures",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-5 w-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrokerVerification;