import React, { useState, useEffect } from 'react';
import DashboardSidebar from '../Components/Layout/DashboardSidebar';
import useDashboardData from '../Services/api/useDashboardData';
import CompanyInfoNews from '../Components/Layout/CompanyInfo';
import Navbar from '../Components/Layout/Navbar';
import StockChart from '../Components/Layout/StockAnalysis';
import FinancialDashboard from '../Components/Layout/FinancialDashboard';
import Footer from '../Components/Layout/Footer';
import Predicted from '../Components/Layout/Predicted';
import TimedPopup from './TImePopup';
import StockComments from '../Components/Layout/StockComments';
import StockAnalysisCard from '../Components/Layout/DividendAndSentiment';
import ChatbotWithModal from '../Components/Layout/Chatbot';
import './Dashboard.css'; // We'll create this stylesheet for dashboard-specific styles

function Dashboard() {
  const {
    stockName,
    companyData,
    stockData,
    loading,
    error,
    handleFetchCompanyInfo
  } = useDashboardData();
  
  const [industry, setIndustry] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Toggle sidebar visibility (for mobile)
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  async function getStockIndustry(stockName) {
    try {
      // Modified to use query parameters instead of body
      const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/stock-to-industry?stock_symbol=${encodeURIComponent(stockName)}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      });
     
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error fetching stock industry:', error);
      return null;
    }
  }

  useEffect(() => {
    async function fetchIndustry() {
      if (stockName) {
        const fetchedIndustry = await getStockIndustry(stockName);
        setIndustry(fetchedIndustry || '');
      }
    }
    fetchIndustry();
  }, [stockName]);

  // Close sidebar when clicking outside on small screens
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) {
        setSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="dashboard-container">
      <TimedPopup />
      
      <div className={`dashboard-layout ${sidebarOpen ? 'sidebar-open' : ''}`}>
        
      <ChatbotWithModal />
        {/* Pass the toggle function to the sidebar */}
        <DashboardSidebar onToggle={toggleSidebar} isOpen={sidebarOpen} />
        
        <div className="dashboard-content">
          <Navbar onStockSelect={handleFetchCompanyInfo} />
          
          <div className="dashboard-sections">
            <section id="stock-chart" className="dashboard-section">

              
              <StockChart stockData={stockData} stock_symbol={stockName} />
            </section>
            
            <section id="financial-dashboard" className="dashboard-section">
              <FinancialDashboard stock_symbol={stockName} />
            </section>
            
            <section id="predicted" className="dashboard-section">
              <Predicted stock_symbol={stockName} />
            </section>
            
            {loading && <p className="loading-message">Loading company data...</p>}
            {error && <p className="error-message">{error}</p>}
            
            <section id="sentiment" className="dashboard-section">
              <StockAnalysisCard
                stockSymbol={stockName}
                industry={industry}
                days={30}
              />
            </section>
            
            <section id="company-info" className="dashboard-section">
              <CompanyInfoNews companyData={companyData} industry={industry} days={14} />
            </section>
            
            <section id="community-collaboration" className="dashboard-section">
              <StockComments stockId={stockName} />
            </section>
            <section className='dashboard-section'>
          <Footer />  
          </section>
          </div>
          
          
        </div>
      </div>
    </div>
  );
}

export default Dashboard;