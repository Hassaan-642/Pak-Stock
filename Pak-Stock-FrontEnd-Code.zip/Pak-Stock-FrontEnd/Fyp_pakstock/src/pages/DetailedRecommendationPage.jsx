import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { fetchRecommendation } from '../Services/api/recommendationService'; // Import the service function
import { SMAChart, RSIChart, MACDChart, BollingerBandsChart } from '../Components/Layout/RecommendationCharts';
import MarketTrendIndicator from '../Components/Layout/MarketTrendIndicator';
import SentimentAnalysis from '../Components/Layout/SentimentAnalysis';
import ArticlesList from '../Components/Layout/ArticlesList';

const DetailedRecommendationPage = () => {
  const { stock_symbol } = useParams();
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const recommendationData = await fetchRecommendation(stock_symbol); // Use the service function
        setData(recommendationData);
      } catch (err) {
        setError('Failed to fetch the data. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };

    if (stock_symbol) {
      fetchData();
    }
  }, [stock_symbol]);

  if (isLoading) {
    return <div className="p-6">Loading...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-500">{error}</div>;
  }

  if (!data || !data.indicators ) {
    return <div className="p-6">No data available</div>;
  }

  const { indicators,trend_recommendation, detailed_data,  } = data;
  // const sentimentData = [
  //   { name: 'Positive', value: sentiment.positive_percentage },
  //   { name: 'Neutral', value: sentiment.neutral_percentage },
  //   { name: 'Negative', value: sentiment.negative_percentage },
  // ];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Detailed Recommendation for {stock_symbol}</h1>

      <div className="grid grid-cols-1 md:grid-cols-1 gap-6">
        <SMAChart indicators={indicators} detailedData={detailed_data} />
        <RSIChart indicators={indicators} detailedData={detailed_data} />
        <MACDChart indicators={indicators} detailedData={detailed_data} />
        <BollingerBandsChart indicators={indicators} detailedData={detailed_data} />
      </div>

      <div className="gap-6 mb-2" style={{ display: 'flex' }}>
        <MarketTrendIndicator trend={trend_recommendation} />
        {/* <SentimentAnalysis sentimentData={sentimentData} /> */}
      </div>

      {/* <ArticlesList articles={articles} /> */}
    </div>
  );
};

export default DetailedRecommendationPage;
