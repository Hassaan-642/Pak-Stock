import React, { useState, useEffect } from 'react';
import { ArrowUp, ArrowDown, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "../Components/ui/Card";
import { Badge } from "../Components/ui/Badge";
import { motion } from "framer-motion";

const StockRow = ({ stock }) => {
  const isPositive = stock.change_direction === 'up';
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="p-2 sm:p-3 md:p-4 border-b hover:bg-gray-50 transition-colors duration-200"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0">
        <div className="flex-1 w-full sm:w-auto">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 truncate">{stock.company}</h3>
          <div className="flex items-center text-xs sm:text-sm text-gray-500">
            <span>Market Cap: {(stock.market_cap / 1000000).toFixed(2)}M</span>
          </div>
        </div>
        <div className="text-right w-full sm:w-auto">
          <div className="text-base sm:text-lg font-bold">{stock.close_quote.toFixed(2)}</div>
          <div className={`flex items-center justify-end ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {isPositive ? (
              <ArrowUp className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
            ) : (
              <ArrowDown className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
            )}
            <span className="text-xs sm:text-sm font-medium">
              {stock.change_value.toFixed(2)} ({stock.change_percentage.toFixed(2)}%)
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const IndustryPerformance = ({ industry }) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Handle responsive layout detection
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    // Set initial value
    handleResize();
    
    // Add event listener for window resize
    window.addEventListener('resize', handleResize);
    
    // Clean up
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/industry-top-gainers-losers?industry=${industry}`);
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const result = await response.json();
        setData(result);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchData();
  }, [industry]);

  if (loading) {
    return (
      <Card className="w-full max-w-full lg:w-[90%] mx-auto lg:ml-[5%]">
        <CardContent className="h-48 sm:h-64 md:h-96 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 sm:h-12 sm:w-12 md:h-16 md:w-16 border-t-4 border-b-4 border-blue-500"></div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full max-w-full lg:w-[90%] mx-auto lg:ml-[5%]">
        <CardContent className="p-3 sm:p-4 md:p-6">
          <div className="bg-red-50 border-l-4 border-red-500 text-red-700 p-3 sm:p-4 rounded-r-lg">
            <p className="font-bold">Error</p>
            <p>{error}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className="w-full max-w-full mx-auto lg:ml-[5%]">
        <CardContent className="p-3 sm:p-4 md:p-6">
          <div className="bg-gray-50 border-l-4 border-gray-500 text-gray-700 p-3 sm:p-4 rounded-r-lg">
            <p className="font-bold">No Data</p>
            <p>No data is currently available for this industry.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-full  mx-auto lg:ml-[5%] mt-4 sm:mt-6">
      <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-3 sm:p-4 md:p-6">
        <CardTitle className="text-xl sm:text-2xl md:text-3xl font-bold">
          {industry} Sector Performance
        </CardTitle>
        <p className="text-blue-100 mt-1 sm:mt-2 text-sm sm:text-base">Top gainers and losers in the market</p>
      </CardHeader>
      <CardContent className="p-2 sm:p-4 md:p-6">
        <div className="grid gap-4 sm:gap-6 md:gap-8 grid-cols-1 md:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: isMobile ? 0 : -50, y: isMobile ? -20 : 0 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-2 sm:mb-4 bg-green-50 p-2 sm:p-3 md:p-4 rounded-lg flex items-center justify-between">
              <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-green-700">Top Gainers</h2>
              <Badge variant="success" className="text-xs sm:text-sm md:text-lg py-0 sm:py-1">
                <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5 mr-1" />
                Rising
              </Badge>
            </div>
            <div className="border rounded-lg divide-y shadow-sm">
              {data.top_gainers.map((stock) => (
                <StockRow key={stock.id} stock={stock} />
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: isMobile ? 0 : 50, y: isMobile ? 20 : 0 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="mb-2 sm:mb-4 bg-red-50 p-2 sm:p-3 md:p-4 rounded-lg flex items-center justify-between">
              <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-red-700">Top Losers</h2>
              <Badge variant="destructive" className="text-xs sm:text-sm md:text-lg py-0 sm:py-1">
                <TrendingDown className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5 mr-1" />
                Falling
              </Badge>
            </div>
            <div className="border rounded-lg divide-y shadow-sm">
              {data.top_losers.map((stock) => (
                <StockRow key={stock.id} stock={stock} />
              ))}
            </div>
          </motion.div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IndustryPerformance;