import React, { useState, useEffect } from 'react';
import { ArrowDown, ArrowUp, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../Components/ui/Card";

function InfoItem({ label, value, isPositive }) {
  return (
    <div className="bg-gray-50 p-4 rounded-lg hover:bg-gray-100 transition-colors duration-200">
      <h3 className="text-sm font-medium text-gray-600 mb-1">{label}</h3>
      <p className={`text-lg font-semibold ${isPositive ? 'text-green-600' : ''}`}>{value}</p>
    </div>
  );
}

export default function KSE100Dashboard() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  '/api/kse100-index');
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('An error occurred'));
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="w-full h-60 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
        Error: {error.message}
      </div>
    );
  }

  if (!data) {
    return (
      <div className="w-full p-4 bg-gray-50 border border-gray-200 rounded-lg text-gray-700">
        No data available
      </div>
    );
  }

  const isPositiveChange = data.index_direction === 'up';

  // Determine the card styles based on screen size
  const getCardStyles = () => {
    // Mobile view
    if (windowWidth < 768) {
      return "w-full px-2";
    } 
    // Tablet view
    else if (windowWidth < 1024) {
      return "w-full md:w-5/6 mx-auto px-4";
    } 
    // Small desktop
    else if (windowWidth < 1280) {
      return "w-full  mx-auto px-4";
    } 
    // Default/larger desktop
    else {
      return "w-full   mx-auto";
    }
  };

  return (
    <div className="relative w-full flex justify-center">
      <Card className={getCardStyles()}>
        <CardHeader className="border-b border-gray-100 pb-4 md:pb-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
            <TrendingUp className="h-6 w-6 sm:h-8 sm:w-8 text-blue-600" />
            <div>
              <CardTitle className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900">KSE-100 Index Live</CardTitle>
              <CardDescription className="text-xs sm:text-sm text-gray-600 mt-1">
                Last Updated: {data.date}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-4 md:pt-6">
          <div className="mb-4 md:mb-8 p-3 md:p-6 bg-gray-50 rounded-xl">
            <div className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-2 md:mb-3">
              {data.index_value}
            </div>
            <div className={`flex items-center text-lg sm:text-xl ${isPositiveChange ? 'text-green-600' : 'text-red-600'}`}>
              {isPositiveChange ? (
                <ArrowUp className="mr-2 h-4 w-4 sm:h-6 sm:w-6" />
              ) : (
                <ArrowDown className="mr-2 h-4 w-4 sm:h-6 sm:w-6" />
              )}
              <span className="font-semibold">{data.index_change}</span>
              <span className="ml-2 text-gray-600 text-xs sm:text-sm md:text-base">
                ({((parseFloat(data.index_change) / parseFloat(data.previous_close)) * 100).toFixed(2)}%)
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3 md:gap-4">
            <InfoItem 
              label="Today's High" 
              value={data.high}
              isPositive={parseFloat(data.high) > parseFloat(data.previous_close)}
            />
            <InfoItem 
              label="Today's Low" 
              value={data.low}
            />
            <InfoItem 
              label="Trading Volume" 
              value={parseInt(data.volume).toLocaleString()}
            />
            <InfoItem 
              label="1 Year Change" 
              value={data.one_year_change}
              isPositive={parseFloat(data.one_year_change) > 0}
            />
            <InfoItem 
              label="YTD Change" 
              value={data.ytd_change}
              isPositive={parseFloat(data.ytd_change) > 0}
            />
            <InfoItem 
              label="Previous Close" 
              value={data.previous_close}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}