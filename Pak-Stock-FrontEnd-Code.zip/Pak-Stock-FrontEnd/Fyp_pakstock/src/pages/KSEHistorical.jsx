import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "../Components/ui/Card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const KSE100Historical = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedDuration, setSelectedDuration] = useState('W1'); 

  // Duration mapping
  const durationMap = {
    'D1': 1,    // 1 day
    'W1': 7,    // 1 week
    'M1': 30,   // 1 month
    'Y1': 365,  // 1 year
    'Y5': 1825, // 5 years
    'Y10': 3650, // 10 years
    'Y20': 7300, // 20 years
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const days = durationMap[selectedDuration];
        const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  `/api/kse100-historical?days=${days}`);
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const result = await response.json();
        const filteredData = result.filter(item => item.close !== 0);
        setData(filteredData.reverse());
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    fetchData();
  }, [selectedDuration]);

  const formatYAxis = (value) => {
    return (value / 1000).toFixed(0) + 'K';
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border rounded shadow-lg">
          <p className="font-medium text-gray-600">{label}</p>
          <p className="text-blue-600 font-bold">
            {payload[0].value.toFixed(2)}
          </p>
        </div>
      );
    }
    return null;
  };

  const DurationButton = ({ duration }) => (
    <button
      onClick={() => setSelectedDuration(duration)}
      className={`px-2 py-1 rounded-md text-sm font-medium transition-colors ${
        selectedDuration === duration
          ? 'bg-blue-600 text-white'
          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
      }`}
    >
      {duration}
    </button>
  );

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="h-96 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full">
        <CardContent className="p-4">
          <div className="bg-red-50 border border-red-200 rounded-lg text-red-700 p-4">
            Error: {error}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-col space-y-3 sm:flex-row sm:items-center sm:justify-between sm:space-y-0 p-4">
        <CardTitle className="text-xl sm:text-2xl font-bold text-gray-900">
          KSE-100 Index Historical Data
        </CardTitle>
        <div className="flex flex-wrap gap-2">
          <DurationButton duration="D1" />
          <DurationButton duration="W1" />
          <DurationButton duration="M1" />
          <DurationButton duration="Y1" />
          <DurationButton duration="Y5" />
          <DurationButton duration="Y10" />
          <DurationButton duration="Y20" />
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="h-64 sm:h-80 md:h-96 lg:h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{
                top: 5,
                right: 10,
                left: 0,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="date"
                tick={{ fill: '#6B7280', fontSize: '0.75rem' }}
                tickLine={{ stroke: '#6B7280' }}
                tickFormatter={(value) => {
                  // For smaller screens, show less x-axis labels
                  if (window.innerWidth < 640) {
                    // Logic to display fewer labels on small screens
                    return value.split('-').slice(1).join('/');
                  }
                  return value;
                }}
              />
              <YAxis
                tickFormatter={formatYAxis}
                domain={['auto', 'auto']}
                tick={{ fill: '#6B7280', fontSize: '0.75rem' }}
                tickLine={{ stroke: '#6B7280' }}
                width={40}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="close"
                stroke="#2563EB"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default KSE100Historical;