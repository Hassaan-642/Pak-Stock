import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "../Components/ui/Card";

export default function KSEAccuracy() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL + '/api/kse_accuracy');
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('An error occurred'));
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="w-full h-64 sm:h-80 md:h-96 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
        Error: {error.message}
      </div>
    );
  }

  if (!data) {
    return (
      <div className="w-full p-4 bg-gray-50 border border-gray-200 rounded-lg text-gray-700">
        No data available
      </div>
    );
  }

  return (
    <Card className="w-full mb-6">
      <CardHeader className="border-b border-gray-100 pb-4 sm:pb-6 p-4">
        <CardTitle className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900">
          KSE-100 Index Prediction Accuracy
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 sm:pt-6 p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* MAPE */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-600 mb-1">MAPE (%)</h3>
            <p className="text-lg font-semibold text-gray-900">{data.mape_in_percentage}%</p>
          </div>
          
          {/* Accuracy in Percentage */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-600 mb-1">Accuracy In Percentage (%)</h3>
            <p className="text-lg font-semibold text-gray-900">{data.accuracy_in_percentage}%</p>
          </div>
          
          {/* Record Date */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-600 mb-1">Record Date</h3>
            <p className="text-lg font-semibold text-gray-900">{data.record_date}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}