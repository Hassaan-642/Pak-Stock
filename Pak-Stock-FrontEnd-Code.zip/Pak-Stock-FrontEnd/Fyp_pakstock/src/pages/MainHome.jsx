import React, { useState, useEffect } from 'react';
import StockList from '../Components/Layout/StockList';
import KSE100Dashboard from './KSE100Dashboard';
import KSEPredictedChart from '../Components/Layout/KSEPredicted';
import IndustryPerformance from './IndustryGainLose';
import KSE100Historical from './KSEHistorical';
import ReccomendationAdvanced from './ReccomendationAdvanced';
import KSE_Accuracy from './KSE_Accuracy';
import DashboardSidebar from '../Components/Layout/DashboardSidebar';
import './Dashboard.css'
import HomepageSidebar from '../Components/Layout/HomePageSidebar';

function MainHome() {
  const [selectedIndustry, setSelectedIndustry] = useState("banking");
  const [isMobileView, setIsMobileView] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Handle responsive layout detection
  useEffect(() => {
    const handleResize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };
    
    // Set initial value
    handleResize();
    
    // Add event listener for window resize
    window.addEventListener('resize', handleResize);
    
    // Clean up
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleIndustrySelect = (industry) => {
    setSelectedIndustry(industry);
    
    // Close sidebar on selection in mobile view
    if (isMobileView && sidebarOpen) {
      setSidebarOpen(false);
    }
  };

  // Toggle sidebar in mobile view
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-gray-50">
      {/* Mobile menu button */}
      {isMobileView && (
        <button 
          onClick={toggleSidebar}
          className="fixed top-4 left-4 z-50 p-2 bg-blue-600 text-white rounded-md shadow-lg"
          aria-label="Toggle sidebar"
        >
          {sidebarOpen ? "✕" : "☰"}
        </button>
      )}

      {/* Sidebar - fixed on mobile when open, always visible on desktop */}
      <div 
       
      >
        <HomepageSidebar onToggle={toggleSidebar} isOpen={sidebarOpen}/>
      </div>

      {/* Main content */}
      <div className={`
        flex-1 w-full  dashboard-sections
        ${isMobileView ? 'px-2 sm:px-4 pb-6' : 'pl-0 pr-2 sm:pr-4 pb-6'}
        transition-all duration-300 ease-in-out
      `}>
        <div className="mt-4 sm:mt-6 md:mt-8 lg:mt-16 max-w-full mx-auto">
          <KSE100Dashboard onIndustrySelect={handleIndustrySelect} />
          
          <div className="mt-4 sm:mt-6 md:mt-8">
            <KSE100Historical />
          </div>
          
          <div className="mt-4 sm:mt-6 md:mt-8">
            <KSEPredictedChart />
          </div>
          
          <div className="mt-4 sm:mt-6 md:mt-8">
            <KSE_Accuracy />
          </div>
          
          <div className="mt-4 sm:mt-6 md:mt-8">
            <ReccomendationAdvanced />
          </div>
          
          <div className="mt-4 sm:mt-6 md:mt-8">
            <StockList onIndustrySelect={handleIndustrySelect} />
          </div>
          
          {selectedIndustry && (
            <div className="mt-4 sm:mt-6 md:mt-8">
              <IndustryPerformance industry={selectedIndustry} />
            </div>
          )}
        </div>
      </div>
      
      {/* Overlay for mobile sidebar backdrop */}
      {isMobileView && sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}
    </div>
  );
}

export default MainHome;