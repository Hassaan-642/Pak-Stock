import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "../Components/ui/Card";
import { Button } from "../Components/ui/Button";
import { 
  ChevronDown, 
  ChevronUp, 
  TrendingUp, 
  TrendingDown, 
  AlertCircle,
  Anchor,
  Waves 
} from 'lucide-react';

export default function RecommendationAdvancedTable() {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedRows, setExpandedRows] = useState({});

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch(process.env.REACT_APP_BACKEND_BASE_URL +  '/api/recommendationAdvanced');
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('An error occurred'));
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, []);

  const toggleRowExpand = (index, category) => {
    setExpandedRows(prev => ({
      ...prev,
      [`${index}_${category}`]: !prev[`${index}_${category}`]
    }));
  };

  const getStockCategoryConfig = (category) => {
    const configs = {
      'HotStocks': {
        icon: TrendingUp,
        color: 'green',
        label: 'Hot Stocks'
      },
      'ColdStocks': {
        icon: TrendingDown,
        color: 'red',
        label: 'Cold Stocks'
      },
      'NotVolatileStocks': {
        icon: Anchor,
        color: 'blue',
        label: 'Not Volatile Stocks'
      },
      'HighlyVolatileStocks': {
        icon: Waves,
        color: 'purple',
        label: 'Highly Volatile Stocks'
      }
    };
    return configs[category] || { icon: AlertCircle, color: 'gray', label: 'Unknown Stocks' };
  };

  const renderStockList = (stocks, category, index) => {
    if (!stocks) return 'N/A';
    
    const stockArray = stocks.split(',').map(stock => stock.trim());
    const displayCount = 3;
    const { icon: Icon, color, label } = getStockCategoryConfig(category);

    return (
      <div>
        {stockArray.slice(0, displayCount).map((stock, idx) => (
          <div 
            key={idx} 
            className={`
              flex items-center justify-between 
              px-2 sm:px-3 py-1 sm:py-2 rounded-md mb-2
              bg-${color}-50 text-${color}-800
              text-xs sm:text-sm
            `}
          >
            <span className="font-medium">{stock}</span>
            <Icon className={`text-${color}-600`} size={16} />
          </div>
        ))}
        {stockArray.length > displayCount && (
          <Button 
            variant="outline" 
            className="w-full mt-2 text-xs sm:text-sm text-gray-600 hover:bg-gray-100 py-1"
            onClick={() => toggleRowExpand(index, category)}
          >
            {expandedRows[`${index}_${category}`] 
              ? 'Show Less' 
              : `See All ${stockArray.length} ${label}`}
          </Button>
        )}
      </div>
    );
  };

  const renderExpandedStocks = (stocks, category) => {
    if (!stocks) return null;
    const stockArray = stocks.split(',').map(stock => stock.trim());
    const { icon: Icon, color } = getStockCategoryConfig(category);
    
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 mt-4">
        {stockArray.map((stock, idx) => (
          <div 
            key={idx} 
            className={`
              flex items-center justify-between 
              px-2 sm:px-3 py-1 sm:py-2 rounded-md
              bg-${color}-50 text-${color}-800
              text-xs sm:text-sm
            `}
          >
            <span className="font-medium">{stock}</span>
            <Icon className={`text-${color}-600`} size={16} />
          </div>
        ))}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="w-full h-64 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="w-full">
        <CardContent className="p-4">
          <div className="bg-red-50 border border-red-200 rounded-lg text-red-700 p-4">
            Error: {error.message}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data || data.length === 0) {
    return (
      <Card className="w-full">
        <CardContent className="p-4">
          <div className="bg-gray-50 border border-gray-200 rounded-lg text-gray-700 p-4">
            No recommendations available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full shadow-lg">
      <CardHeader className="border-b border-gray-100 pb-4 sm:pb-6 bg-gray-50 p-4">
        <CardTitle className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 flex items-center">
          <TrendingUp className="mr-2 sm:mr-3 text-green-600" size={24} />
          Stock Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 sm:space-y-6 overflow-hidden py-4 px-3 sm:px-4">
        {data.map((row, index) => (
          <div 
            key={index} 
            className="bg-white p-3 sm:p-4 md:p-6 rounded-lg shadow-md border border-gray-100 transition-all duration-300 hover:shadow-lg"
          >
            <div>
              <h3 className="text-xs sm:text-sm font-medium text-gray-600 mb-1">Record Date</h3>
              <p className="text-base sm:text-lg font-semibold text-gray-900 mb-3">{row.calculated_on}</p>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {['HotStocks', 'ColdStocks'].map((category) => {
                  const { icon: Icon, color, label } = getStockCategoryConfig(category);
                  return (
                    <div key={category}>
                      <h3 className={`text-xs sm:text-sm font-medium text-${color}-600 mb-2 flex items-center`}>
                        <Icon className={`mr-1 sm:mr-2 text-${color}-600`} size={16} />
                        {label}
                      </h3>
                      {renderStockList(row[category], category, index)}
                      {expandedRows[`${index}_${category}`] && renderExpandedStocks(row[category], category)}
                    </div>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {['NotVolatileStocks', 'HighlyVolatileStocks'].map((category) => {
                  const { icon: Icon, color, label } = getStockCategoryConfig(category);
                  return (
                    <div key={category}>
                      <h3 className={`text-xs sm:text-sm font-medium text-${color}-600 mb-2 flex items-center`}>
                        <Icon className={`mr-1 sm:mr-2 text-${color}-600`} size={16} />
                        {label}
                      </h3>
                      {renderStockList(row[category], category, index)}
                      {expandedRows[`${index}_${category}`] && renderExpandedStocks(row[category], category)}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}