import React, { useState, useEffect } from 'react';
import { X, TrendingUp, DollarSign, PieChart, MessageCircleReply } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getAuth, onAuthStateChanged } from 'firebase/auth';

const TimedPopup = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    const auth = getAuth();
    // Set up auth state listener
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthChecked(true);
    });

    // Only set up timers if user is not authenticated
    let initialTimer;
    let recurringTimer;

    if (!user) {
      const showPopup = () => {
        setIsOpen(true);
      };

      // Show popup initially after 60 seconds
      initialTimer = setTimeout(showPopup, 60000);
      
      // Set up recurring timer to show popup every 5 minutes
      recurringTimer = setInterval(showPopup, 60000);
    }

    // Cleanup function
    return () => {
      unsubscribe();
      if (initialTimer) clearTimeout(initialTimer);
      if (recurringTimer) clearInterval(recurringTimer);
    };
  }, [user]);

  const closePopup = () => {
    setIsOpen(false);
  };

  // Don't render anything if user is authenticated, auth hasn't been checked, or popup is closed
  if (!authChecked || user || !isOpen) return null;

  return (
    <div className="fixed inset-0 backdrop-blur-md backdrop-brightness-50 flex items-center justify-center p-4 z-50">
      <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-8 rounded-xl shadow-2xl max-w-4xl w-full h-[70vh] flex flex-col text-white relative overflow-hidden">
        <button onClick={closePopup} className="absolute top-4 right-4 text-white hover:text-gray-200 transition-colors">
          <X size={24} />
        </button>
       
        <h2 className="text-4xl font-bold mb-6 text-center">Unlock the Power of Smart Investing</h2>
       
        <div className="flex-grow flex flex-col md:flex-row items-center justify-around mb-8">
          <Feature
            icon={<TrendingUp size={48} />}
            title="Real-time Analytics"
            description="Stay ahead with our cutting-edge stock tracking tools"
          />
          <Feature
            icon={<DollarSign size={48} />}
            title="Recommendation"
            description="Maximize your returns with AI-driven detail recommendations "
          />
          <Feature
            icon={<MessageCircleReply size={48} />}
            title="Connect with Community"
            description="Provide way to discuss with real world and Connect with Brokers"
          />
        </div>
       
        <p className="text-lg text-center mb-8">
          Join thousands of successful investors who have taken control of their financial future.
          Don't miss out on potential opportunities - start your journey today!
        </p>
       
        <button className="bg-white text-blue-600 hover:bg-blue-100 transition-colors duration-300 font-bold py-3 px-8 rounded-full text-xl shadow-lg mx-auto block">
          <Link to='/login'>Join Free Now</Link>
        </button>
      </div>
    </div>
  );
};

const Feature = ({ icon, title, description }) => (
  <div className="flex flex-col items-center text-center mb-6 md:mb-0 px-4">
    <div className="mb-4 text-yellow-300">{icon}</div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-sm opacity-80">{description}</p>
  </div>
);

export default TimedPopup;