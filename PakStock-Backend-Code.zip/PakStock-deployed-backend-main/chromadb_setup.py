from database.vector_db_procedures import create_chromadb_collection, insert_chromadb_collection, query_collection
import json

create_chromadb_collection()
insert_chromadb_collection()

response = query_collection("What is pakstock?") 

print(json.dumps(response, indent=4))