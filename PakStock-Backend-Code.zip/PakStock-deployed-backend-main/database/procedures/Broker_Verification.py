from database.schemas.broker_verification import BrokerVerification
from peewee import IntegrityError
from fastapi import HTTPException
from utility.datetime_utils import getNowTime

# POST: Create Broker Verification Entry
def create_broker_verification(
    user_id,
    email,
    legal_name,
    license_number,
    brokerage_type,
    registration_number,
    office_address,
    contact_phone,
    professional_email,
    website_url,
    secp_registration_details,
    aml_compliance_details,
    kyc_procedures_details,
    capital_adequacy_ratio_details,
    financial_statements_details,
    trading_platforms_details,
    trading_tools_details,
    secp_license_details,
    iso_certification_details=None,
    other_certifications=None,
    investment_products=None,
    fee_structure_details=None,
    client_testimonials=None,
    security_measures=None,
    privacy_policy_details=None,
    verification_date=None,
    verification_notes=None
):
    try:
        # Check if email or uid already exists
        if BrokerVerification.select().where(
            (BrokerVerification.email == email) | 
            (BrokerVerification.user_id == user_id)
        ).exists():
            raise IntegrityError("Broker registeration request with this email or user ID already exists.")

        # Check if license_number or registration_number already exists
        if BrokerVerification.select().where(
            (BrokerVerification.license_number == license_number) | 
            (BrokerVerification.registration_number == registration_number) |
            (BrokerVerification.legal_name == legal_name)
        ).exists():
            raise IntegrityError("Broker registeration request with this license, registration number or name already exists.")
        
        # Create new broker verification record
        BrokerVerification.create(
            user_id=user_id,
            email=email,
            legal_name=legal_name,
            license_number=license_number,
            brokerage_type=brokerage_type,
            registration_number=registration_number,
            office_address=office_address,
            contact_phone=contact_phone,
            professional_email=professional_email,
            website_url=website_url,
            secp_registration_details=secp_registration_details,
            aml_compliance_details=aml_compliance_details,
            kyc_procedures_details=kyc_procedures_details,
            capital_adequacy_ratio_details=capital_adequacy_ratio_details,
            financial_statements_details=financial_statements_details,
            trading_platforms_details=trading_platforms_details,
            trading_tools_details=trading_tools_details,
            secp_license_details=secp_license_details,
            iso_certification_details=iso_certification_details,
            other_certifications=other_certifications,
            investment_products=investment_products,
            fee_structure_details=fee_structure_details,
            client_testimonials=client_testimonials,
            security_measures=security_measures,
            privacy_policy_details=privacy_policy_details,
            verification_status='Pending',  # Explicitly set; can be omitted if model has default
            verification_date=verification_date,
            verification_notes=verification_notes
        )
        
        return {
            "status": "success"}

    except IntegrityError as e:
        print("IntegrityError in create_broker_verification:", e)
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        print("Exception in create_broker_verification:", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

def get_all_broker_verifications():
    import traceback
    from datetime import datetime
    
    try:
        print(f"\n[{datetime.now()}] === STARTING get_all_broker_verifications ===")
        
        # Step 1: Check if model is imported correctly
        print("Step 1: Checking BrokerVerification model...")
        try:
            print(f"✓ Model class: {BrokerVerification}")
            print(f"✓ Model table name: {BrokerVerification._meta.table_name}")
        except Exception as model_error:
            print(f"✗ Model check failed: {model_error}")
            raise Exception(f"Model import error: {model_error}")
        
        # Step 2: Check database connection
        print("Step 2: Testing database connection...")
        try:
            db = BrokerVerification._meta.database
            if not db.is_connection_usable():
                db.connect()
            print("✓ Database connection successful")
        except Exception as db_error:
            print(f"✗ Database connection failed: {db_error}")
            raise Exception(f"Database connection error: {db_error}")
        
        # Step 3: Check if table exists
        print("Step 3: Checking if table exists...")
        try:
            if not BrokerVerification.table_exists():
                print("✗ BrokerVerification table does not exist")
                raise Exception("BrokerVerification table not found in database")
            print("✓ Table exists")
        except Exception as table_error:
            print(f"✗ Table check failed: {table_error}")
            raise Exception(f"Table existence error: {table_error}")
        
        # Step 4: Get record count
        print("Step 4: Checking record count...")
        try:
            count = BrokerVerification.select().count()
            print(f"✓ Found {count} records in table")
            if count == 0:
                print("⚠️  Table is empty - returning empty list")
                return []
        except Exception as count_error:
            print(f"✗ Count query failed: {count_error}")
            raise Exception(f"Count query error: {count_error}")
        
        # Step 5: Fetch data
        print("Step 5: Fetching broker verifications...")
        try:
            verifications = BrokerVerification.select()
            print(f"✓ Query executed successfully")
        except Exception as select_error:
            print(f"✗ Select query failed: {select_error}")
            raise Exception(f"Select query error: {select_error}")
        
        # Step 6: Process records
        print("Step 6: Processing records...")
        result = []
        processed_count = 0
        
        for i, verification in enumerate(verifications):
            try:
                print(f"Processing record {i+1}...")
                
                # Check if verification object is valid
                if verification is None:
                    print(f"⚠️  Record {i+1} is None, skipping...")
                    continue
                
                record_dict = {}
                
                # Process each field with individual error handling
                try:
                    record_dict['user_id'] = getattr(verification, 'user_id', None)
                    record_dict['email'] = getattr(verification, 'email', None)
                except Exception as field_error:
                    print(f"⚠️  Error getting primary fields for record {i+1}: {field_error}")
                    record_dict['user_id'] = "ERROR"
                    record_dict['email'] = "ERROR"
                
                # Handle datetime fields with extra safety
                try:
                    submission_date = getattr(verification, 'submission_date', None)
                    if submission_date and hasattr(submission_date, 'isoformat'):
                        record_dict['submission_date'] = submission_date.isoformat()
                    else:
                        record_dict['submission_date'] = str(submission_date) if submission_date else None
                except Exception as date_error:
                    print(f"⚠️  Error processing submission_date for record {i+1}: {date_error}")
                    record_dict['submission_date'] = None
                
                try:
                    verification_date = getattr(verification, 'verification_date', None)
                    if verification_date and hasattr(verification_date, 'isoformat'):
                        record_dict['verification_date'] = verification_date.isoformat()
                    else:
                        record_dict['verification_date'] = str(verification_date) if verification_date else None
                except Exception as date_error:
                    print(f"⚠️  Error processing verification_date for record {i+1}: {date_error}")
                    record_dict['verification_date'] = None
                
                # Process all other fields safely
                field_mapping = {
                    'verification_status': 'verification_status',
                    'verification_notes': 'verification_notes',
                    'legal_name': 'legal_name',
                    'license_number': 'license_number',
                    'brokerage_type': 'brokerage_type',
                    'registration_number': 'registration_number',
                    'office_address': 'office_address',
                    'contact_phone': 'contact_phone',
                    'professional_email': 'professional_email',
                    'website_url': 'website_url',
                    'secp_registration_details': 'secp_registration_details',
                    'aml_compliance_details': 'aml_compliance_details',
                    'kyc_procedures_details': 'kyc_procedures_details',
                    'capital_adequacy_ratio_details': 'capital_adequacy_ratio_details',
                    'financial_statements_details': 'financial_statements_details',
                    'trading_platforms_details': 'trading_platforms_details',
                    'trading_tools_details': 'trading_tools_details',
                    'secp_license_details': 'secp_license_details',
                    'iso_certification_details': 'iso_certification_details',
                    'other_certifications': 'other_certifications',
                    'investment_products': 'investment_products',
                    'fee_structure_details': 'fee_structure_details',
                    'client_testimonials': 'client_testimonials',
                    'security_measures': 'security_measures',
                    'privacy_policy_details': 'privacy_policy_details'
                }
                
                for dict_key, model_field in field_mapping.items():
                    try:
                        value = getattr(verification, model_field, None)
                        # Ensure value is JSON serializable
                        if value is not None:
                            record_dict[dict_key] = str(value)
                        else:
                            record_dict[dict_key] = None
                    except Exception as field_error:
                        print(f"⚠️  Error processing field '{model_field}' for record {i+1}: {field_error}")
                        record_dict[dict_key] = None
                
                result.append(record_dict)
                processed_count += 1
                print(f"✓ Successfully processed record {i+1}")
                
            except Exception as record_error:
                print(f"✗ Error processing record {i+1}: {record_error}")
                print(f"Record error traceback:")
                traceback.print_exc()
                # Add a placeholder for failed records
                result.append({
                    'user_id': f"ERROR_RECORD_{i+1}",
                    'email': "PROCESSING_ERROR",
                    'error': str(record_error)
                })
        
        print(f"✓ Successfully processed {processed_count} out of {count} records")
        print(f"[{datetime.now()}] === COMPLETED get_all_broker_verifications ===\n")
        
        return result
        
    except Exception as e:
        print(f"\n[{datetime.now()}] === CRITICAL ERROR in get_all_broker_verifications ===")
        print(f"Error Type: {type(e).__name__}")
        print(f"Error Message: {str(e)}")
        print("Full Traceback:")
        traceback.print_exc()
        print("=" * 60)
        
        # Return more specific error information
        error_detail = f"Database error: {type(e).__name__}: {str(e)}"
        raise HTTPException(status_code=500, detail=error_detail)
    
def update_broker_verification_status(user_id, email, status, verification_date=getNowTime(), verification_notes=None):
    try:
        # Fetch the broker verification record
        broker_verification = BrokerVerification.get(
            (BrokerVerification.user_id == user_id) & 
            (BrokerVerification.email == email)
        )
        
        # Update the status and other fields
        broker_verification.verification_status = status
        broker_verification.verification_date = verification_date
        broker_verification.verification_notes = verification_notes
        
        # Save the changes
        broker_verification.save()
        
        return {
            "status": "success",
            "message": "Broker verification status updated successfully.",
            "data": {
                "user_id": broker_verification.user_id,
                "email": broker_verification.email,
                "verification_status": broker_verification.verification_status,
                "verification_date": broker_verification.verification_date,
                "verification_notes": broker_verification.verification_notes
            }
        }

    except BrokerVerification.DoesNotExist:
        raise HTTPException(status_code=404, detail="No broker registeration record with the provided user_id and email exists.")
    
    except Exception as e:
        print("Exception in update_broker_verification_status:", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")