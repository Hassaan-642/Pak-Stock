from datetime import datetime, date, time, timedelta
from fastapi import HTTPException
from database.schemas.live_historical_data import LiveHistoricalData

def get_Day_To_Day_Trading(stock_name: str):
    try:
        search_date = date.today()

        while True:
            start_time = datetime.combine(search_date, time(9, 0, 0))
            end_time = datetime.combine(search_date, time(23, 59, 59))

            # Query data for the given date
            results = (
                LiveHistoricalData.select()
                .where(
                    (LiveHistoricalData.stock_name == stock_name) & 
                    (LiveHistoricalData.TIME >= start_time) & 
                    (LiveHistoricalData.TIME <= end_time)
                )
                .order_by(LiveHistoricalData.TIME.asc())
            )

            data = []
            for result in results:
                data.append({
                    'TIME': result.TIME.strftime('%Y-%m-%d %H:%M:%S'),
                    'OPEN': result.OPEN,
                    'HIGH': result.HIGH,
                    'LOW': result.LOW,
                    'CLOSE': result.CLOSE,
                    'VOLUME': result.VOLUME,
                    'stock_name': result.stock_name
                })

            # If data is found, return it; otherwise, check the previous day
            if data:
                return data
            
            search_date -= timedelta(days=1)  # Move to the previous day

    except Exception as e:
        print(f"Error in get_Day_To_Day_Trading: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
