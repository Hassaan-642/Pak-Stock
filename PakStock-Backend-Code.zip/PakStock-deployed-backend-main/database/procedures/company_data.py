from database.schemas.company_data import CompanyInfo 
from fastapi import HTTPException

# Will retrieve the company information for a given stock symbol
def get_company_info(stock_symbol: str):
    try:
        # Query the company info for the given stock symbol
        result = CompanyInfo.get(CompanyInfo.stock_name.contains(stock_symbol))
        # print(len(result))

        # Map the result to a dictionary
        company_info_data = {
            'company_information': result.company_information,
            'ceo_name': result.ceo_name,
            'chairperson_name': result.chairperson_name,
            'company_secretary_name': result.company_secretary_name,
            'address': result.address,
            'website': result.website,
            'registrar': result.registrar,
            'auditor': result.auditor,
            'fiscal_year_end': result.fiscal_year_end,
            'market_cap': result.market_cap,
            'shares': result.shares,
            'free_float_of_shares': result.free_float_of_shares,
            'free_float_percentage': result.free_float_percentage,
            'stock_name': result.stock_name
        }

        return company_info_data
    
    except CompanyInfo.DoesNotExist:
        raise HTTPException(status_code=404, detail="Company not found")
    except Exception as e:
        print(f"Error get_company_info: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
