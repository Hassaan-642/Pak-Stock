from database.schemas.dividendData import DividendData
from fastapi import HTTPException
from utility.datetime_utils import *  # If any utility is needed
import traceback

def get_dividend_data(stock_symbol: str):
    try:
        # Modify the query to only filter by stock symbol
        result = DividendData.select().where(DividendData.stock_symbol == stock_symbol).first()  # Use .first() to get the first record

        # If no record is found, raise an HTTP 404 error
        if not result:
            raise HTTPException(
                status_code=404, detail=f"No dividend data found for stock symbol: {stock_symbol}"
            )

        # Collect the required fields from the result
        row_data = {
            "dividend_amount": result.dividend_amount,
            "dividend_yield": result.dividend_yield,
            "last_ex_date": result.last_ex_date,
            "last_pay_date": result.last_pay_date,
        }

        return row_data

    except HTTPException as http_exc:
        # Re-raise the HTTP exception if one is caught
        print(f"HTTP Exception in get_dividend_data: {http_exc}")
        raise http_exc

    except Exception as e:
        # Print error message and raise HTTP 500 internal server error for other exceptions
        print(f"Error in get_dividend_data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error nahi hai")
    finally:
        traceback.print_exc()