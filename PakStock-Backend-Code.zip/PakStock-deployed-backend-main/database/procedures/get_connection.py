import peewee
import os
from dotenv import load_dotenv

load_dotenv('.env')

def get_conn():
    print("OS getenv JAWAD_AZURE_DATABASE: ", os.getenv("JAWAD_AZURE_DATABASE"))
    try:
        # Database connection
        db = peewee.MySQLDatabase(
            database=os.getenv("JAWAD_AZURE_DATABASE"),
            host=os.getenv("JAWAD_AZURE_HOSTNAME"),
            port=int(os.getenv("JAWAD_AZURE_PORT")),  # Ensure port is an integer
            user=os.getenv("JAWAD_AZURE_USERNAME"),    # Use os.getenv for username
            password=os.getenv("JAWAD_AZURE_PASSWORD"), # Correct parameter name for password
            autocommit=True,                     # Enable autocommit if needed
            ssl={
                'ca': os.getenv("AZURE_SSL_CERT_PATH")  # Path to CA file
            }
        )

        return db

    except Exception as e:
        print("Error in get_conn: ", e)
        raise e