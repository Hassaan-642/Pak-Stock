from database.schemas.historical_data import HistoricalData
from utility.datetime_utils import *
from fastapi import HTTPException

# Will retrieve the historical data of the past N days
def get_historical_data(stock_symbol: str, days: int):
    try:
        current_date = get_N_days_ago_date(0)
        N_days_ago = get_N_days_ago_date(days)

        # Query the data where TIME is between N_days_ago and current_date
        results = (
            HistoricalData.select()
            .where((HistoricalData.TIME >= N_days_ago) & (HistoricalData.TIME <= current_date) & (HistoricalData.stock_name == stock_symbol)))

        data = []
        for row in results:
            row_data = {
                'TIME': row.TIME,
                'OPEN': row.OPEN,
                'CLOSE': row.CLOSE,
                'VOLUME': row.VOLUME,
                'HIGH': row.HIGH,
                'LOW': row.LOW
            }
            data.append(row_data)

        return data
    
    except Exception as e:
        print(f"Error get_historical_data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
