import peewee
from database.schemas.historicalKSE100index import HistoricalKSE100Index
from utility.datetime_utils import get_N_days_ago_date

def get_historical_kse100_data(days: int):
    """
    Get historical KSE100 data
    """
    N_days_ago = get_N_days_ago_date(days)
    historical_kse100_data = list(HistoricalKSE100Index.select().where(HistoricalKSE100Index.date >= N_days_ago).order_by(HistoricalKSE100Index.date.desc()).dicts())
    return historical_kse100_data