from database.schemas.kse100index import KSE100Index
from utility.datetime_utils import *
from fastapi import HTTPException
import datetime

def get_latest_kse100_index_data():
    try:
        result = (
            KSE100Index.select()
            .order_by(KSE100Index.date.desc())
            .dicts()
            .first()
        )

        print("Result: ", result)

        result['date'] = result['date'].strftime('%Y-%m-%d %H:%M:%S')

        return result
    
    except Exception as e:
        print(f"Error in get_kse100_index_data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
