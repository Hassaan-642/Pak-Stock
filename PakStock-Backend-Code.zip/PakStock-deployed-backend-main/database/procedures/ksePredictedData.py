from database.schemas.ksePredictedData import PredictedKSE100Index
from fastapi import HTTPException
from datetime import datetime
from peewee import fn

# Retrieve all predicted KSE 100 Index data starting from today without duplicates
def get_all_predicted_data():
    try:
        # Get today's date in 'YYYY-MM-DD' format
        today_date = datetime.today().strftime('%Y-%m-%d')

        # Query the database for rows with a date >= today's date
        results = (
            PredictedKSE100Index
            .select(
                PredictedKSE100Index.date,
                PredictedKSE100Index.close
            )
            .where(PredictedKSE100Index.date >= today_date)
            #.distinct()  # Ensure duplicates are removed
            #.order_by(PredictedKSE100Index.date)  # Optional: Order results by date
        )

        # Map the results to a list of dictionaries
        predicted_index_data = [
            {
                'date': record.date,
                'close': float(record.close)
            }
            for record in results
        ]

        return predicted_index_data

    except Exception as e:
        print(f"Error get_all_predicted_data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    
