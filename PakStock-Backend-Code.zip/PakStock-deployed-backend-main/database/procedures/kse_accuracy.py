from database.schemas.kse_accuracy import kse_accuracy  # Import the schema for kse_accuracy table
from fastapi import HTTPException
import traceback

def get_kse_accuracy_data():
    try:
        # Fetch only the latest record from the kse_accuracy table
        latest_result = (kse_accuracy
                         .select()
                         .order_by(kse_accuracy.record_date.desc())  # Order by record_date (latest first)
                         .first())  # Fetch only the most recent record

        # If no records are found, raise an HTTP 404 error
        if not latest_result:
            raise HTTPException(status_code=404, detail="No data found in the kse_accuracy table")

        # Return the latest record
        return {
            "mape_in_percentage": latest_result.mape_in_percentage,
            "accuracy_in_percentage": latest_result.accuracy_in_percentage,
            "record_date": latest_result.record_date,
        }

    except HTTPException as http_exc:
        print(f"HTTP Exception in get_latest_kse_accuracy_data: {http_exc}")
        raise http_exc

    except Exception as e:
        print(f"Error in get_latest_kse_accuracy_data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error nahi hai")
    finally:
        traceback.print_exc()