from database.schemas.live_company_data import LiveCompanyData
from utility.datetime_utils import *
from fastapi import HTTPException
import datetime

# Function to retrieve live company data based on provided time
def get_live_company_data(company: str):
    try:
        result = (
            LiveCompanyData.select()
            .where((LiveCompanyData.company == company))
            .order_by(LiveCompanyData.time.desc())
            .first()
        )

        # Collect the result data
        row_data = {
            'id': result.id,
            'company': result.company,
            'time': result.time.strftime('%Y-%m-%d %H:%M:%S'),  # Keep seconds in the output
            'close_quote': result.close_quote,
            'change_direction': result.change_direction,
            'change_value': result.change_value,
            'change_percentage': result.change_percentage,
            'market_cap': result.market_cap,
            'shares': result.shares,
            'free_float_volume': result.free_float_volume,
            'free_float_percentage': result.free_float_percentage,
        }

        return row_data
    
    except Exception as e:
        print(f"Error in get_live_company_data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
