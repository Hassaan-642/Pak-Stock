from database.schemas.live_historical_data import LiveHistoricalData
from utility.datetime_utils import *
from fastapi import HTTPException
import datetime

# Function to retrieve live historical data based on provided time and stock name
def get_live_historical_data(stock_name: str):
    try:
        # Query the data from live_historical_data where TIME falls within the specified hour and stock_name matches
        result = (
            LiveHistoricalData.select()
            .where((LiveHistoricalData.stock_name == stock_name))
            .order_by(LiveHistoricalData.TIME.desc())
            .first()
        )

        # Collect the result data
        data = []
        row_data = {
            'TIME': result.TIME.strftime('%Y-%m-%d %H:%M:%S'),  # Keep seconds in the output
            'OPEN': result.OPEN,
            'HIGH': result.HIGH,
            'LOW': result.LOW,
            'CLOSE': result.CLOSE,
            'VOLUME': result.VOLUME,
            'stock_name': result.stock_name
        }
        data.append(row_data)

        return data

    except Exception as e:
        print(f"Error in get_live_historical_data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
