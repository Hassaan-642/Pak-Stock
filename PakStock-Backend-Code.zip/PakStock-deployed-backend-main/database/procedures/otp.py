from database.schemas.otp import OTP
from datetime import datetime, timedelta
from utility.datetime_utils import getNowTime
import os
from fastapi import HTTPException
from peewee import DoesNotExist

otp_expiration_time_in_minutes = int(os.getenv("OTP_EXP_DELTA_SECONDS")) / 60

def create_otp(user, otp_code, purpose):
    try:
        # Query the latest OTP for the user and purpose
        latest_otp = OTP.select().where(
            (OTP.user == user) & 
            (OTP.purpose == purpose)
        ).order_by(OTP.created_at.desc()).first()

        # Check if an OTP exists and whether it has expired
        if latest_otp:
            now = getNowTime()

            # If the current time is before the OTP's expiration time, prevent new OTP creation
            if now < latest_otp.expires_at and not latest_otp.is_used:
                raise HTTPException(status_code=400, detail="An active OTP already exists for this user.")

        # If no valid OTP exists or it has expired, create a new one
        expiration_time = getNowTime() + timedelta(minutes=otp_expiration_time_in_minutes)
        print("Now: ", datetime.now())
        print("Expiration time: ", expiration_time)
        
        new_otp = OTP.create(
            user=user, 
            otp_code=otp_code, 
            purpose=purpose, 
            created_at=getNowTime(),
            expires_at=expiration_time,
            is_used=False
        )

        return new_otp.otp_code

    except Exception as e:
        print("Error in create_otp: ", e)
        raise e

def validate_otp(user_id: str, otp_code: str, purpose: str) -> bool:
    """
    Validate the OTP against the database.
    """
    try:
        otp_record = OTP.select().where(
            (OTP.user == user_id) &
            (OTP.purpose == purpose) &
            (OTP.otp_code == otp_code)
        ).get()

        print("OTP record: ", otp_record)

        # Check if the OTP exists and is not expired
        if not otp_record:
            raise HTTPException(status_code=400, detail="Invalid OTP.")
        
        if otp_record and otp_record.expires_at > getNowTime():
            otp_record.is_used = True
            otp_record.save()
            return True
        
        raise HTTPException(status_code=400, detail="OTP has expired.")
    except OTP.DoesNotExist as e:
        # Handle the case where no matching record is found
        print("No OTP record found matching the query.")
        raise HTTPException(status_code=400, detail="Invalid OTP.")
    except Exception as e:
        print("Error in validate_otp: ", e)
        raise e