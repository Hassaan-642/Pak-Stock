from database.schemas.predicted_data import PredictedDataKMeansLinearRegression, PredictedDataRandomForestRegressor
from utility.datetime_utils import *
from fastapi import HTTPException

# Will retrieve the predicted data of the past N days from a specified model
def get_predicted_data(stock_symbol: str, days: int, model_type: str):
    try:
        # Get the current date and calculate N days after the current date
        current_date = get_N_days_ago_date(0)
        N_days_after = get_N_days_after_date(days)

        # Choose the correct model based on the model_type parameter
        if model_type == "KMeansLinearRegression":
            Model = PredictedDataKMeansLinearRegression
        elif model_type == "RandomForestRegressor":
            Model = PredictedDataRandomForestRegressor
        else:
            raise HTTPException(status_code=400, detail="Invalid model type provided")

        # Query the data from the selected model where TIME is between current_date and N_days_after
        results = (
            Model.select()
            .where((Model.TIME >= current_date) & (Model.TIME <= N_days_after) & (Model.stock_name == stock_symbol))
        )

        # Collect the result data
        data = []
        for row in results:
            row_data = {
                'TIME': row.TIME,
                'CLOSE': row.CLOSE,
            }
            data.append(row_data)

        return data
    
    except Exception as e:
        print(f"Error in get_predicted_data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
