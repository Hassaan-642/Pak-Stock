from fastapi import HTTPException
from playhouse.shortcuts import model_to_dict
from database.schemas.processed_articles import ProcessedArticle
from utility.datetime_utils import get_N_days_ago_date
from peewee import fn, Case

# Function to get all processed articles
def get_all_processed():
    try:
        rows = ProcessedArticle.select()  # Select all records from ProcessedArticle
        return [model_to_dict(row) for row in rows]  # Convert to dictionary format
    except Exception as e:
        print(f"Database error get_all_processed: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

# Function to get processed articles by keyword and date
def get_processed_articles_by_industry_and_date(industry: str, days: int):
    try:
        print("In get_processed_articles_by_keyword_and_date")
        date = get_N_days_ago_date(days)  # Get the date N days ago
        print("Date:", date)
        # print("Hello")
        rows = list(ProcessedArticle
                .select()
                .where(
                    (ProcessedArticle.keyword == industry) & 
                    (ProcessedArticle.publish_date >= date)
                ))
        # print("Type:", type(rows))
        json_objects = [model_to_dict(row) for row in rows]  # Convert to dictionary format
        
        # Format publish_date to string
        for obj in json_objects:
            if 'publish_date' in obj:
                obj['publish_date'] = obj['publish_date'].strftime('%Y-%m-%d')
                
        return json_objects
    except Exception as e:
        print(f"Error in get_processed_articles_by_keyword_and_date: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

def get_processed_articles_by_industry_and_date_count(industry: str, days: int):
    try:
        date = get_N_days_ago_date(days)

        query = (ProcessedArticle
                 .select(
                     ProcessedArticle.model,
                     fn.COUNT(Case(None, [(ProcessedArticle.label == 'Positive', 1)])).alias('positive_count'),
                     fn.COUNT(Case(None, [(ProcessedArticle.label == 'Negative', 1)])).alias('negative_count'),
                     fn.COUNT(Case(None, [(ProcessedArticle.label == 'Neutral', 1)])).alias('neutral_count')
                 )
                 .where(
                     (ProcessedArticle.keyword == industry) &
                     (ProcessedArticle.publish_date >= date)
                 )
                 .group_by(ProcessedArticle.model))

        return list(query.dicts())

    except Exception as e:
        print(f"Error in get_processed_articles_by_industry_and_date_count: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")