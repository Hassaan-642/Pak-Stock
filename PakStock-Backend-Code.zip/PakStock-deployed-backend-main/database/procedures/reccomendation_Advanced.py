from database.schemas.reccomendation_advanced import RecommendationAdvanced
from utility.datetime_utils import getNowTime
from dotenv import load_dotenv
import os

def get_recommendation_advanced_by_date():
    try:
        print("Fetching the latest available recommendation advanced data...")

        # Fetch the most recent entry based on calculated_on date
        query = (
            RecommendationAdvanced
            .select()
            .order_by(RecommendationAdvanced.calculated_on.desc())  # Sort by date (latest first)
            .limit(1)  # Fetch only the latest entry
        )

        data = list(query.dicts().execute())  # Convert result to dictionary list

        if data:
            print("Fetched latest recommendation advanced data successfully.")
        else:
            print("No recommendation advanced data found.")

        return data
    except Exception as e:
        print("Error fetching recommendation advanced data:", e)
        raise e
