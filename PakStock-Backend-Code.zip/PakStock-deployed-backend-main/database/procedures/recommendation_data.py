from database.schemas.recommendation_data import RecommendationDataDetailed
from utility.datetime_utils import *
from datetime import timedelta
from dotenv import load_dotenv
import os

load_dotenv('.env')
recommendation_dataframe_size = int(os.getenv("RECOMMENDATION_DATAFRAME_SIZE"))



# n = RECOMMENDATION_DATAFRAME_SIZE, defined in .env
def get_recommendation_detailed_data_n_days(symbol):
    # print("In get_recommendation_detailed_data_n_days")
    try:
        start_date = (getNowTime() - timedelta(days=recommendation_dataframe_size)).strftime('%Y-%m-%d')
        print("start_date: ", start_date)
        query = RecommendationDataDetailed.select().where(
            (RecommendationDataDetailed.time >= start_date) & 
            (RecommendationDataDetailed.stock_symbol == symbol)
        )
        data = list(query.dicts().execute())
        print("Here3")
        return data
    except Exception as e:
        print("Error in get_recommendation_detailed_data: ", e)
        raise e