from database.schemas.stock_accuracy import StockAccuracyResults  # Update the import path as needed 
from fastapi import HTTPException

# Retrieve accuracy results for a specific stock symbol
def get_stock_accuracy_by_symbol(stock_symbol: str):
    try:
        # Query the table for all records matching the provided stock symbol
        latest_result = (StockAccuracyResults
                         .select()
                         .where(StockAccuracyResults.stock_symbol == stock_symbol)
                         .order_by(StockAccuracyResults.record_date.desc())  # Order by record_date in descending order
                         .first()) 

        if not latest_result:
            raise HTTPException(status_code=404, detail=f"No accuracy data found for stock: {stock_symbol}")

        return {
            'stock_symbol': latest_result.stock_symbol,
            'mape_in_percentage': latest_result.mape_in_percentage,
            'accuracy_in_percentage': latest_result.accuracy_in_percentage,
            'record_date': latest_result.record_date
        }

    except Exception as e:
        print(f"Error in get_latest_stock_accuracy: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

    
