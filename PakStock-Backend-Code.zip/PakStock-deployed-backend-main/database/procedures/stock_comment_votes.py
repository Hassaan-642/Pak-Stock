from database.schemas.stock_comment_votes import StockCommentVotes
from database.schemas.stock_comments import StockComments
from peewee import DoesNotExist, IntegrityError
from fastapi import HTTPException

# POST: Create Stock Comment Vote
def create_stock_comment_vote(comment_id, user_id, username, isUpvote):
    try:
        # verify whether comment exists
        StockComments.get(StockComments.comment_id == comment_id) # will throw exception if comment doesn't exist

        # check whether user has already voted on this comment
        if StockCommentVotes.select().where(
            StockCommentVotes.comment_id == comment_id,
            StockCommentVotes.user_id == user_id
        ).exists():
            raise IntegrityError

        StockCommentVotes.create(
            comment_id=comment_id,
            user_id=user_id,
            username=username,
            isUpvote=isUpvote
        )

        return True
    
    except StockComments.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Comment not found")
    
    except IntegrityError as e:
        print(e)
        raise HTTPException(status_code=400, detail="Vote already exists")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")

# GET: Get All Votes for a Comment
def get_stock_comment_votes(comment_id):
    try:
        # check whether comment exists
        StockComments.get(StockComments.comment_id == comment_id) # will throw exception if comment doesn't exist

        votes = list(StockCommentVotes.select().where(StockCommentVotes.comment_id == comment_id).dicts())
        return votes
    
    except StockComments.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Comment not found")
    
    except StockCommentVotes.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Comment not found")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")

# DELETE: Delete Stock Comment Vote
def delete_stock_comment_vote(comment_id, user_id):
    try:
        vote = StockCommentVotes.get(
            StockCommentVotes.comment_id == comment_id,
            StockCommentVotes.user_id == user_id
        )

        vote.delete_instance()
        return True
    
    except StockCommentVotes.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Vote not found")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
# DELETE: Delete All Votes for a Comment
def delete_all_stock_comment_votes(comment_id):
    try:
        # check whether comment exists
        StockComments.get(StockComments.comment_id == comment_id) # will throw exception if comment doesn't exist

        query = StockCommentVotes.delete().where(StockCommentVotes.comment_id == comment_id)
        query.execute()
        return True
    
    except StockComments.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Comment not found")
    
    except StockCommentVotes.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Votes do not exist")
    
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")
    