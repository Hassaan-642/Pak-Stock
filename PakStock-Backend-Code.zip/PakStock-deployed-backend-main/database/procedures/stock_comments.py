from database.schemas.stock_comments import StockComments
from database.procedures.stock_comment_votes import delete_all_stock_comment_votes
from peewee import DoesNotExist, IntegrityError
from fastapi import HTTPException
from playhouse.shortcuts import model_to_dict, dict_to_model

# POST: Create Stock Comment
def create_stock_comment(stock_symbol, user_id, username, content, parent_comment_id):
    try:
        # check if parent_comment_id exists. If not, exception will be raised
        if parent_comment_id is not None:
            parent_comment = StockComments.get(StockComments.comment_id == parent_comment_id)

        StockComments.create(
            stock_symbol=stock_symbol,
            user_id=user_id,
            username=username,
            parent_comment_id=parent_comment_id,
            content=content,
        )
        
        return True
    
    except StockComments.DoesNotExist as e:
        print("Error in create_stock_comment: ", e)
        raise HTTPException(status_code=400, detail="Parent stock comment does not exist.")

    except IntegrityError as e:
        print("Error in create_stock_comment: ", e)
        raise HTTPException(status_code=400, detail="Stock Comment already exists.")

    except Exception as e:
        print("Error in create_stock_comment: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# GET: Get All Comments for One Stock
def get_all_stock_comments(stock_symbol):
    try:
        query = StockComments.select().where(StockComments.stock_symbol==stock_symbol)
        data = list(query.dicts().execute())
        return data

    except StockComments.DoesNotExist as e:
        print("Error in get_stock_comments: ", e)
        raise HTTPException(status_code=400, detail="No comments for this stock_symbol exist.")

    except Exception as e:
        print("Error in get_stock_comments: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# GET: Get Comment by ID
def get_stock_comment_by_id(comment_id):
    try:
        query = StockComments.get(StockComments.comment_id==comment_id)
        data = model_to_dict(query)
        return data
    
    except StockComments.DoesNotExist as e:
        print("Error in get_stock_comment_by_id: ", e)
        raise HTTPException(status_code=400, detail="Stock Comment does not exist.")

    
    except Exception as e:
        print("Error in get_stock_comment_by_id: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

 
# PUT: Update Comment by ID
def update_stock_comment_by_id(comment_id, content):
    try:
        # verify if comment exists
        instance = StockComments.get(StockComments.comment_id == comment_id) # will throw exception if comment doesn't exist

        query = instance.update(content=content).where(StockComments.comment_id==comment_id)
        query.execute()
        return True

    except StockComments.DoesNotExist as e:
        print("Error in update_stock_comment_by_id: ", e)
        raise HTTPException(status_code=400, detail="Stock Comment does not exist.")

    except Exception as e:
        print("Error in update_stock_comment_by_id: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# DELETE: Delete Comment by ID
def delete_stock_comment_by_id(comment_id):
    try:
        # verify if comment exists
        instance = StockComments.get(StockComments.comment_id == comment_id) # will throw exception if comment doesn't exist
        
        # delete all stock comment votes for the comment
        delete_all_stock_comment_votes(comment_id)

        # see if comment has any child comments  
        child_comments = StockComments.select().where(StockComments.parent_comment_id==comment_id)
        if child_comments.exists():
            # delete all child comments for the comment
            for comment in child_comments:
                delete_all_stock_comment_votes(comment.comment_id)
                delete_stock_comment_by_id(comment.comment_id)
        
        # delete the comment
        query = StockComments.delete().where(StockComments.comment_id==comment_id)
        query.execute()
        return True

    except StockComments.DoesNotExist as e:
        print("Error in delete_stock_comment_by_id: ", e)
        raise HTTPException(status_code=400, detail="Stock Comment does not exist.")

    except Exception as e:
        print("Error in delete_stock_comment_by_id: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")