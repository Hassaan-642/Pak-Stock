# db.py - Database operations
from database.schemas.user import User
from peewee import DoesNotExist, IntegrityError
from fastapi import HTTPException


def create_user(username: str, email: str, password_hash: str):
    try:
        user = User.create(
            username=username,
            email=email,
            password_hash=password_hash
        )

        return user
    except IntegrityError as e:
            raise HTTPException(status_code=400, detail="Username or email already exists")
    except Exception as e:
        print(f"Error creating user: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    

def get_user_by_email(email: str):
    try:
        user = User.get(User.email == email)
        return user
    except User.DoesNotExist:
        return None
    except Exception as e:
        print(f"Error getting user by email: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

def get_user_by_id(user_id: str):
    try:
        # user = User.get_by_id(user_id)
        # print("Get user by id. Id: ", user_id)
        # print("User; ", user)
        # return user

        # user = User.select(User.id, User.email, User.username, User.role, User.confirmed).where(User.id == user_id).get()
        # print("User: ", user)
        # return user
        # return User.get(User.uid == user_id)

        user = User.get(User.uid == user_id)
        print("User type: ", type(user))
        # Access the fields
        print("User id: ", user.uid, "Username: ", user.username, user.email, user.role)

        return user
    except User.DoesNotExist:
        return None
    except Exception as e:
        print(f"Error getting user by id: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

def confirm_user_email(user_id: str) -> dict:
    """
    Mark the user's email as verified in the database.
    """
    try:
        # Retrieve the user and update their email_verified status
        user = User.get(User.uid == user_id)
        user.confirmed = True
        user.save()

        return {
            "uid": user.uid,
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "confirmed": True
        }
    except User.DoesNotExist as e:
        print("The user does not exist.")
        raise e
    
# def verify_password(user_id: str, request_password: str):
#     try:
#         user = User.get(User.id == user_id)
        
        
#     except User.DoesNotExist as e:
#         print("The user does not exist.")
#         raise e
#     except Exception as e:
#         print(f"Error verifying password: {e}")
#         raise HTTPException(status_code=500, detail="Internal Server Error")