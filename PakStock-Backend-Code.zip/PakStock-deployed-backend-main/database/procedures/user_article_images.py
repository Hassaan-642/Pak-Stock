from fastapi import HTTPException
from fastapi.responses import JSONResponse
from playhouse.shortcuts import model_to_dict, dict_to_model
from database.schemas.user_article_images import UserArticleImages
from database.schemas.articles import UserArticles

# Create Article
def create_article_image(article_id: str, image_path: str):
    try:
        # validate whether article exists
        UserArticles.get(article_id=article_id) # throws exception if not found

        createdImage = UserArticleImages.create(
                        article_id=article_id, 
                        image_path=image_path,
        )
        createdImage = model_to_dict(createdImage)
        
        return createdImage
    
    except UserArticles.DoesNotExist:
        print(f"Post with ID {article_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while creating the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")



# Get article images by article id
def get_article_images_by_article_id(article_id: str):
    try:
        # validate whether article exists
        UserArticles.get(article_id=article_id) # throws exception if not found
        
        article_images = list(UserArticleImages.select().where(UserArticleImages.article_id == article_id).dicts())

        return article_images

    except UserArticles.DoesNotExist:
        print(f"Post with ID {article_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except UserArticleImages.DoesNotExist:
        print(f"No images found for article with ID {article_id}.")
        return []
    
    except Exception as e:
        print(f"Error occurred while fetching the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# Delete article by Id
def delete_article_image_by_id(article_image_id: str):
    try:
        # verify whether image exists
        article_image_object = UserArticleImages.get(article_image_id=article_image_id)
        article_image_object.delete_instance()
        
        return True
    
    except UserArticleImages.DoesNotExist:
        print(f"Article image with ID {article_image_object} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while deleting the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")