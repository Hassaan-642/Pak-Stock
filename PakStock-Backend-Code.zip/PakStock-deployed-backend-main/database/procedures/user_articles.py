from fastapi import HTTPException
from fastapi.responses import JSONResponse
from playhouse.shortcuts import model_to_dict, dict_to_model
from database.schemas.articles import UserArticles

# Create Article
def create_article(user_id: str, username: str, title: str, content: str):
    try:
        article = UserArticles.create(
                        user_id=user_id, 
                        username=username, 
                        title=title, 
                        content=content,              
                        )
        
        article = model_to_dict(article)

        article["date_created"] = article["date_created"].strftime("%Y-%m-%d %H:%M:%S")

        return JSONResponse(content={"message": "Article created successfully.", "article": article}, status_code=201)
    
    except Exception as e:
        print(f"Error occurred while creating the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")



# Read/Get Article by Id
def get_article_by_article_id(article_id: str):
    try:
        article_object = UserArticles.get(article_id=article_id)
        article_object = model_to_dict(article_object)
        article_object["date_created"] = article_object["date_created"].strftime("%Y-%m-%d %H:%M:%S")
        return article_object
    
    except UserArticles.DoesNotExist:
        print(f"Post with ID {article_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while fetching the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# Get all Articles
def get_all_articles():
    try:
        articles = UserArticles.select()
        articles = [model_to_dict(article) for article in articles]
        for article in articles:
            article["date_created"] = article["date_created"].strftime("%Y-%m-%d %H:%M:%S")
        return articles
    
    except UserArticles.DoesNotExist:
        print("No posts found.")
        return []
    
    except Exception as e:
        print(f"Error occurred while fetching the posts: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# Update article by Id
def update_article(article_id: str, title: str, content: str):
    try:
        article_object = UserArticles.get(article_id=article_id)

        if title != None:
            article_object.title = title
        
        if content != None:
            article_object.content = content
            
        article_object.save()

        return_article_object = model_to_dict(article_object)
        return_article_object["date_created"] = return_article_object["date_created"].strftime("%Y-%m-%d %H:%M:%S")

        return JSONResponse(content={"message": "Article updated successfully.", "article": return_article_object}, status_code=201)
    
    except UserArticles.DoesNotExist:
        print(f"Post with ID {article_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while updating the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# Delete article by Id
def delete_article(article_id: str):
    try:
        article_object = UserArticles.get(article_id=article_id)
        article_object.delete_instance()
        
        return True
    
    except UserArticles.DoesNotExist:
        print(f"Post with ID {article_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while deleting the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")
    

def update_article_views(article_id: str):
    try:
        article_object = UserArticles.get(article_id=article_id)
        article_object.view_count += 1
        article_object.save()

        return JSONResponse(content={"message": "Article views updated successfully.", "article_views": article_object.view_count}, status_code=201)
    
    except UserArticles.DoesNotExist:
        print(f"Post with ID {article_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while updating the post views: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")