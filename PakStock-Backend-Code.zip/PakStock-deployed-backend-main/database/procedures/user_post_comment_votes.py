from database.schemas.user_post_comment_votes import UserPostCommentVotes
from database.schemas.user_post_comments import UserPostComments

from peewee import DoesNotExist, IntegrityError
from fastapi import HTTPException

# POST: Create User Post Comment Vote
def create_user_post_comment_vote(comment_id, user_id, username, isUpvote):
    try:
        # verify if comment exists
        UserPostComments.get(UserPostComments.comment_id == comment_id)

        # verify if user has already voted on this comment
        if UserPostCommentVotes.select().where(
            UserPostCommentVotes.comment_id == comment_id,
            UserPostCommentVotes.user_id == user_id
        ).exists():
            raise IntegrityError

        UserPostCommentVotes.create(
            comment_id=comment_id,
            user_id=user_id,
            username=username,
            isUpvote=isUpvote
        )

        return True
    
    except UserPostComments.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Comment not found")

    except IntegrityError as e:
        print(e)
        raise HTTPException(status_code=400, detail="Vote already exists")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")

# GET: Get All Votes for a Comment
def get_user_post_comment_votes(comment_id):
    try:
        votes = list(UserPostCommentVotes.select().where(UserPostCommentVotes.comment_id == comment_id).dicts())
        return votes
    
    except UserPostCommentVotes.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Comment not found")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")

# DELETE: Delete User Post Comment Vote
def delete_user_post_comment_vote(comment_id, user_id):
    try:
        vote = UserPostCommentVotes.get(
            UserPostCommentVotes.comment_id == comment_id,
            UserPostCommentVotes.user_id == user_id
        )

        vote.delete_instance()
        return True
    
    except DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Vote not found")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
# DELETE: Delete All User Post Comment Votes for a Comment
def delete_all_user_post_comment_votes(comment_id):
    try:
        # check if comment exists
        UserPostComments.get(UserPostComments.comment_id == comment_id)

        # delete all user post comment votes for the comment
        query = UserPostCommentVotes.delete().where(UserPostCommentVotes.comment_id==comment_id)
        query.execute()

        return True
    
    except UserPostComments.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Comment not found")
    
    except UserPostCommentVotes.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Vote not found")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")