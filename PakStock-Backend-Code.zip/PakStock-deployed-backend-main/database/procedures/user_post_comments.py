from database.schemas.user_post_comments import UserPostComments
from database.schemas.user_posts import UserPosts
from database.procedures.user_post_comment_votes import delete_all_user_post_comment_votes
from peewee import DoesNotExist, IntegrityError
from fastapi import HTTPException

# POST: Create Stock Comment
def create_user_post_comment(post_id, user_id, username,content, parent_comment_id):
    try:
        # check if post exists. If not, exception will be raised
        post = UserPosts.get(UserPosts.post_id == post_id)

        # if parent_comment_id not null, check whether it exists
        if parent_comment_id is not None:
            parent_comment = UserPostComments.get(UserPostComments.comment_id == parent_comment_id)
            
        UserPostComments.create(
            post_id=post_id,
            user_id=user_id,
            username=username,
            parent_comment_id=parent_comment_id,
            content=content,
        )
        
        return True
    
    except UserPosts.DoesNotExist as e:
        print("Error in create_user_post_comment: ", e)
        raise HTTPException(status_code=400, detail="User post does not exist.")
    
    except UserPostComments.DoesNotExist as e:
        print("Error in create_user_post_comment: ", e)
        raise HTTPException(status_code=400, detail="User comment does not exist.")
    
    except IntegrityError as e:
        print("Error in create_user_post_comment: ", e)
        raise HTTPException(status_code=400, detail="User post comment already exists.")
    
    except Exception as e:
        print("Error in create_user_post_comment: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# GET: Get All Comments for One Stock
def get_all_user_post_comments(post_id):
    try:
        query = UserPostComments.select().where(UserPostComments.post_id==post_id)
        data = list(query.dicts().execute())
        for comment in data:
            comment['date_created'] = comment['date_created'].strftime('%Y-%m-%d %H:%M:%S')
        return data

    except UserPostComments.DoesNotExist as e:
        print("Error in get_all_user_post_comments: ", e)
        raise HTTPException(status_code=400, detail="User post does not exist.")

    except Exception as e:
        print("Error in get_all_user_post_comments: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# GET: Get Comment by ID
def get_user_post_comment_by_id(comment_id):
    try:
        query = UserPostComments.select().where(UserPostComments.comment_id==comment_id)
        data = list(query.dicts().execute())
        return data
    
    except UserPostComments.DoesNotExist as e:
        print("Error in get_user_post_comment_by_id: ", e)
        raise HTTPException(status_code=400, detail="User post comment does not exist.")

    
    except Exception as e:
        print("Error in get_user_post_comment_by_id: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

 
def update_user_post_comment_by_id(comment_id, content):
    try:
        # Check if comment exists
        comment = UserPostComments.get(UserPostComments.comment_id == comment_id)
        if comment is None:
            raise HTTPException(status_code=404, detail="Comment not found.")

        # Update the comment
        comment.content = content
        comment.save()

        # Return the updated comment
        response = UserPostComments.select().where(UserPostComments.comment_id == comment_id).dicts().first()
        response["date_created"] = response["date_created"].strftime('%Y-%m-%d %H:%M:%S')
        return response

    except UserPostComments.DoesNotExist as e:
        print("Error in update_user_post_comment_by_id: ", e)
        raise HTTPException(status_code=400, detail="User post comment does not exist.")

    except Exception as e:
        print("Error in update_user_post_comment_by_id: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# DELETE: Delete Comment by ID
def delete_user_post_comment_by_id(comment_id):
    try:
        # check if comment exists
        check = UserPostComments.get(UserPostComments.comment_id == comment_id)
        if check is None:
            raise HTTPException(status_code=404, detail="Comment not found.")
        
        # delete all user comment votes for the comment
        delete_all_user_post_comment_votes(comment_id)

        # see if comment has any child comments
        child_comments = UserPostComments.select().where(UserPostComments.parent_comment_id==comment_id)
        if child_comments.exists():
            # delete all child comments for the comment
            for comment in child_comments:
                delete_all_user_post_comment_votes(comment.comment_id)
                delete_user_post_comment_by_id(comment.comment_id)
        
        # delete the comment
        query = UserPostComments.delete().where(UserPostComments.comment_id==comment_id)
        query.execute()
        return True

    except UserPostComments.DoesNotExist as e:
        print("Error in delete_user_post_comment_by_id: ", e)
        raise HTTPException(status_code=400, detail="User post comment does not exist.")

    except Exception as e:
        print("Error in delete_user_post_comment_by_id: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")

# DELETE: Delete All Comments for a Post
def delete_all_user_post_comments(post_id):
    try:
        # check if post exists
        post = UserPosts.get(UserPosts.post_id == post_id)
        if post is None:
            raise HTTPException(status_code=404, detail="Post not found.")
        
        # fetch all comments for the post
        query = UserPostComments.select().where(UserPostComments.post_id==post_id)

        # delete all user comment votes for the post
        for comment in query:
            delete_all_user_post_comment_votes(comment.comment_id)

        # delete all user comment votes for the post
        query = UserPostComments.delete().where(UserPostComments.post_id==post_id)
        query.execute()

        return True

    except UserPosts.DoesNotExist as e:
        print("Error in delete_all_user_post_comments: ", e)
        raise HTTPException(status_code=400, detail="User post does not exist.")

    except Exception as e:
        print("Error in delete_all_user_post_comments: ", e)
        raise HTTPException(status_code=500, detail="Internal Server Error.")