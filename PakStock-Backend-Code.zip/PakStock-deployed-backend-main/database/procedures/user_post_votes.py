from database.schemas.user_post_votes import UserPostVotes
from database.schemas.user_posts import UserPosts
from peewee import DoesNotExist, IntegrityError
from fastapi import HTTPException

# POST: Create Stock Comment Vote
def create_user_post_vote(post_id, user_id, username, isUpvote):
    try:
        # check whether the post exists
        post = UserPosts.get(UserPosts.post_id == post_id)

        UserPostVotes.create(
            post_id=post_id,
            user_id=user_id,
            username=username,
            isUpvote=isUpvote
        )

        return True
    
    except UserPosts.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Post not found")
    
    except IntegrityError as e:
        print(e)
        raise HTTPException(status_code=400, detail="Vote already exists")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")

# GET: Get All Votes for a Comment
def get_user_post_votes(post_id):
    try:
        # check if post exists
        post = UserPosts.get(UserPosts.post_id == post_id)
        
        votes = list(UserPostVotes.select().where(UserPostVotes.post_id == post_id).dicts())

        # for each vote, convert datetime -> string
        for vote in votes:
            vote["date_created"] = vote["date_created"].strftime('%Y-%m-%d %H:%M:%S')

        return votes
    
    except UserPosts.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Post not found")
    
    except UserPostVotes.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Comment not found")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")

# DELETE: Delete user post vote for a user
def delete_user_post_vote(post_id, user_id):
    try:
        vote = UserPostVotes.get(
            UserPostVotes.post_id == post_id,
            UserPostVotes.user_id == user_id
        )

        vote.delete_instance()
        vote.save()

        return True
    
    except UserPostVotes.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Vote not found")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")

# DELETE: Delete All Votes for a Post
def delete_all_user_post_votes(post_id):
    try:
        # check whether post exists
        UserPosts.get(UserPosts.post_id == post_id) # will throw exception if post doesn't exist

        votes = UserPostVotes.delete().where(UserPostVotes.post_id == post_id)
        votes.execute()

        return True
    
    except UserPosts.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Post not found")
    
    except UserPostVotes.DoesNotExist as e:
        print(e)
        raise HTTPException(status_code=404, detail="Vote not found")

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Internal Server Error")