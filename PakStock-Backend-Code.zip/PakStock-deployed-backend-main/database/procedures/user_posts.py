from peewee import IntegrityError, DoesNotExist
from database.schemas.user_posts import UserPosts
from database.procedures.user_post_votes import delete_all_user_post_votes
from database.procedures.user_post_comments import delete_all_user_post_comments
from fastapi import HTTPException
from playhouse.shortcuts import model_to_dict, dict_to_model

def create_user_post(title, content, user_id, username, picture_path=None):
    try:
        new_post = UserPosts.create(title=title, content=content, user_id=user_id, username=username, picture_path=picture_path)
        new_post = model_to_dict(new_post)
        new_post["date_created"] = new_post["date_created"].strftime('%Y-%m-%d %H:%M:%S')
        return new_post
    
    except Exception as e:
        print(f"Error occurred while creating the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")


def get_user_post(post_id):
    try:
        user_post = UserPosts.get(UserPosts.post_id == post_id)
        user_post = model_to_dict(user_post)
    
        user_post["date_created"] = user_post["date_created"].strftime('%Y-%m-%d %H:%M:%S')
        return user_post
    
    except UserPosts.DoesNotExist:
        print(f"Post with ID {post_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while fetching the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")


def update_user_post(post_id, title=None, content=None, picture_path=None):
    try:
        # verify if post exists
        response = UserPosts.get(UserPosts.post_id == post_id)

        update_data = {}
        if title is not None:
            update_data[UserPosts.title] = title
        if content is not None:
            update_data[UserPosts.content] = content
        if picture_path is not None:
            update_data[UserPosts.picture_path] = picture_path

        if update_data:
            query = response.update(update_data)
            query.execute()
            return True
        
        return 0  # No fields to update
    
    except UserPosts.DoesNotExist as e:
        print(f"Post with ID {post_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while updating the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")

def update_user_post_image_path(post_id, picture_path):
    try:
        # verify if post exists
        response = UserPosts.get(UserPosts.post_id == post_id)

        response.picture_path = picture_path
        response.save()
        return model_to_dict(response)

    except UserPosts.DoesNotExist as e:
        print(f"Post with ID {post_id} does not exist.")
        raise HTTPException(status_code=404, detail="Post not found.")
    
    except Exception as e:
        print(f"Error occurred while updating the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")


def delete_user_post(post_id):
    try:
        # check if post exists
        response = UserPosts.get(UserPosts.post_id == post_id)

        # delete all user post votes for the post
        delete_all_user_post_votes(post_id)

        # delete all user post comments for the post
        delete_all_user_post_comments(post_id)
        
        response.delete_instance()

    except UserPosts.DoesNotExist as e:
            print(f"Post with ID {post_id} does not exist.")
            raise HTTPException(status_code=404, detail="Post not found.")
        
    except Exception as e:
        print(f"Error occurred while updating the post: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")

    

def get_all_user_posts():
    try:
        results = list(UserPosts.select().dicts())

        for result in results:
            if 'date_created' in result and result['date_created'] is not None:
                result['date_created'] = result['date_created'].strftime('%Y-%m-%d %H:%M:%S')

        # print(f"Results are: {results}")
        return results
    
    except Exception as e:
        print(f"Error occurred while fetching all posts: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")