import peewee
from database.schemas.baseModel import BaseModel
from utility.datetime_utils import getNowTime
import uuid

class UserArticles(BaseModel):
    article_id = peewee.CharField(primary_key=True, max_length=255, default=lambda: str(uuid.uuid4()))
    user_id = peewee.CharField(max_length=255)
    username = peewee.CharField(max_length=255)
    date_created = peewee.DateTimeField(default=getNowTime())
    title = peewee.CharField(max_length=255)
    content = peewee.TextField()
    view_count = peewee.IntegerField(default=0)

    class Meta:
        table_name = 'user_articles'






