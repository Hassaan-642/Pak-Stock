import peewee
from database.procedures.get_connection import get_conn
from dotenv import load_dotenv
import os 

load_dotenv('.env')

db = get_conn()

# Base Model
class BaseModel(peewee.Model):
    class Meta:
        database = db