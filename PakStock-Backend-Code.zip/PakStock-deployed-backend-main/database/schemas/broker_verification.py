import peewee
from database.schemas.baseModel import BaseModel
from utility.datetime_utils import getNowTime

class BrokerVerification(BaseModel):
    user_id = peewee.CharField(max_length=255, unique=True, null=False)
    email = peewee.CharField(max_length=255, unique=True, null=False)
    submission_date = peewee.DateTimeField(default=getNowTime())  # default to current timestamp
    verification_status = peewee.CharField(default='Pending')
    verification_date = peewee.DateField(null=True)
    verification_notes = peewee.TextField(null=True)
    
    # Broker Information
    legal_name = peewee.CharField(max_length=255, null=False)
    license_number = peewee.CharField(max_length=100, unique=True, null=False)
    brokerage_type = peewee.CharField(max_length=50, null=False)
    registration_number = peewee.CharField(max_length=100, unique=True, null=False)
    
    # Contact Details
    office_address = peewee.TextField(null=False)
    contact_phone = peewee.CharField(max_length=50, null=False)
    professional_email = peewee.CharField(max_length=255, null=False)
    website_url = peewee.CharField(max_length=255, null=True)
    
    # Regulatory Compliance
    secp_registration_details = peewee.TextField(null=False)
    aml_compliance_details = peewee.TextField(null=False)
    kyc_procedures_details = peewee.TextField(null=False)
    
    # Financial Information
    capital_adequacy_ratio_details = peewee.TextField(null=False)
    financial_statements_details = peewee.TextField(null=False)
    
    # Trading Platforms & Tools
    trading_platforms_details = peewee.TextField(null=False)
    trading_tools_details = peewee.TextField(null=False)
    
    # Licenses & Certifications
    secp_license_details = peewee.TextField(null=False)
    iso_certification_details = peewee.TextField(null=True)
    other_certifications = peewee.TextField(null=True)
    
    # Broker Services
    investment_products = peewee.TextField(null=False)
    fee_structure_details = peewee.TextField(null=False)
    client_testimonials = peewee.TextField(null=True)
    
    # Security and Privacy
    security_measures = peewee.TextField(null=False)
    privacy_policy_details = peewee.TextField(null=False)

    class Meta:
        primary_key = peewee.CompositeKey('user_id', 'email')
        table_name = 'broker_verification'
