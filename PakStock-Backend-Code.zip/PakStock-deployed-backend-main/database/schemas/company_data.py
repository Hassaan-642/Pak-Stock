import peewee
from database.schemas.baseModel import BaseModel

# Models for Company Info, Processed Articles, and Raw Articles
class CompanyInfo(BaseModel):
    my_row_id = peewee.BigAutoField()  # Auto-incrementing primary key
    company_information = peewee.TextField(null=True)  # Use null=True to allow NULL values
    ceo_name = peewee.CharField(max_length=255, null=True)
    chairperson_name = peewee.CharField(max_length=255, null=True)
    company_secretary_name = peewee.CharField(max_length=255, null=True)
    address = peewee.CharField(max_length=255, null=True)
    website = peewee.CharField(max_length=255, null=True)
    registrar = peewee.TextField(null=True)
    auditor = peewee.CharField(max_length=255, null=True)
    fiscal_year_end = peewee.CharField(max_length=50, null=True)
    market_cap = peewee.FloatField(null=True)
    shares = peewee.BigIntegerField(null=True)
    free_float_of_shares = peewee.BigIntegerField(null=True)
    free_float_percentage = peewee.FloatField(null=True)
    stock_name = peewee.CharField(max_length=255, null=True)

    class Meta:
        table_name = 'company_info'  # Specify the table name