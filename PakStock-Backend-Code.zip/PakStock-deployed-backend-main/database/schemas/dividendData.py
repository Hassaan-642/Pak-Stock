import peewee
from database.schemas.baseModel import BaseModel  # Ensure BaseModel is properly configured

class DividendData(BaseModel):
    dividend_amount = peewee.CharField(max_length=50)
    dividend_yield = peewee.CharField(max_length=50)
    last_ex_date = peewee.CharField(max_length=50)
    last_pay_date = peewee.CharField(max_length=50)
    stock_symbol = peewee.CharField(max_length=50)
    dividendData = peewee.BooleanField()
    payDividend = peewee.BooleanField()

    class Meta:
        table_name = 'dividend_data'
        primary_key = False  # Explicitly no primary key
