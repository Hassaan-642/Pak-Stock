import peewee
from database.schemas.baseModel import BaseModel


class HistoricalKSE100Index(BaseModel):
    my_row_id = peewee.AutoField()  # AUTO_INCREMENT field
    date = peewee.DateField(null=False)  # Corresponds to `Date` column
    close = peewee.DecimalField(max_digits=15, decimal_places=2, null=False)  # Corresponds to `Close` column

    class Meta:
        table_name = 'historical_kse_100_index'  # Table name in the database