import peewee
from database.schemas.baseModel import BaseModel
from utility.kse_data_utils import get_stock_symbols

class HistoricalData(BaseModel):
    TIME = peewee.DateField()
    OPEN = peewee.DoubleField(null=True)
    HIGH = peewee.DoubleField(null=True)
    LOW = peewee.DoubleField(null=True)
    CLOSE = peewee.DoubleField(null=True)
    VOLUME = peewee.FloatField(null=True)
    stock_name = peewee.CharField(max_length=255)

    class Meta:
        table_name = 'historical_data'
        primary_key = peewee.CompositeKey('TIME', 'stock_name')