import peewee
from database.schemas.baseModel import BaseModel


# Note, this is for live KSE100 data
class KSE100Index(BaseModel):
    # Define the id as the primary key explicitly using PrimaryKeyField
    id = peewee.PrimaryKeyField()  # Auto-incrementing primary key
    
    # Define the other columns in the table
    index_value = peewee.DecimalField(max_digits=10, decimal_places=2)
    index_change = peewee.CharField(max_length=20)
    index_direction = peewee.CharField(max_length=20)
    high = peewee.DecimalField(max_digits=10, decimal_places=2)
    low = peewee.DecimalField(max_digits=10, decimal_places=2)
    volume = peewee.BigIntegerField(null=True)
    one_year_change = peewee.DecimalField(max_digits=5, decimal_places=2, null=True)
    ytd_change = peewee.DecimalField(max_digits=5, decimal_places=2, null=True)
    previous_close = peewee.DecimalField(max_digits=10, decimal_places=2, null=True)
    date = peewee.DateTimeField()

    class Meta:
        table_name = 'kse100_index'  # Specify the table name
