import peewee
from database.schemas.baseModel import BaseModel

# Model for Predicted KSE 100 Index
class PredictedKSE100Index(BaseModel):
    date = peewee.DateField(null=False)  # Date column, NOT NULL
    close = peewee.DecimalField(max_digits=15, decimal_places=2, null=False)  # DECIMAL(15,2), NOT NULL

    class Meta:
        table_name = 'predicted_KSE_100_Index'  # Specify the table name
