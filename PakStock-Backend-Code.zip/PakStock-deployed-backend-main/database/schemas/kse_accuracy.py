import peewee
from database.schemas.baseModel import BaseModel  # Ensure BaseModel is properly configured




class kse_accuracy(BaseModel):
    mape_in_percentage = peewee.CharField(max_length=50)
    accuracy_in_percentage = peewee.CharField(max_length=50)
    record_date = peewee.DateField()

    class Meta:
        table_name = 'kse_accuracy'
        primary_key = False  # Explicitly no primary key
