import peewee
from database.schemas.baseModel import BaseModel

class LiveCompanyData(BaseModel):
    id = peewee.PrimaryKeyField()  # Explicitly set the primary key as 'id'
    company = peewee.CharField(max_length=255)
    time = peewee.DateTimeField()  # Use DateTimeField for datetime values
    close_quote = peewee.DoubleField(null=True)
    change_direction = peewee.CharField(max_length=255)
    change_value = peewee.DoubleField(null=True)
    change_percentage = peewee.FloatField(null=True)
    market_cap = peewee.DoubleField(null=True)
    shares = peewee.BigIntegerField(null=True)
    free_float_volume = peewee.BigIntegerField(null=True)
    free_float_percentage = peewee.FloatField(null=True)

    class Meta:
        table_name = 'live_company_data'  # Specify the table name