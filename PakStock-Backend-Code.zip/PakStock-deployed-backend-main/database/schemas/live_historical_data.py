import peewee
from database.schemas.baseModel import BaseModel

class LiveHistoricalData(BaseModel):
    TIME = peewee.DateTimeField()  # Primary key
    OPEN = peewee.DoubleField(null=True)
    HIGH = peewee.DoubleField(null=True)
    LOW = peewee.DoubleField(null=True)
    CLOSE = peewee.DoubleField(null=True)
    VOLUME = peewee.FloatField(null=True)
    stock_name = peewee.CharField(max_length=255)  # Primary key

    class Meta:
        table_name = 'live_historical_data'
        primary_key = peewee.CompositeKey('TIME', 'stock_name')  # Composite primary key

