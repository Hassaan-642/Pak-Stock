import peewee
from database.schemas.baseModel import BaseModel
from database.schemas.user import User
from utility.datetime_utils import getNowTime
import uuid

class OTP(BaseModel):
    oid = peewee.CharField(primary_key=True, max_length=36, default=lambda: str(uuid.uuid4()))
    user = peewee.ForeignKeyField(User, backref='otps', on_delete='CASCADE', column_name='uid')
    otp_code = peewee.CharField(max_length=10)
    purpose = peewee.CharField(max_length=255)
    created_at = peewee.DateTimeField(default=getNowTime())
    expires_at = peewee.DateTimeField()
    is_used = peewee.BooleanField(default=False)

    class Meta:
        table_name = 'otps'