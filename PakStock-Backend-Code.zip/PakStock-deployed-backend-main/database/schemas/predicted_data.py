import peewee
from database.schemas.baseModel import BaseModel

class PredictedDataKMeansLinearRegression(BaseModel):
    stock_name = peewee.CharField(max_length=255)
    TIME = peewee.DateField()
    CLOSE = peewee.DoubleField(null=True)

    class Meta:
        table_name = 'predicted_data_K_Means_Clustering_With_Linear_Regression'
        primary_key = peewee.CompositeKey('TIME', 'stock_name')


class PredictedDataRandomForestRegressor(BaseModel):
    stock_name = peewee.CharField(max_length=255)
    TIME = peewee.DateField()
    CLOSE = peewee.DoubleField(null=True)

    class Meta:
        table_name = 'predicted_data_Random_Forest_Regressor'
        primary_key = peewee.CompositeKey('TIME', 'stock_name')
