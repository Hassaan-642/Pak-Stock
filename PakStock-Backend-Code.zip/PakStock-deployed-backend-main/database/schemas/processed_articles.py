import peewee
from database.schemas.baseModel import BaseModel

class ProcessedArticle(BaseModel):
    article_id = peewee.AutoField()
    title = peewee.CharField()
    description = peewee.TextField()
    link = peewee.CharField()
    snippet = peewee.CharField()
    image = peewee.CharField()
    publish_date = peewee.DateField()
    keyword = peewee.CharField()
    label = peewee.CharField()
    score = peewee.FloatField()
    model = peewee.CharField()

    class Meta:
        indexes = (
            (('keyword', 'title', 'snippet', 'model'), True),  # Composite unique constraint
        )
        table_name = 'processed_articles'
