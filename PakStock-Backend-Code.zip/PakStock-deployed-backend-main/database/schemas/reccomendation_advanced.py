import peewee
from database.schemas.baseModel import BaseModel

class RecommendationAdvanced(BaseModel):
    calculated_on = peewee.DateField()
    NotVolatileStocks = peewee.CharField(max_length=255)
    HotStocks = peewee.CharField(max_length=255, null=True)
    ColdStocks = peewee.CharField(max_length=255, null=True)
    HighlyVolatileStocks = peewee.CharField(max_length=255, null=True)
    
    class Meta:
        table_name = 'Recommendation_Advanced'
        primary_key = peewee.CompositeKey('calculated_on', 'NotVolatileStocks')