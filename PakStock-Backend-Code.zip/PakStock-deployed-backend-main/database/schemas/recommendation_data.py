import peewee
from database.schemas.baseModel import BaseModel

class RecommendationDataDetailed(BaseModel):
    stock_symbol = peewee.CharField(max_length=10, null=True)
    time = peewee.DateField(null=True)
    close = peewee.FloatField(null=True)
    sma_50 = peewee.FloatField(null=True)
    sma_200 = peewee.FloatField(null=True)
    ema_10 = peewee.FloatField(null=True)
    ema_20 = peewee.FloatField(null=True)
    bollinger_middle_band = peewee.FloatField(null=True)
    bollinger_upper_band = peewee.FloatField(null=True)
    bollinger_lower_band = peewee.FloatField(null=True)
    rsi_14 = peewee.FloatField(null=True)
    macd_line = peewee.FloatField(null=True)
    macd_histogram = peewee.FloatField(null=True)
    signal_line = peewee.FloatField(null=True)
    long_term_trend = peewee.CharField(max_length=50, null=True)  # Added new field for long-term trend
    short_term_trend = peewee.CharField(max_length=50, null=True)
    sma_signal = peewee.CharField(max_length=50, null=True)
    bollinger_band_signal = peewee.CharField(max_length=50, null=True)
    rsi_14_signal = peewee.CharField(max_length=50, null=True)
    macd_signal = peewee.CharField(max_length=50, null=True)
    ema_signal = peewee.CharField(max_length=50, null=True)
    volatility = peewee.FloatField(null=True)

    class Meta:
        table_name = 'recommendation_data_detailed'
        primary_key = peewee.CompositeKey('stock_symbol', 'time')
