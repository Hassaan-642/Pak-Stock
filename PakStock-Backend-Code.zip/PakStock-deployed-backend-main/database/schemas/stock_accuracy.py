import peewee
from database.schemas.baseModel import BaseModel

class StockAccuracyResults(BaseModel):
    stock_symbol = peewee.CharField(max_length=10)
    mape_in_percentage = peewee.DecimalField(max_digits=5, decimal_places=2)
    accuracy_in_percentage = peewee.DecimalField(max_digits=5, decimal_places=2)
    record_date = peewee.DateField()

    class Meta:
        table_name = 'stock_accuracy_results'
        primary_key = False  # Indicate that there is no primary key
