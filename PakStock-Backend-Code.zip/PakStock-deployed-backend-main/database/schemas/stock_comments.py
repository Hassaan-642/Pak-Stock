import peewee
from database.schemas.baseModel import BaseModel
from utility.datetime_utils import getNowTime
import uuid

class StockComments(BaseModel):
    comment_id = peewee.CharField(primary_key=True, max_length=255, default=lambda: str(uuid.uuid4()))
    stock_symbol = peewee.CharField(max_length=50, index=True)
    user_id = peewee.CharField(max_length=255, index=True)
    username = peewee.CharField(max_length=255)  # Added username field
    parent_comment_id = peewee.ForeignKeyField('self', backref='replies', null=True, on_delete='SET NULL')
    date_created = peewee.DateTimeField(default=getNowTime())
    content = peewee.TextField()

    class Meta:
        table_name = 'stock_comments'