import peewee
from database.schemas.baseModel import BaseModel
from utility.datetime_utils import getNowTime
import uuid

class User(BaseModel):
    uid = peewee.CharField(primary_key=True, max_length=36, default=lambda: str(uuid.uuid4()))
    username = peewee.CharField(unique=True, max_length=150)
    email = peewee.CharField(unique=True, max_length=255)
    password_hash = peewee.CharField(max_length=255)
    confirmed = peewee.BooleanField(default=False)
    role = peewee.CharField(max_length=255, default='user')
    created_at = peewee.DateTimeField(default=getNowTime())
    updated_at = peewee.DateTimeField(default=getNowTime())

    class Meta:
        table_name = 'users'