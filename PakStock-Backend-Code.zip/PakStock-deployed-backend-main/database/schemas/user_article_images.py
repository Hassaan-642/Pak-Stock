import peewee
from database.schemas.baseModel import BaseModel
from database.schemas.articles import UserArticles
import uuid

class UserArticleImages(BaseModel):
    article_image_id = peewee.CharField( primary_key=True, max_length=255,  default=lambda: str(uuid.uuid4()))
    article_id = peewee.ForeignKeyField(UserArticles, backref='images', on_delete='CASCADE')
    image_path = peewee.TextField()

    class Meta:
        table_name = 'user_article_images'