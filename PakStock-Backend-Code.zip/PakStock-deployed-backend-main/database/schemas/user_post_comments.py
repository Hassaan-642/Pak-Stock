import peewee
from database.schemas.baseModel import BaseModel
from database.schemas.user_posts import UserPosts
from utility.datetime_utils import getNowTime
import uuid

class UserPostComments(BaseModel):
    comment_id = peewee.CharField(primary_key=True, max_length=255, default=lambda: str(uuid.uuid4()))
    post_id = peewee.ForeignKeyField(UserPosts, backref='comments', on_delete='CASCADE', index=True)
    user_id = peewee.CharField(max_length=255, index=True)
    username = peewee.CharField(max_length=255)  # Added username field
    parent_comment_id = peewee.ForeignKeyField('self', backref='replies', null=True, on_delete='SET NULL')
    date_created = peewee.DateTimeField(default=getNowTime())
    content = peewee.TextField()

    class Meta:
        table_name = 'user_post_comments'