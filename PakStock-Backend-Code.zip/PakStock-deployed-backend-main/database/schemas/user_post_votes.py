import peewee
from database.schemas.baseModel import BaseModel
from database.schemas.user_posts import UserPosts
from utility.datetime_utils import getNowTime
import uuid

class UserPostVotes(BaseModel):
    vote_id = peewee.CharField(primary_key=True, max_length=255, default=lambda: str(uuid.uuid4()))
    post_id = peewee.ForeignKeyField(UserPosts, backref='votes', on_delete='CASCADE', index=True)
    user_id = peewee.CharField(max_length=255, index=True)
    username = peewee.CharField(max_length=255)  # Added username field
    date_created = peewee.DateTimeField(default=getNowTime())
    isUpvote = peewee.BooleanField()

    class Meta:
        table_name = 'user_post_votes'