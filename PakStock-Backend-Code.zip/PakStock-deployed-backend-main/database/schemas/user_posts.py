import peewee
from database.schemas.baseModel import BaseModel
from utility.datetime_utils import getNowTime
import uuid

class UserPosts(BaseModel):
    post_id = peewee.CharField(primary_key=True, max_length=255, default=lambda: str(uuid.uuid4()))
    title = peewee.CharField(max_length=255)
    content = peewee.TextField()
    user_id = peewee.CharField(max_length=255, index=True)
    username = peewee.CharField(max_length=255)  # Added username field
    picture_path = peewee.CharField(max_length=255, null=True)
    date_created = peewee.DateTimeField(default=getNowTime())

    class Meta:
        table_name = 'user_posts'