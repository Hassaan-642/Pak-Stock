import chromadb
from chromadb.errors import InvalidCollectionException
from dotenv import load_dotenv
import os
from utility.vectordb_utils import generate_stock_data_documents, generate_website_info_document, generate_investor_guide_document, extract_keywords
import json
from chromadb.utils import embedding_functions

load_dotenv('.env')

CHROMA_PATH = os.getenv("CHROMA_PATH")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY")

client = chromadb.PersistentClient(path="./vectordb/chroma")

huggingface_ef = embedding_functions.HuggingFaceEmbeddingFunction(
    api_key=HUGGINGFACE_API_KEY,
    model_name="sentence-transformers/multi-qa-MiniLM-L6-cos-v1"
)

# Create Collection

def create_chromadb_collection():
    """
    Create or recreate the ChromaDB collection.
    """
    try:
        # Delete existing collection if it exists
        if client.get_collection(name=CHROMA_PATH):
            print("Collection exists. Deleting and recreating...\n")
            client.delete_collection(name=CHROMA_PATH)
    except InvalidCollectionException:
        # Handle case where collection does not exist
        print("Collection does not exist. Creating new collection...\n")
    finally:
        # Create the collection with the embedding function
        client.get_or_create_collection(name=CHROMA_PATH, embedding_function=huggingface_ef)


def insert_chromadb_collection():
    """
    Insert transformed documents and metadata into the ChromaDB collection.
    """
    print("Inserting documents...\n")
    collection = client.get_collection(name=CHROMA_PATH)

    # Generate stock company documents, metadata, and ids
    ids_metadata_documents = generate_stock_data_documents()
    ids = ids_metadata_documents["ids"]
    meta_data = ids_metadata_documents["meta_data"]
    documents = ids_metadata_documents["documents"]

    # Generate website info documents
    website_info = generate_website_info_document()
    ids.append(website_info["ids"])
    meta_data.append(website_info["meta_data"])
    documents.append(website_info["documents"])

    # Generate investor guide documents
    investor_guides = generate_investor_guide_document()
    print(json.dumps(investor_guides, indent=4))
    ids += investor_guides["ids"]
    meta_data += investor_guides["meta_data"]
    documents += investor_guides["documents"]

    # print("Metadata: ", meta_data)

    # Add documents and metadata to the collection
    collection.add(documents=documents, ids=ids, metadatas=meta_data)
    print("Documents inserted successfully!\n")

def combine_metadata_and_documents(results):
    combined_results = []
    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]

    # Ensure the documents and metadatas align
    for doc, metadata in zip(documents, metadatas):
        combined_results.append({"document": doc, "metadata": metadata})

    return combined_results



def query_collection(query):
    """
    Perform both keyword and semantic searches and combine the results.
    """
    # Extract keywords
    keywords = extract_keywords(query)
    collection = client.get_collection(name=CHROMA_PATH)

    # Perform keyword search first
    keyword_results = collection.query(query_texts=keywords, n_results=2)
    semantic_results = collection.query(query_texts=[query], n_results=2)

    # Combine keyword and semantic results
    combined_results = combine_metadata_and_documents(keyword_results)
    combined_results.extend(combine_metadata_and_documents(semantic_results))

    # print("Combined results: ", json.dumps(combined_results, indent=4))

    return combined_results
