import firebase_admin
from firebase_admin import credentials

cred = credentials.Certificate("./resources/pakstockServiceKey.json")
firebase_admin.initialize_app(cred)

from firebase_admin import db

root = db.reference()