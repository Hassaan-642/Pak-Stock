from routers.articles import article_router
# from routers.auth import auth_router
from routers.kse_data import kse_data_router
from routers.scrape_data import scrape_router
from routers.stock_comment_votes_router import stock_comment_votes_router
from routers.stock_comments_router import stock_comment_router
from routers.user_post_comment_votes_router import user_post_comment_votes_router
from routers.user_post_comments_router import user_post_comments_router
from routers.user_post_votes_router import user_post_votes_router
from routers.user_posts_router import user_posts_router
from routers.user_articles_router import user_articles_router
from routers.user_article_images_router import user_article_images_router
from routers.chatbot_router import chatbot_router
from routers.user_post_image_router import user_post_image_router
from routers.broker_verification import broker_verification_router
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from middleware.loggingMiddleware import LoggingMiddleware
from middleware.authorizationMiddleware import AuthorizationMiddleware
from fastapi.staticfiles import StaticFiles
from slowapi.errors import RateLimitExceeded
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.middleware import SlowAPIMiddleware
from middleware.databaseConnectionMiddleware import PeeweeConnectionMiddleware


app = FastAPI()

# for rate limiting
limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins, modify for production
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

app.add_middleware(SlowAPIMiddleware)
app.add_middleware(PeeweeConnectionMiddleware)

app.mount("/user_article_image_uploads", StaticFiles(directory="resources/user_article_image_uploads"), name="static")
app.mount("/user_post_image_uploads", StaticFiles(directory="resources/user_post_image_uploads"), name="static")

app.add_middleware(middleware_class=LoggingMiddleware)
# app.add_middleware(middleware_class=AuthorizationMiddleware)

app.include_router(article_router)
# app.include_router(auth_router)
app.include_router(kse_data_router)
app.include_router(scrape_router)
app.include_router(stock_comment_votes_router)
app.include_router(stock_comment_router)
app.include_router(user_post_comment_votes_router)
app.include_router(user_post_comments_router)
app.include_router(user_post_votes_router)
app.include_router(user_posts_router)
app.include_router(user_post_image_router)
app.include_router(user_articles_router)
app.include_router(user_article_images_router)
app.include_router(chatbot_router)
app.include_router(broker_verification_router)