# logging_middleware.py
from fastapi import Request, HTTPException
import logging
from utility.auth_utils import verify_jwt
import jwt

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class AuthorizationMiddleware:
    async def __call__(self, request: Request, call_next):
        authorization_header = request.headers.get("Authorization")
        if not authorization_header:
            raise HTTPException(status_code=401, detail="Unauthorized")


        token = authorization_header.split("Bearer ")[1]
        try:
            payload = verify_jwt(token)
            request.state.user = payload
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token expired")
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token") 
