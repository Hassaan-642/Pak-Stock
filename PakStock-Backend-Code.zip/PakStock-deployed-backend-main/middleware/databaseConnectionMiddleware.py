# middleware/peewee_middleware.py
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from database.schemas.baseModel import db

class PeeweeConnectionMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        with db.connection_context():
            response: Response = await call_next(request)
        return response
