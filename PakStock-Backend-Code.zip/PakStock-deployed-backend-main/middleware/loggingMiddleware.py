# logging_middleware.py
from fastapi import Request
import time
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class LoggingMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        # Check if the request type is "http"
        if scope['type'] == 'http':
            request = Request(scope, receive)
            start_time = time.time()
            logger.info(f"Request: {request.method} {request.url}")
            
            # Process the request
            await self.app(scope, receive, send)  # Call the next app
            
            response_time = time.time() - start_time
            logger.info(f"Response: {scope['path']} - Time: {response_time:.4f} seconds")
        else:
            await self.app(scope, receive, send)  # Call the next app for non-http requests