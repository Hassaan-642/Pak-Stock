from pydantic import BaseModel, Field, field_validator
from utility.kse_data_utils import get_kse_industries
from fastapi import HTTPException

valid_industries = get_kse_industries()

# Define a Pydantic model for query parameters
class ArticleRequest(BaseModel):
    industry: str = Field(..., description="Industry must be one of the valid options")
    days: int = Field(..., gt=0, description="Days must be an integer greater than 0")

    # Custom validator to check if the industry is valid
    @field_validator('industry')
    def validate_industry(cls, value):
        if value.lower() not in valid_industries:
            raise HTTPException(status_code=400, detail="Invalid industry")
        return value.lower()