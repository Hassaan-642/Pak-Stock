from pydantic import BaseModel, Field
from typing import Optional


class BrokerVerificationRequest(BaseModel):
    legal_name: str
    license_number: str
    brokerage_type: str
    registration_number: str
    office_address: str
    contact_phone: str
    professional_email: str
    website_url: str
    secp_registration_details: str
    aml_compliance_details: str
    kyc_procedures_details: str
    capital_adequacy_ratio_details: str
    financial_statements_details: str
    trading_platforms_details: str
    trading_tools_details: str
    secp_license_details: str
    iso_certification_details: Optional[str] = None
    other_certifications: Optional[str] = None
    investment_products: Optional[str] = None
    fee_structure_details: Optional[str] = None
    client_testimonials: Optional[str] = None
    security_measures: Optional[str] = None
    privacy_policy_details: Optional[str] = None
    verification_date: Optional[str] = None
    verification_notes: Optional[str] = None

class BrokerVerificationStatusRequest(BaseModel):
    status: str = Field('Pending', enum=['Pending', 'Accepted', 'Rejected'])
    user_id: str
    email: str
    verification_notes: Optional[str] = None