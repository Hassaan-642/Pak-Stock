from pydantic import BaseModel
from typing import Optional


# Define a Pydantic model for query parameters
class ChatBotQueryRequest(BaseModel):
    user_query: str
    conversation: Optional[list[dict]] = None