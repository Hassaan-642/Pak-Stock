from pydantic import BaseModel, field_validator
from fastapi import HTTPException
from utility.kse_data_utils import validate_stock_symbol  # Ensure this function is defined

class DividendDataRequest(BaseModel):
    stock_symbol: str  # Only validating stock_symbol

    # Custom validator to check if the stock symbol is valid
    @field_validator('stock_symbol')
    def validate_stock_symbol(cls, value):
        if not validate_stock_symbol(value):
            raise HTTPException(status_code=400, detail="Invalid stock symbol")
        return value.lower()  # Convert to lowercase as per your requirement
