from pydantic import BaseModel, Field, field_validator
from utility.kse_data_utils import validate_stock_symbol
from fastapi import HTTPException

# Define a Pydantic model for query parameters
class HistoricalKSE100Request(BaseModel):
    days: int