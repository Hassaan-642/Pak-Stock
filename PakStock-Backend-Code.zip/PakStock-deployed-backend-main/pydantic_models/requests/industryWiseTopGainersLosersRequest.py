from pydantic import BaseModel
from pydantic import BaseModel, Field, field_validator 
from fastapi import HTTPException
from utility.kse_data_utils import validate_industry

# Define a Pydantic model for fetching all predicted data
class industryWiseTopGainersLosersQuery(BaseModel):
    industry: str = Field(..., description="industry for which to retrieve top gainers and losers")

    @field_validator('industry')
    def validate_industry(cls, value):
        if not validate_industry(value):
            raise HTTPException(status_code=400, detail=f"Invalid industry: {value}.")
        return value
    
