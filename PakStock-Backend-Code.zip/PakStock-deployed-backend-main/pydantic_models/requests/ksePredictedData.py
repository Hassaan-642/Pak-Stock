from pydantic import BaseModel

# Define a Pydantic model for fetching all predicted data
class PredictedDataRequest(BaseModel):
    """
    Pydantic model to fetch all KSE 100 predicted data without any query parameters.
    This model is left empty intentionally as no parameters are needed.
    """
    pass
