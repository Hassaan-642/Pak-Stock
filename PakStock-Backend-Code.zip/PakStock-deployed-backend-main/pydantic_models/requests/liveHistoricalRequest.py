from pydantic import BaseModel, Field, field_validator
from datetime import datetime
from fastapi import HTTPException
from utility.kse_data_utils import validate_stock_symbol  # Assuming there's a utility for stock name validation

# Define a Pydantic model for query parameters
class LiveHistoricalDataRequest(BaseModel):
    stock_name: str = Field(..., description="Stock name must be a valid stock name")
  
    # Custom validator to check if the stock name is valid
    @field_validator('stock_name')
    def validate_stock_name(cls, value):
        if not validate_stock_symbol(value):
            raise HTTPException(status_code=400, detail="Invalid stock name")
        return value.lower()