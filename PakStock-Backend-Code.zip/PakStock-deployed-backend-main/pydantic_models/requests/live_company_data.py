from pydantic import BaseModel, Field, field_validator 
from fastapi import HTTPException
from utility.kse_data_utils import validate_stock_symbol  # Ensure this function is defined
import datetime

class LiveCompanyDataRequest(BaseModel):
    company: str = Field(..., description="company for which to retrieve live data")

    @field_validator('company')
    def validate_company_symbol(cls, value):
        if not validate_stock_symbol(value):
            raise HTTPException(status_code=400, detail=f"Invalid company: {value}.")
        return value
