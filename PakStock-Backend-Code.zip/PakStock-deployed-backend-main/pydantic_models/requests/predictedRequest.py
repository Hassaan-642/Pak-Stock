from pydantic import BaseModel, Field, field_validator
from utility.kse_data_utils import validate_stock_symbol
from fastapi import HTTPException

# Define a Pydantic model for query parameters
class PredictedRequest(BaseModel):
    stock_symbol: str = Field(..., description="Stock symbol must be a valid stock symbol")
    days: int = Field(..., gt=0, description="Days must be an integer greater than 0")
    model_type: str = Field(..., description="Model type must be either 'KMeansLinearRegression' or 'RandomForestRegressor'")

    # Custom validator to check if the stock symbol is valid
    @field_validator('stock_symbol')
    def validate_stock_symbol(cls, value):
        if not validate_stock_symbol(value):
            raise HTTPException(status_code=400, detail="Invalid stock symbol")
        return value.lower()

    # Custom validator for model_type to ensure valid model types are provided
    @field_validator('model_type')
    def validate_model_type(cls, value):
        valid_models = ['KMeansLinearRegression', 'RandomForestRegressor']
        if value not in valid_models:
            raise HTTPException(status_code=400, detail=f"Invalid model type: {value}. Must be one of {valid_models}.")
        return value
