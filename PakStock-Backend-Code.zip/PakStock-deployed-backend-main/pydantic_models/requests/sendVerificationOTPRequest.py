from pydantic import BaseModel, EmailStr

class SendVerificationOTPRequest(BaseModel):
    jwt: str
