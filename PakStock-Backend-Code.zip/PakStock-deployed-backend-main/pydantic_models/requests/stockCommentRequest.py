from pydantic import BaseModel, Field, field_validator
from typing import Optional
from utility.kse_data_utils import validate_stock_symbol  # Assuming there's a utility for stock name validation
from fastapi import HTTPException


# Request model for creating a comment
class CreateCommentRequest(BaseModel):
    stock_symbol: str
    user_id: str
    parent_comment_id: Optional[str] = None
    username: str
    content: str

    # Custom validator to check if the stock name is valid
    @field_validator('stock_symbol')
    def validate_stock_name(cls, value):
        if not validate_stock_symbol(value):
            raise HTTPException(status_code=400, detail="Invalid stock name")
        return value

# Query model for getting all comments for a stock
class GetAllCommentsQuery(BaseModel):
    stock_symbol: str

     # Custom validator to check if the stock name is valid
    @field_validator('stock_symbol')
    def validate_stock_name(cls, value):
        if not validate_stock_symbol(value):
            raise HTTPException(status_code=400, detail="Invalid stock name")
        return value

# Query model for getting a comment by ID
class GetCommentByIdQuery(BaseModel):
    comment_id: str

# Request model for updating a comment
class UpdateCommentRequest(BaseModel):
    user_id: Optional[str] = None
    comment_id: str
    content: str

# Query model for deleting a comment
class DeleteCommentQuery(BaseModel):
    comment_id: str
    user_id: Optional[str] = None
