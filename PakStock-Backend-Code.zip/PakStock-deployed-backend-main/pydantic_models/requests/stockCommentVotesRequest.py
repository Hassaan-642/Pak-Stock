from pydantic import BaseModel, Field, field_validator
from typing import Optional
from utility.kse_data_utils import validate_stock_symbol  # Assuming there's a utility for stock name validation
from fastapi import HTTPException


class CreateStockCommentVoteRequest(BaseModel):
    comment_id: str 
    user_id: str
    username: str
    isUpvote: bool

class GetStockVotesQuery(BaseModel):
    comment_id: str

class DeleteStockVoteQuery(BaseModel):
    comment_id: str 
    user_id: str