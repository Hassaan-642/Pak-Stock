from pydantic import BaseModel, Field, field_validator
from utility.kse_data_utils import validate_stock_symbol
from fastapi import HTTPException

# Define a Pydantic model for query parameters
class StockImageRequest(BaseModel):
    stock_symbol: str = Field(..., description="Stock symbol must be a valid stock symbol")
    
    # Custom validator to check if the stock symbol is valid
    @field_validator('stock_symbol')
    def validate_stock_symbol(cls, value):
        if not validate_stock_symbol(value):
            raise HTTPException(status_code=400, detail="Invalid stock symbol")
        return value