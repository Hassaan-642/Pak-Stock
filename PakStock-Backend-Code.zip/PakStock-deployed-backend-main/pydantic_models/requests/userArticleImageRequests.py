from pydantic import BaseModel

class CreateArticleImageQuery(BaseModel):
    article_id: str

class GetArticleImagesByArticleIdQuery(BaseModel):
    article_id: str
    
class DeleteArticleImageQuery(BaseModel):
    article_image_id: str