from pydantic import BaseModel
from typing import Optional

class CreateArticleRequest(BaseModel):
    user_id: str
    username: str
    title: str
    content: str

# added user_id purely for JWT purposes, not used in the request body
class UpdateArticleRequest(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    user_id: Optional[str] = None

class GetArticleByIdQuery(BaseModel):
    article_id: str

class UpdateArticleQuery(BaseModel):
    article_id: str

class DeleteArticleQuery(BaseModel):
    article_id: str
    user_id: Optional[str] = None