# from pydantic import BaseModel, EmailStr, field_validator
# from fastapi import HTTPException
# import os
# import kickbox

# sender_email = os.getenv("EMAIL_SENDER")
# kickbox_api_key = os.getenv("KICKBOX_API_KEY")

# class UserLoginRequest(BaseModel):
#     email: EmailStr
#     password: str

#     @field_validator("email")
#     def email_must_be_valid(cls, value):
#         try:
#             client = kickbox.Client(kickbox_api_key)
#             kickbox_client = client.kickbox()
            
#             # Verifying the email
#             response = kickbox_client.verify(value, {'timeout': 6000})
#             print("Kickbox response: ", response.body)

#             # Check the result of the verification
#             if response.body['result'] == 'undeliverable':
#                 raise HTTPException(status_code=400, detail="Email address is undeliverable.")
#             elif response.body['result'] == 'risky':
#                 raise HTTPException(status_code=400, detail="Email address is considered risky.")
#             elif response.body['result'] == 'invalid':
#                 raise HTTPException(status_code=400, detail="Invalid email address.")
#             elif response.body['reason'] == 'no_connect':
#                 raise HTTPException(status_code=500, detail="Could not connect to SMTP server.")
#             elif response.body['reason'] == 'timeout':
#                 raise HTTPException(status_code=500, detail="SMTP session timed out.")
#             elif response.body['reason'] == 'invalid_smtp':
#                 raise HTTPException(status_code=500, detail="SMTP server returned an unexpected/invalid response.")
#             elif response.body['reason'] == 'unavailable_smtp':
#                 raise HTTPException(status_code=500, detail="SMTP server was unavailable to process our request.")
#             elif response.body['reason'] == 'unexpected_error':
#                 raise HTTPException(status_code=500, detail="An unexpected error has occurred.")

#             if response.body['success']:
#                 return value  # Email is valid

#         except Exception as e:
#             # Catch other potential issues (e.g., network issues)
#             raise HTTPException(status_code=500, detail=f"An error occurred during email verification: {str(e)}")
