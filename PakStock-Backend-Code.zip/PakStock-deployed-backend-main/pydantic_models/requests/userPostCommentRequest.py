from pydantic import BaseModel
from typing import Optional

# Request Models
class CreateUserPostCommentRequest(BaseModel):
    post_id: str
    user_id: str
    parent_comment_id: Optional[str] = None
    username: str
    content: str

class GetAllUserPostCommentsQuery(BaseModel):
    post_id: str

class UpdateUserPostCommentRequest(BaseModel):
    content: str
    user_id: Optional[str] = None

class UpdateUserPostCommentQuery(BaseModel):
    comment_id: str

class GetUserPostCommentQuery(BaseModel):
    comment_id: str

class DeleteUserPostCommentQuery(BaseModel):
    comment_id: str
    user_id: Optional[str] = None
