from pydantic import BaseModel

# Request Models
class CreateUserPostCommentVoteRequest(BaseModel):
    comment_id: str
    user_id: str
    username: str
    isUpvote: bool

class DeleteUserPostCommentVoteQuery(BaseModel):
    comment_id: str
    user_id: str

class GetUserPostCommentVotesQuery(BaseModel):
    comment_id: str