from pydantic import BaseModel
from typing import Optional

# Request Models
class CreateUserPostVoteRequest(BaseModel):
    post_id: str
    user_id: str
    username: str
    isUpvote: bool

class GetUserPostVoteQuery(BaseModel):
    post_id: str

class DeleteUserPostVoteQuery(BaseModel):
    post_id: str
    user_id: str