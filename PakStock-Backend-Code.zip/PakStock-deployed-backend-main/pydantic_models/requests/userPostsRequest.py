from pydantic import BaseModel
from typing import List, Optional

# Request and Response Models
class CreateUserPostRequest(BaseModel):
    title: str
    content: str
    user_id: str
    username: str
    picture_path: Optional[str] = None

class GetUserPostQuery(BaseModel):
    post_id: str

class UpdateUserPostQuery(BaseModel):
    post_id: str 

class UpdateUserPostRequest(BaseModel):
    title: Optional[str]
    content: Optional[str]
    picture_path: Optional[str]
    user_id: Optional[str] = None

class DeleteUserPostQuery(BaseModel):
    post_id: str
    user_id: Optional[str] = None

class CreateUserPostImageQuery(BaseModel):
    post_id: str