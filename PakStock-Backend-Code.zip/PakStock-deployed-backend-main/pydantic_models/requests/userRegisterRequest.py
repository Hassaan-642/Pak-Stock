from pydantic import BaseModel, EmailStr, field_validator
from fastapi import HTTPException
import os
import kickbox

sender_email = os.getenv("EMAIL_SENDER")
kickbox_api_key = os.getenv("KICKBOX_API_KEY")

class UserRegisterRequest(BaseModel):
    username: str
    email: EmailStr
    password: str

    @field_validator("email")
    def email_must_be_valid(cls, value):
        try:
            client = kickbox.Client(kickbox_api_key)
            kickbox_client = client.kickbox()
            
            # Verifying the email
            response = kickbox_client.verify(value, {'timeout': 6000})
            print("Kickbox response: ", response.body)

            # Check the result of the verification
            if response.body['result'] == 'undeliverable':
                raise HTTPException(status_code=400, detail="Email address is undeliverable.")
            elif response.body['result'] == 'risky':
                raise HTTPException(status_code=400, detail="Email address is considered risky.")
            elif response.body['result'] == 'invalid':
                raise HTTPException(status_code=400, detail="Invalid email address.")
            elif response.body['reason'] == 'no_connect':
                raise HTTPException(status_code=500, detail="Could not connect to SMTP server.")
            elif response.body['reason'] == 'timeout':
                raise HTTPException(status_code=500, detail="SMTP session timed out.")
            elif response.body['reason'] == 'invalid_smtp':
                raise HTTPException(status_code=500, detail="SMTP server returned an unexpected/invalid response.")
            elif response.body['reason'] == 'unavailable_smtp':
                raise HTTPException(status_code=500, detail="SMTP server was unavailable to process our request.")
            elif response.body['reason'] == 'unexpected_error':
                raise HTTPException(status_code=500, detail="An unexpected error has occurred.")

            if response.body['success']:
                return value  # Email is valid

        except Exception as e:
            # Catch other potential issues (e.g., network issues)
            raise HTTPException(status_code=500, detail=f"An error occurred during email verification: {str(e)}")


# class UserRegisterRequest(BaseModel):
#     username: str
#     email: EmailStr
#     password: str

    
#     @field_validator("email")
#     def email_must_be_valid(cls, value):
#         client   = kickbox.Client('Your_API_Key_Here')
#         kickbox_client  = client.kickbox()
#         response = kickbox_client.verify(value, { 'timeout': 6000 })
        
        # is_valid = validate_email(
        #     email_address=value,
        #     check_format=True,
        #     check_blacklist=True,
        #     check_dns=True,
        #     dns_timeout=3,
        #     check_smtp=True,
        #     smtp_timeout=3,
        #     smtp_skip_tls=False,
        #     smtp_tls_context=None,
        #     smtp_debug=True
        # )
        
        # if not is_valid:
        #     raise HTTPException(detail="Email is not valid or domain is unreachable.", status_code=400)

        # # Additional check for popular disposable email providers
        # disposable_domains = {"mailinator.com", "guerrillamail.com", "10minutemail.com"}
        # domain = value.split('@')[1]
        # if domain in disposable_domains:
        #     raise HTTPException(detail="Disposible email addresses are not allowed.", status_code=400)
        
        # return value