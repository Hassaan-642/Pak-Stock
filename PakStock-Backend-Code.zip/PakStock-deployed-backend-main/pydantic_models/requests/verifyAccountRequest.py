from pydantic import BaseModel

class VerifyAccountRequest(BaseModel):
    otp: str