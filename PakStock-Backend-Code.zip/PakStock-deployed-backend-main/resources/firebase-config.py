firebaseConfig = {
  "apiKey": "AIzaSyAKyDqE5BvPRAqO-gFJdAQMnfCEqQkct4I",
  "authDomain": "pak-stock.firebaseapp.com",
  "projectId": "pak-stock",
  "storageBucket": "pak-stock.firebasestorage.app",
  "messagingSenderId": "111489176611",
  "appId": "1:111489176611:web:f29ea4025ea78e4af78d96"
}