from fastapi import APIRouter, Query, HTTPException, Depends
from pydantic_models.requests.articleRequest import ArticleRequest
from pydantic_models.requests.sentimentRequest import SentimentRequest
from utility.kse_data_utils import get_kse_industries, get_industry_search_terms
from services.article_service import get_articles, get_sentiment


article_router = APIRouter(prefix="/api")

valid_industries = get_kse_industries()
valid_industry_search_terms = get_industry_search_terms()

# /articles/HBL/?days=7
# NOTE: industry is the actual industry, not the search term
@article_router.get('/articles')
def home(query: ArticleRequest = Depends()):
    print("In /articles/sentiment")
    
    # Proceed to fetch articles if validations pass
    response = get_articles(query.industry.lower(), query.days)
    return response

# INPUT: industry, days
# industry may be "cement", "banking", etc.
@article_router.get('/sentiment')
def home(query: SentimentRequest = Depends()):
    print("In /articles/sentiment")
    
    response = get_sentiment(query.industry.lower(), query.days)
    return response