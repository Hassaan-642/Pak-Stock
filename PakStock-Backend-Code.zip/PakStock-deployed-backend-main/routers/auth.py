# from fastapi import APIRouter, Depends, requests
# from pydantic_models.requests.userLoginRequest import UserLoginRequest
# from pydantic_models.requests.userRegisterRequest import UserRegisterRequest
# from pydantic_models.requests.sendVerificationOTPRequest import SendVerificationOTPRequest
# from pydantic_models.requests.verifyAccountRequest import VerifyAccountRequest
# from services.auth_service import register_user, send_verification_otp, verify_account, send_2fa_otp, verify_2fa, login
# from utility.auth_utils import verify_jwt

# auth_router = APIRouter(prefix="/api")

# # INPUT: username, email, password
# @auth_router.post("/register")
# async def register(user_req: UserRegisterRequest):
#     response = register_user(user_req.username, user_req.email, user_req.password)
#     return response

# @auth_router.post("/send-verification-otp")
# def send_verification_otp_endpoint(payload: dict = Depends(verify_jwt)):
#     print("In send_verification_otp_endpoint")
#     print("Payload: ", payload)
#     response = send_verification_otp(payload)
#     return response

# @auth_router.post("/verify-account")
# def verify_account_endpoint(request: VerifyAccountRequest, payload: dict = Depends(verify_jwt)):
#     print("In verify_account_endpoint")
#     print(request)
#     print(payload)
#     response = verify_account(otp_code=request.otp, payload=payload)
#     return response

# @auth_router.post("/send-2fa-otp")
# def send_2fa_otp_endpoint(payload: dict = Depends(verify_jwt)):
#     print("In send-2fa-otp")
#     print(payload)
#     response = send_2fa_otp(payload)
#     return response

# @auth_router.post("/verify-2fa")
# def verify_2fa_endpoint(request: VerifyAccountRequest, payload: dict = Depends(verify_jwt)):
#     print("In verify_2fa_endpoint")
#     print(request)
#     print(payload)
#     response = verify_2fa(otp_code=request.otp, payload=payload)
#     return response

# @auth_router.post("/login")
# def login_endpoint(request: UserLoginRequest):
#     response = login(request.email, request.password)
#     return response