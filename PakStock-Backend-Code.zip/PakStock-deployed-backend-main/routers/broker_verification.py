from fastapi import APIRouter, HTTPException, Request
from pydantic_models.requests.broker_verification import BrokerVerificationRequest, BrokerVerificationStatusRequest
from database.procedures.Broker_Verification import create_broker_verification, get_all_broker_verifications, update_broker_verification_status
from utility.firebase_utils import verify_jwt, get_user_role
import logging
import os


##########################################################################################
#############
#############   NOTE: There is no service layer for broker verification, as all of it
#############   is handled in the database procedures directly.
#############
##########################################################################################

broker_verification_router = APIRouter(prefix="/api")

@broker_verification_router.post("/broker-verification")
async def broker_verification_endpoint(request: Request, broker_request: BrokerVerificationRequest):
    try:

        # Check if the user JWT is valid
        decoded_token = await verify_jwt(request)
    
        user_id = decoded_token.get('uid')
        email = decoded_token.get('email')

        # Convert model to dict using model_dump() (or dict() for older Pydantic)
        data_dict = broker_request.model_dump()
        
        # Call the database function without await since it's synchronous
        response = create_broker_verification(user_id=user_id, email=email, **data_dict)
        
        print(f"Broker verification successful: {response}")
        return {"status": "success", "data": response}
    except Exception as e:
        raise e

@broker_verification_router.get("/broker-verification")
async def get_broker_verification(request: Request):
    try:
        decoded_token = await verify_jwt(request)
        
        # From decoded_token, get user_id and use that to fetch user role from firebase collection "Users"
        user_id = decoded_token.get('uid')
        user_role = await get_user_role(user_id)
        print(f"User ID: {user_id}, User Role: {user_role}")

        # Check if user is an Admin
        if user_role != 'Admin':
            raise HTTPException(status_code=403, detail="Access forbidden: Admins only.")
        
        response = get_all_broker_verifications()
        return response
        
    except Exception as e:
        print(f"Error fetching broker verification data: {e}")
        raise e
    

@broker_verification_router.put("/broker-verification/approve")
async def approve_broker_verification(request: Request, broker_request: BrokerVerificationRequest):
    try:
        # Check if the user JWT is valid
        decoded_token = await verify_jwt(request)
        
        # Get user role from user_id in decoded_token
        user_id = decoded_token.get('uid')
        user_role = await get_user_role(user_id)

        # Check if user is an Admin
        if user_role != 'Admin':
            raise HTTPException(status_code=403, detail="Access forbidden: Admins only.")

        # Call the database function without await since it's synchronous
        response = update_broker_verification_status(user_id=broker_request.user_id,
                                                     email=broker_request.email,
                                                     status=broker_request.status,
                                                     verification_notes=broker_request.verification_notes,
                                                     )
        
        print(f"Broker verification approved: {response}")
        return {"status": "success"}
    except Exception as e:
        raise e