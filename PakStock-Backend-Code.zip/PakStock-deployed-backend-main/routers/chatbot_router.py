from fastapi import APIRouter, HTTPException, Request, Depends
from services.chatbot_service import LLM
from pydantic_models.requests.chatbotQueryRequest import ChatBotQueryRequest
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from dotenv import load_dotenv
import os

load_dotenv('.env')

RATE_LIMITER_MAX_CALLS = os.getenv("RATE_LIMITER_MAX_CALLS", default="10/minute") 

chatbot_router = APIRouter(prefix='/api')
limiter = Limiter(key_func=get_remote_address)

@chatbot_router.post("/chatbot-query")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def process_query(request: Request, query: ChatBotQueryRequest):
    try:
        llm = LLM()
        response_conversation = llm.process_query(query.user_query)
        return response_conversation
    except HTTPException as e:
        raise e
