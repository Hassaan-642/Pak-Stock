from fastapi import APIRouter, Depends, Response, HTTPException, Request
from pydantic_models.requests.historicalRequest import HistoricalRequest
from pydantic_models.requests.predictedRequest import PredictedRequest
from pydantic_models.requests.companyInformationRequest import CompanyInformationRequest
from pydantic_models.requests.detailedCategoryInformation import DetailedCategoryRequest
from pydantic_models.requests.stockImageRequest import StockImageRequest
from database.procedures.historical_data import get_historical_data
from database.procedures.predicted_data import get_predicted_data
from database.procedures.company_data import get_company_info
from services.kse_service import get_category_info, get_stock_image, get_category_info_detailed
from pydantic_models.requests.liveHistoricalRequest import LiveHistoricalDataRequest
from database.procedures.live_historical_data import get_live_historical_data
from pydantic_models.requests.live_company_data import LiveCompanyDataRequest
from database.procedures.DayToDayTrading import get_Day_To_Day_Trading
from database.procedures.live_company_data import get_live_company_data
from services.kse_service import get_latest_kse100_data
from pydantic_models.requests.dividendData import DividendDataRequest
from database.procedures.dividendData import get_dividend_data
from pydantic_models.requests.stock_accuracy import StockAccuracyRequest
from database.procedures.stock_accuracy import get_stock_accuracy_by_symbol
from pydantic_models.requests.ksePredictedData import PredictedDataRequest
from database.procedures.ksePredictedData import get_all_predicted_data
from database.procedures.randomForestAccuracy import get_stock_accuracy_random_forest_by_symbol
from pydantic_models.requests.randomForestAccuracy import StockAccuracyRequestRandomForest
from database.procedures.recommendation_data import get_recommendation_detailed_data_n_days
from pydantic_models.requests.reccomendationRequest import RecommendationRequest
from pydantic_models.requests.industryWiseTopGainersLosersRequest import industryWiseTopGainersLosersQuery
from services.kse_service import get_industry_top_gainers_losers
from pydantic_models.requests.historicalKSE100Request import HistoricalKSE100Request
from utility.kse_data_utils import get_industry_by_psx_symbol
from services.kse_service import get_historical_kse100_data_service
from database.procedures.kse_accuracy import get_kse_accuracy_data
from pydantic_models.requests.recommmendation_advanced import RecommendationAdvancedRequest
from database.procedures.reccomendation_Advanced import get_recommendation_advanced_by_date
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from utility.firebase_utils import verify_jwt
from dotenv import load_dotenv
import os

load_dotenv('.env')

RATE_LIMITER_MAX_CALLS = os.getenv("RATE_LIMITER_MAX_CALLS", default="10/minute") 

limiter = Limiter(key_func=get_remote_address)

kse_data_router = APIRouter(prefix="/api")

# INPUT: stock_symbol, days, model_type
@kse_data_router.get("/recommendationAdvanced")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def RecommendationAdvanced(request: Request):
    # Call the get_predicted_data function with the model_type
    response = get_recommendation_advanced_by_date()
    return response


# INPUT: stock_symbol, days
@kse_data_router.get("/historical")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def historical(request: Request, query: HistoricalRequest = Depends()):
    response = get_historical_data(query.stock_symbol, query.days)
    return response




@kse_data_router.get("/kse_accuracy")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def get_all_Kse100Accuracy(request: Request):
    """
    Fetch all KSE 100 accuracy data.

    Returns:
        list[dict]: A list of all KSE 100 accuracy data.
    """
    try:
        # Call the service to fetch all predicted data
        response = get_kse_accuracy_data()

        # If no data is returned, raise a 404 error
        if not response:
            raise HTTPException(status_code=404, detail="No kse 100 accuracy found.")

        # Return the response
        return response

    except Exception as e:
        # Handle unexpected errors and return a 500 Internal Server Error
        raise HTTPException(status_code=500, detail="Internal Server Error")

# INPUT: stock_symbol, days, model_type
@kse_data_router.get("/predicted")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def predicted(request: Request, query: PredictedRequest = Depends()):
    # Call the get_predicted_data function with the model_type
    response = get_predicted_data(query.stock_symbol, query.days, query.model_type)
    return response

# INPUT: stock_symbol
@kse_data_router.get('/recommendation')
@limiter.limit(RATE_LIMITER_MAX_CALLS)
async def get_recommendation_data(request: Request, query: RecommendationRequest = Depends()):
    # await verify_jwt(request)
    # verification removed since this is also needed for the frontend
    response = get_recommendation_detailed_data_n_days(query.stock_symbol)
    return response

# INPUT: stock_symbol
@kse_data_router.get("/company-information")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def company(request: Request, query: CompanyInformationRequest = Depends()):
    response = get_company_info(stock_symbol=query.stock_symbol)
    return response

@kse_data_router.get("/category-information")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def category_information(request: Request):
    response = get_category_info()
    return response

@kse_data_router.get("/stock-image")
def get_stock_image_endpoint(query: StockImageRequest = Depends()):
    response = get_stock_image(query.stock_symbol)
    return Response(content=response, media_type="image/jpeg")  # Adjust the media type if needed

@kse_data_router.get("/detailed-category-information")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def detailed_category_information(request: Request, query: DetailedCategoryRequest = Depends()):
    response = get_category_info_detailed(query.industry)
    return response

@kse_data_router.get("/live-historical")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def live_historical(request: Request, query: LiveHistoricalDataRequest = Depends()):
    response = get_live_historical_data(query.stock_name)
    return response

@kse_data_router.get("/live-DayToDayTrading")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def live_historical(request: Request, query: LiveHistoricalDataRequest = Depends()):
    response = get_Day_To_Day_Trading(query.stock_name)
    return response

# INPUT: company name and time
@kse_data_router.get("/live-company-data")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def live_company_data(request: Request, query: LiveCompanyDataRequest = Depends()):
    # Call the function with the correct parameter names
    response = get_live_company_data(company=query.company)
    
    # If no data is returned, raise a 404 error
    if not response:
        raise HTTPException(status_code=404, detail="No live company data found for the provided company name and time.")
    
    return response
    

@kse_data_router.get("/dividend-data")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def dividend_data(request: Request, query: DividendDataRequest = Depends()):
    # Get the dividend data based on the stock_symbol
    response = get_dividend_data(stock_symbol=query.stock_symbol)
    return response


@kse_data_router.get("/ksepredicted")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def get_all_predicted_data_api(request: Request):
    try:
        # Call the service to fetch all predicted data
        response = get_all_predicted_data()

        # If no data is returned, raise a 404 error
        if not response:
            raise HTTPException(status_code=404, detail="No predicted data found.")

        # Return the response
        return response

    except Exception as e:
        # Handle unexpected errors and return a 500 Internal Server Error
        raise HTTPException(status_code=500, detail="Internal Server Error")

@kse_data_router.get("/stock-accuracy")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def stock_accuracy(request: Request, query: StockAccuracyRequest = Depends()):
    # Get the stock accuracy data based on the stock_symbol
    response = get_stock_accuracy_by_symbol(stock_symbol=query.stock_symbol)

    # If no data is returned, raise a 404 error
    if not response:
        raise HTTPException(status_code=404, detail="No stock accuracy data found for the provided stock symbol.")
    
    return response

@kse_data_router.get("/stock-accuracy-randomForest")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def stock_accuracy_randomForest(request: Request, query: StockAccuracyRequestRandomForest = Depends()):
    # Get the stock accuracy data based on the stock_symbol
    response = get_stock_accuracy_random_forest_by_symbol(stock_symbol=query.stock_symbol)

    # If no data is returned, raise a 404 error
    if not response:
        raise HTTPException(status_code=404, detail="No stock accuracy data found for the provided stock symbol.")
    
    return response


@kse_data_router.get("/kse100-index")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def kse100_index(request: Request):
    # Call the procedure to retrieve KSE 100 index data based on the provided date
    response = get_latest_kse100_data()
    return response



@kse_data_router.get("/kse100-historical")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def kse100_historical(request: Request, query: HistoricalKSE100Request = Depends()):
    # Call the procedure to retrieve historical KSE 100 index data
    response = get_historical_kse100_data_service(days=query.days)
    return response

@kse_data_router.get("/industry-top-gainers-losers")
@limiter.limit(RATE_LIMITER_MAX_CALLS)
def industry_top_gainers_losers(request: Request, query: industryWiseTopGainersLosersQuery = Depends()):
    # Call the procedure to retrieve industry-wise top gainers and losers data
    response = get_industry_top_gainers_losers(industry=query.industry)
    return response

    
@kse_data_router.get("/stock-to-industry")
def stock_to_industry(request: Request, query: StockAccuracyRequestRandomForest = Depends()):
    response = get_industry_by_psx_symbol(symbol=query.stock_symbol)
    return response