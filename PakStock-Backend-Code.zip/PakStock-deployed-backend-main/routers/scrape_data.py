from fastapi import APIRouter, HTTPException, Depends
from utility.kse_data_utils import validate_stock_symbol
from services.scrape_data_service import get_live_company_data, get_kse100_index_data
from pydantic_models.requests.companyInformationRequest import CompanyInformationRequest

scrape_router = APIRouter(prefix="/api")

# INPUT: stock_symbol
@scrape_router.get('/live-company-data')
async def get_live_company__data(query: CompanyInformationRequest = Depends()):
    response = await get_live_company_data(stock_symbol=query.stock_symbol)
    return response

@scrape_router.get('/kse100-data')
async def get_kse100_data():
    response = await get_kse100_index_data()
    return response
