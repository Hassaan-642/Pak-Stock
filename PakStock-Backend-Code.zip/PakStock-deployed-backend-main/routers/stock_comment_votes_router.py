from fastapi import APIRouter, HTTPException, Depends, Request
from services.stock_comment_votes_service import (
    create_stock_vote_service,
    get_stock_votes_service,
    delete_stock_vote_service,
)

from pydantic_models.requests.stockCommentVotesRequest import CreateStockCommentVoteRequest, GetStockVotesQuery, DeleteStockVoteQuery
from utility.firebase_utils import verify_jwt

stock_comment_votes_router = APIRouter(prefix="/api")

@stock_comment_votes_router.post("/stock-comment-vote")
async def create_vote(request: CreateStockCommentVoteRequest):
    """
    Create a new stock comment vote.
    """
    # Verify JWT and get decoded token
    # decoded_token = await verify_jwt(request)
    
    # # Skip user_id check for admins
    # if decoded_token.get('role') != 'Admin':
    #     # Check if user_id matches JWT uid
    #     if request.user_id != decoded_token.get('uid'):
    #         raise HTTPException(
    #             status_code=403,
    #             detail="User ID doesn't match token"
    #         )
        
    response = create_stock_vote_service(request.comment_id, request.user_id, request.username, request.isUpvote)
    return response


@stock_comment_votes_router.get("/stock-comment-votes")
def get_votes(query: GetStockVotesQuery = Depends()):
    """
    Get all votes for a specific comment.
    """
    response = get_stock_votes_service(query.comment_id) 
    return response


@stock_comment_votes_router.delete("/stock-comment-vote")
async def delete_vote(request: Request, query: DeleteStockVoteQuery = Depends()):
    """
    Delete a specific vote on a stock comment.
    """
    # decoded_token = await verify_jwt(request)
    
    # # Skip user_id check for admins
    # if decoded_token.get('role') != 'Admin':
    #     # Check if user_id matches JWT uid
    #     if query.user_id != decoded_token.get('uid'):
    #         raise HTTPException(
    #             status_code=403,
    #             detail="User ID doesn't match token"
    #         )
        
    response = delete_stock_vote_service(query.comment_id, query.user_id)
    return response
    
