from fastapi import APIRouter, HTTPException, Depends, Request
from services.stock_comment_service import (
    create_stock_comment_service,
    get_all_stock_comments_service,
    get_stock_comment_by_id_service,
    update_stock_comment_service,
    delete_stock_comment_service,
)

from pydantic_models.requests.stockCommentRequest import (
    CreateCommentRequest,
    GetCommentByIdQuery,
    GetAllCommentsQuery,
    UpdateCommentRequest,
    DeleteCommentQuery
)

from utility.firebase_utils import verify_jwt

stock_comment_router = APIRouter(prefix='/api')

# POST: Create Stock Comment
@stock_comment_router.post("/stock-comments")
async def create_stock_comment_route(request: CreateCommentRequest):
    try:
        # decoded_token = await verify_jwt(request)
    
        # # Skip user_id check for admins
        # if decoded_token.get('role') != 'Admin':
        #     # Check if user_id matches JWT uid
        #     if request.user_id != decoded_token.get('uid'):
        #         raise HTTPException(

        #             status_code=403,
        #             detail="User ID doesn't match token"
        #         )
            
        return create_stock_comment_service(request.stock_symbol, request.user_id, request.username, request.content, request.parent_comment_id)
    except HTTPException as e:
        raise e

# GET: Get All Comments for One Stock
@stock_comment_router.get("/stock-comments")
async def get_all_stock_comments_route(query: GetAllCommentsQuery = Depends()):
    try:
        return get_all_stock_comments_service(query.stock_symbol)
    except HTTPException as e:
        raise e

# GET: Get Comment by ID
@stock_comment_router.get("/stock-comment")
async def get_stock_comment_by_id_route(query: GetCommentByIdQuery = Depends()):
    try:
        return get_stock_comment_by_id_service(query.comment_id)
    except HTTPException as e:
        raise e

# PUT: Update Comment by ID
# user_id in request for JWT purposes
@stock_comment_router.put("/stock-comments")
async def update_stock_comment_route(request: UpdateCommentRequest):
    try:
        # decoded_token = await verify_jwt(request)
    
        # # Skip user_id check for admins
        # if decoded_token.get('role') != 'Admin':
        #     # Check if user_id matches JWT uid
        #     if request.user_id != decoded_token.get('uid'):
        #         raise HTTPException(

        #             status_code=403,
        #             detail="User ID doesn't match token"
        #         )
            
        return update_stock_comment_service(request.comment_id, request.content)
    except HTTPException as e:
        raise e

# DELETE: Delete Comment by ID
# user_id in query for JWT purposes
@stock_comment_router.delete("/stock-comments")
async def delete_stock_comment_route(request: Request, query: DeleteCommentQuery = Depends()):
    try:
        # decoded_token = await verify_jwt(request)
    
        # # Skip user_id check for admins
        # if decoded_token.get('role') != 'Admin':
        #     # Check if user_id matches JWT uid
        #     if query.user_id != decoded_token.get('uid'):
        #         raise HTTPException(

        #             status_code=403,
        #             detail="User ID doesn't match token"
        #         )
            
        return delete_stock_comment_service(query.comment_id)
    except HTTPException as e:
        raise e
