from fastapi import APIRouter, HTTPException, Depends, File, UploadFile
from services.user_article_images_service import (
    create_article_image_service,
    get_article_images_by_article_id_service,
    delete_article_image_by_id_service,
)
from pydantic_models.requests.userArticleImageRequests import CreateArticleImageQuery, GetArticleImagesByArticleIdQuery, DeleteArticleImageQuery
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from pydantic_models.requests.userPostsRequest import CreateUserPostRequest, GetUserPostQuery, UpdateUserPostRequest, UpdateUserPostQuery, DeleteUserPostQuery, CreateUserPostImageQuery
import aiofiles
from azure.storage.blob import BlobServiceClient
from io import BytesIO
from dotenv import load_dotenv
import imghdr


user_article_images_router = APIRouter(prefix='/api')

# Request Models

# Routes for Article Images
@user_article_images_router.post("/user-articles/images")
async def create_article_image(query: CreateArticleImageQuery = Depends(), image: UploadFile = File(...)):
    try:
        # Read the file contents
        file_content = await image.read()

        # Validate that the file is an image
        file_type = imghdr.what(None, h=file_content)
        if not file_type:
            raise HTTPException(status_code=400, detail="Invalid image file.")

        # Get file size
        print("File size (before upload):", len(file_content))

        created_image = await create_article_image_service(article_id = query.article_id, 
                                                           file_content = file_content,
                                                           file_name = image.filename,
                                                           content_type = image.content_type)
        
        return created_image
    except HTTPException as e:
        raise e

@user_article_images_router.get("/user-articles/images")
def get_article_images_by_article_id(query: GetArticleImagesByArticleIdQuery = Depends()):
    try:
        return get_article_images_by_article_id_service(query.article_id)
    except HTTPException as e:
        raise e

@user_article_images_router.delete("/user-articles/images")
def delete_article_image(query: DeleteArticleImageQuery = Depends()):
    try:
        delete_article_image_by_id_service(query.article_image_id)
        return {"message": "Article image deleted successfully."}
    except HTTPException as e:
        raise e
