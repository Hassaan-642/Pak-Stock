from fastapi import APIRouter, HTTPException, Depends, Request
from services.user_articles_service import (
    create_article_service,
    get_article_by_article_id_service,
    get_all_articles_service,
    update_article_service,
    delete_article_service,
    update_article_views_service
)
from pydantic_models.requests.userArticlesRequest import CreateArticleRequest, UpdateArticleRequest, GetArticleByIdQuery, UpdateArticleQuery, DeleteArticleQuery
from utility.firebase_utils import verify_jwt

user_articles_router = APIRouter(prefix='/api')



# Routes for Articles
@user_articles_router.post("/user-articles")
async def create_article(request: CreateArticleRequest):
    try:
        # decoded_token = await verify_jwt(request)
    
        # # Skip user_id check for admins
        # if decoded_token.get('role') != 'Admin':
        #     # Check if user_id matches JWT uid
        #     if request.user_id != decoded_token.get('uid'):
        #         raise HTTPException(

        #             status_code=403,
        #             detail="User ID doesn't match token"
        #         )
            
        return create_article_service(request.user_id, request.username, request.title, request.content)
        # return {"message": "Article created successfully."}
    except HTTPException as e:
        raise e

@user_articles_router.get("/user-article")
def get_article_by_id(query: GetArticleByIdQuery = Depends()):
    try:
        return get_article_by_article_id_service(query.article_id)
    except HTTPException as e:
        raise e

@user_articles_router.get("/user-articles")
def get_all_articles():
    try:
        return get_all_articles_service()
    except HTTPException as e:
        raise e

# Note, both title and content are optional
# request has user_id for JWT purposes
@user_articles_router.put("/user-articles")
async def update_article(request: UpdateArticleRequest, query: UpdateArticleQuery = Depends()):
    try:
        # decoded_token = await verify_jwt(request)
    
        # # Skip user_id check for admins
        # if decoded_token.get('role') != 'Admin':
        #     # Check if user_id matches JWT uid
        #     if request.user_id != decoded_token.get('uid'):
        #         raise HTTPException(

        #             status_code=403,
        #             detail="User ID doesn't match token"
        #         )
            
        return update_article_service(query.article_id, request.title, request.content)
        # return {"message": "Article updated successfully."}
    except HTTPException as e:
        raise e

# query has user_id for JWT purposes
@user_articles_router.delete("/user-articles")
async def delete_article(request: Request, query: DeleteArticleQuery = Depends()):
    try:
        # decoded_token = await verify_jwt(request)
    
        # # Skip user_id check for admins
        # if decoded_token.get('role') != 'Admin':
        #     # Check if user_id matches JWT uid
        #     if query.user_id != decoded_token.get('uid'):
        #         raise HTTPException(

        #             status_code=403,
        #             detail="User ID doesn't match token"
        #         )
            
        delete_article_service(query.article_id)
        return {"message": "Article deleted successfully."}
    except HTTPException as e:
        raise e
    
@user_articles_router.put("/user-articles/views")
def update_article_views(query: GetArticleByIdQuery = Depends()):
    try:
        return update_article_views_service(query.article_id)
    except HTTPException as e:
        raise e