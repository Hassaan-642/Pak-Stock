from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic_models.requests.userPostCommentRequest import (
    CreateUserPostCommentRequest,
    UpdateUserPostCommentRequest,
    GetAllUserPostCommentsQuery,
    UpdateUserPostCommentQuery,
    DeleteUserPostCommentQuery,
)
from services.user_post_comments_service import (
    create_user_post_comment_service,
    get_all_user_post_comments_service,
    update_user_post_comment_by_id_service,
    delete_user_post_comment_by_id_service,
)
from utility.firebase_utils import verify_jwt

# Define Router
user_post_comments_router = APIRouter(prefix="/api")


@user_post_comments_router.post("/user-post-comment")
async def create_user_post_comment_route(request: CreateUserPostCommentRequest):
    # decoded_token = await verify_jwt(request)
    
    # # Skip user_id check for admins
    # if decoded_token.get('role') != 'Admin':
    #     # Check if user_id matches JWT uid
    #     if request.user_id != decoded_token.get('uid'):
    #         raise HTTPException(

    #             status_code=403,
    #             detail="User ID doesn't match token"
    #         )
        
    response = create_user_post_comment_service(
        post_id=request.post_id,
        user_id=request.user_id,
        parent_comment_id=request.parent_comment_id,
        username=request.username,
        content=request.content,
    )
    return response


@user_post_comments_router.get("/user-post-comment")
def get_all_user_post_comments_route(query: GetAllUserPostCommentsQuery = Depends()):
    response = get_all_user_post_comments_service(post_id=query.post_id)
    return response

# request body has user_id for JWT purposes
@user_post_comments_router.put("/user-post-comment")
async def update_user_post_comment_route(request: UpdateUserPostCommentRequest, query: UpdateUserPostCommentQuery = Depends()):
    # decoded_token = await verify_jwt(request)
    
    # # Skip user_id check for admins
    # if decoded_token.get('role') != 'Admin':
    #     # Check if user_id matches JWT uid
    #     if request.user_id != decoded_token.get('uid'):
    #         raise HTTPException(

    #             status_code=403,
    #             detail="User ID doesn't match token"
    #         )
        
    response = update_user_post_comment_by_id_service(
        comment_id=query.comment_id,
        content=request.content,
    )
    return response

# query has user_id for JWT purposes
@user_post_comments_router.delete("/user-post-comment")
async def delete_user_post_comment_route(request: Request, query: DeleteUserPostCommentQuery = Depends()):
    # decoded_token = await verify_jwt(request)
    
    # # Skip user_id check for admins
    # if decoded_token.get('role') != 'Admin':
    #     # Check if user_id matches JWT uid
    #     if query.user_id != decoded_token.get('uid'):
    #         raise HTTPException(

    #             status_code=403,
    #             detail="User ID doesn't match token"
    #         )
        
    response = delete_user_post_comment_by_id_service(comment_id=query.comment_id)
    return response
