from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from pydantic_models.requests.userPostsRequest import CreateUserPostRequest, GetUserPostQuery, UpdateUserPostRequest, UpdateUserPostQuery, DeleteUserPostQuery, CreateUserPostImageQuery
from services.user_post_image_service import create_user_post_image_service, get_user_post_image_service
import aiofiles
from azure.storage.blob import BlobServiceClient
from io import BytesIO
from dotenv import load_dotenv
import imghdr

# Define Router
user_post_image_router = APIRouter(prefix="/api")

# CREATE user post image
@user_post_image_router.post("/user-post/image")
async def create_user_post_image_route(query: CreateUserPostImageQuery = Depends(), image: UploadFile = File(...)):
    try:
        # Read the file content **ONCE** and store it
        file_content = await image.read()

        # Validate that the file is an image
        file_type = imghdr.what(None, h=file_content)
        if not file_type:
            raise HTTPException(status_code=400, detail="Invalid image file.")

        # Get file size
        print("File size (before upload):", len(file_content))

        # Upload image to file storage, return response
        response = await create_user_post_image_service(
            post_id=query.post_id,
            file_content=file_content,
            filename=image.filename,
            content_type=image.content_type  # Pass the MIME type
        )
        return response
    
    except HTTPException as e:
        raise e

# GET user post image
@user_post_image_router.get("/user-post/image")
def get_user_post_image_route(query: CreateUserPostImageQuery = Depends()):
    try:
        response = get_user_post_image_service(post_id = query.post_id)
        print("get_user_post_router: ", response)
        return response
    
    except HTTPException as e:
        raise e