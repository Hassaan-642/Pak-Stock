from fastapi import APIRouter, Depends, UploadFile, File, Request, HTTPException
from pydantic_models.requests.userPostsRequest import CreateUserPostRequest, GetUserPostQuery, UpdateUserPostRequest, UpdateUserPostQuery, DeleteUserPostQuery, CreateUserPostImageQuery
from services.user_posts_service import create_user_post_service, get_user_post_service, update_user_post_service, delete_user_post_service, get_all_user_posts_service

from utility.firebase_utils import verify_jwt

# Define Router
user_posts_router = APIRouter(prefix="/api")

@user_posts_router.post("/user-post")
async def create_user_post_route(jwt_request: Request, request: CreateUserPostRequest):
    # decoded_token = await verify_jwt(jwt_request)
    
    # # Skip user_id check for admins
    # if decoded_token.get('role') != 'Admin':
    #     # Check if user_id matches JWT uid
    #     if request.user_id != decoded_token.get('uid'):
    #         raise HTTPException(

    #             status_code=403,
    #             detail="User ID doesn't match token"
    #         )
    response = create_user_post_service(title = request.title, content = request.content, user_id = request.user_id, username = request.username, picture_path = request.picture_path)
    return response

@user_posts_router.get("/user-post")
def get_user_post_route(query: GetUserPostQuery = Depends()):
    response = get_user_post_service(post_id = query.post_id)
    print("get_user_post_router: ", response)
    return response

# user_id in request for JWT purposes
@user_posts_router.put("/user-post")
async def update_user_post_route(request: UpdateUserPostRequest, query: UpdateUserPostQuery = Depends()):
    # decoded_token = await verify_jwt(request)
    
    # # Skip user_id check for admins
    # if decoded_token.get('role') != 'Admin':
    #     # Check if user_id matches JWT uid
    #     if request.user_id != decoded_token.get('uid'):
    #         raise HTTPException(

    #             status_code=403,
    #             detail="User ID doesn't match token"
    #         )
    response = update_user_post_service(post_id = query.post_id, title = request.title, content = request.content, picture_path = request.picture_path)
    return response

# user_id in query for JWT purposes
@user_posts_router.delete("/user-post")
async def delete_userpost_route(request: Request, query: DeleteUserPostQuery = Depends()):
    # decoded_token = await verify_jwt(request)
    
    # # Skip user_id check for admins
    # if decoded_token.get('role') != 'Admin':
    #     # Check if user_id matches JWT uid
    #     if query.user_id != decoded_token.get('uid'):
    #         raise HTTPException(

    #             status_code=403,
    #             detail="User ID doesn't match token"
    #         )
    response = delete_user_post_service(post_id = query.post_id)
    return response


@user_posts_router.get("/user-posts")
def get_all_posts_route():
    response = get_all_user_posts_service()
    return response