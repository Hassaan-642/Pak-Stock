from fastapi import HTTPException
from fastapi.responses import JSONResponse
from utility.kse_data_utils import get_industries_object
from database.procedures.processed_articles import get_processed_articles_by_industry_and_date, get_processed_articles_by_industry_and_date_count
import traceback

# Note, industry = {'banking', 'pharmaceuticals', etc.}
def get_articles(industry, days):
    try:
        # Iterate over the async generator to get the session
        articles = get_processed_articles_by_industry_and_date(
            industry=industry,
            days=days
        )
        
        if len(articles) == 0:
            print(f"No articles found for {industry}")
            return []
        print("Articles:", articles)
        return articles

    except Exception as e:
        # Handle unexpected errors
        print(f'\n Error in get_articles: {str(e)} \n')
        raise HTTPException(status_code=500, detail="Internal Server Error")

def get_sentiment(industry, days):
    try:
        model_results = get_processed_articles_by_industry_and_date_count(industry, days)
        
        if not model_results:
            print(f"No articles found for {industry}")
            return []

        sentiment_by_model = {}

        for row in model_results:
            model_name = row['model']
            pos = row['positive_count']
            neg = row['negative_count']
            neu = row['neutral_count']
            total = pos + neg + neu

            if total == 0:
                continue

            sentiment_by_model[model_name] = {
                "positive": pos,
                "neutral": neu,
                "negative": neg,
                "positive_percentage": (pos / total) * 100,
                "neutral_percentage": (neu / total) * 100,
                "negative_percentage": (neg / total) * 100
            }

        return sentiment_by_model

    except Exception as e:
        print(f'\nError in /api/sentiment: {str(e)}\n')
        raise HTTPException(status_code=500, detail="Internal Server Error")