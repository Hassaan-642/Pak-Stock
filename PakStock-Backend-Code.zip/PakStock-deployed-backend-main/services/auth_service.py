from fastapi import HTTPException
from fastapi.responses import JSONResponse
from database.procedures.user import get_user_by_email, create_user, get_user_by_id, confirm_user_email
from database.procedures.otp import validate_otp
from utility.auth_utils import hash_password, verify_password, verify_jwt, create_access_token, send_otp
import traceback
from database.schemas.user import User
import jwt

# Check if the email is already registered
# If not registered, logs it and sends OTP
# If registered, checks if the user is confirmed
# If confirmed, returns error
# If not confirmed, returns JWT token
def register_user(username: str, email: str, password: str):
    try:
        existing_user = get_user_by_email(email)

        if existing_user:
            if existing_user.confirmed == True:
                raise ValueError("Email already registered")
            elif existing_user.confirmed == False:
                # Generate JWT token
                jwt_token = create_access_token({
                    "uid": existing_user.uid,
                    "username": existing_user.username,
                    "email": existing_user.email,
                    "role": existing_user.role,
                    "confirmed": existing_user.confirmed
                })

                return_object = {
                    "uid": existing_user.uid,
                    "username": existing_user.username,
                    "email": existing_user.email,
                    "role": existing_user.role,
                    "confirmed": existing_user.confirmed,
                    "jwt": jwt_token
                }

                return JSONResponse(content={"detail": "Email already registered", "user": return_object}, status_code=200)
                

        # Hash password
        hashed_password = hash_password(password)
        
        # Create new user with confirmed=False
        new_user = create_user(username, email, hashed_password)

        # Generate JWT token
        jwt_token = create_access_token({
            "uid": new_user.uid,
            "username": new_user.username,
            "email": new_user.email,
            "role": new_user.role,
            "confirmed": new_user.confirmed
        })

        return_object = {
            "uid": str(new_user.uid),
            "username": new_user.username,
            "email": new_user.email,
            "role": new_user.role,
            "confirmed": new_user.confirmed,
            "jwt": jwt_token
        }

        return JSONResponse(content=return_object, status_code=200) 
    except ValueError as e:
        traceback.print_exc()
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        traceback.print_exc()
        raise e
    
def verify_account(otp_code: str, payload: dict) -> dict:
    try:
        """
        Handles OTP verification and account confirmation.
        """
        # Step 1: Decode the JWT to get the user_id and check email verification status
        user_id = payload.get("uid")
        email_verified = payload.get("confirmed")
        print("Email verified type: ", type(email_verified))

        # Step 2: If email is already verified, raise an error
        if email_verified:
            raise HTTPException(status_code=400, detail="Email already verified.")

        # Step 3: Validate the OTP
        if not validate_otp(user_id=user_id, otp_code=otp_code, purpose="email_verification"):
            raise HTTPException(status_code=400, detail="Invalid OTP")

        # Step 4: Mark email as verified and generate a new JWT
        user_info = confirm_user_email(user_id)
        if "error" in user_info:
            raise HTTPException(status_code=400, detail=user_info["error"])

        # Create a new JWT with email_verified: True
        new_token_data = {
            "uid": user_info["uid"],
            "username": user_info["username"],
            "email": user_info["email"],
            "role": user_info["role"],
            "confirmed": user_info["confirmed"]
        }

        new_jwt_token = create_access_token(new_token_data)

        # Step 5: Return the user information and new JWT
        user_info["jwt"] = new_jwt_token
        return user_info
    except Exception as e:
        traceback.print_exc()
        raise e

def send_verification_otp(decoded_data: dict) -> dict:
    """
    Handles the resend OTP request. Verifies JWT and resends the OTP if valid.
    """
    try:
        # Step 1: Decode the JWT
        # decoded_data = decode_jwt_token(jwt_token)
        # if not decoded_data:
        #     raise HTTPException(status_code=400, detail="Invalid or expired JWT token.")

        user_id = decoded_data.get("uid")
        email_verified = decoded_data.get("confirmed")
        print("Email verified type: ", type(email_verified))
        print("Email verified: ", email_verified)

        # Step 2: Check if the email is already verified
        if email_verified:
            # print("Is email_verified: ", email_verified)
            raise HTTPException(status_code=400, detail="Email already verified.")

        # Step 3: Get user information
        user: User = get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=400, detail="User not found.")
        
        print("User: ", user)
        
        send_otp(user, user.email, "email_verification")
        
        return JSONResponse(content={"message": "OTP sent successfully."}, status_code=200)
    except jwt.ExpiredSignatureError:
        print("Token expired")
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        print("Invalid token")
        raise HTTPException(status_code=401, detail="Invalid token") 
    except Exception as e:
        traceback.print_exc()
        raise e
    
def send_2fa_otp(payload: dict) -> dict:
    try:
        user_id = payload.get("uid")
        email_verified = payload.get("confirmed")

        # Step 2: Check if the email is already verified
        if not email_verified:
            raise HTTPException(status_code=400, detail="Email not verified.")

        # Step 3: Get user information
        user = get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=400, detail="User not found.")
        
        send_otp(user, user.email, "2fa")
        
        return JSONResponse(content={"message": "OTP sent successfully."}, status_code=200)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token") 
    except Exception as e:
        traceback.print_exc()
        raise e

def verify_2fa(otp_code: str, payload: dict) -> dict:
    try:
        user_id = payload.get("uid")
        email_verified = payload.get("confirmed")

        # Step 2: Check if the email is already verified
        if not email_verified:
            raise HTTPException(status_code=400, detail="Email not verified.")

        # Step 3: Validate the OTP
        if not validate_otp(user_id, otp_code, "2fa"):
            raise HTTPException(status_code=400, detail="Invalid OTP")

        # Step 4: Generate a new JWT
        user_info = get_user_by_id(user_id)
        if not user_info:
            raise HTTPException(status_code=400, detail="User not found.")
        
        new_token_data = {
            "uid": user_info.uid,
            "username": user_info.username,
            "email": user_info.email,
            "role": user_info.role,
            "confirmed": user_info.confirmed
        }

        new_jwt_token = create_access_token(new_token_data)

        return {
            "uid": user_info.uid,
            "username": user_info.username,
            "email": user_info.email,
            "role": user_info.role,
            "confirmed": user_info.confirmed,
            "jwt": new_jwt_token
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token") 
    except Exception as e:
        traceback.print_exc()
        raise e

def login(emaiL: str, password: str):
    try:
        user = get_user_by_email(emaiL)
        if not user:
            raise HTTPException(status_code=400, detail="Invalid email or password.")
        
        if not verify_password(password, user.password_hash):
            raise HTTPException(status_code=400, detail="Invalid email or password.")
        
        if not user.confirmed:
            raise HTTPException(status_code=400, detail="Email not verified.")

        jwt_token = create_access_token({
            "uid": user.uid,
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "confirmed": user.confirmed
        })

        return_object = {
            "uid": str(user.uid),
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "confirmed": user.confirmed,
            "jwt": jwt_token
        }

        return JSONResponse(content=return_object, status_code=200)
    except HTTPException as e:
        traceback.print_exc()
        raise e
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error")