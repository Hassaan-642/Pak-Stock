from huggingface_hub import InferenceClient
import os
from dotenv import load_dotenv
from database.vector_db_procedures import query_collection

load_dotenv()
token = os.getenv('HUGGINGFACE_API_KEY')

class LLM:
    models = {
        'mistral7b': 'mistralai/Mistral-7B-Instruct-v0.3',
        'phi': 'microsoft/Phi-3.5-MoE-instruct'
    }

    chat_completion_args = {
        "max_tokens": 1024,
        "temperature": 0.01,
        "top_p": 0.95
    }

    system_prompt = """    
        You are an intelligent assistant.
        1. **Answer user questions**: User queries will be in the form :Context: \n\n Query: :Use the context to answer the query accurately. If the question is unclear, ask the user for clarification.
        2. **Do not Reference the Context**: Do not mention the context in your responses.
        """

    def __init__(self):
        self.client = InferenceClient(
            model=self.models['mistral7b'],
            token=token,
        )

    def process_query(self, user_query):
        """
        Handles a conversation, creating a new one if none exists, or continuing an existing one.
        Uses the `get_context` function to retrieve relevant context for all queries.

        :param user_query: The user's new question or input.
        :param conversation: A list of messages representing the prior conversation (if any).
        :return: The updated conversation, including the new user query and the assistant's response.
        """
        # Retrieve context for the current query
        context = query_collection(user_query)

        conversation = [
            {"role": "system", "content": self.system_prompt},
        ]

        # Add the user's query
        conversation.append(
            {"role": "user", "content": f"Context:{context} \n\n #### Query:{user_query}"}
        )

        # Generate the assistant's response
        try:
            message = self.client.chat_completion(
                messages=conversation,
                **self.chat_completion_args
            )
        except Exception as e:
            raise RuntimeError(f"Error during chat completion: {e}")

        # Extract the response content
        assistant_response = message["choices"][0]["message"]["content"]

        # Add the assistant's response to the conversation
        conversation.append({"role": "assistant", "content": assistant_response})

        return {"response": assistant_response, "conversation": conversation}
