from fastapi import HTTPException
from utility.kse_data_utils import get_kse_companies_object, get_stock_symbols, get_all_stock_symbols_for_specified_industry
# import os
from services.scrape_data_service import fetch_company_data
# from pydantic_models.requests.detailedCategoryInformation import DetailedCategoryRequest
import traceback
from utility.kse_data_utils import get_image, get_image_b64_encoded
# from utility.scrape_utils import Proxies
# import base64
from database.procedures.live_company_data import get_live_company_data
from database.procedures.kse100_index import get_latest_kse100_index_data
from database.procedures.live_company_data import get_live_company_data
from database.procedures.historical_kse100_data import get_historical_kse100_data

def get_category_info():
    response = get_kse_companies_object()
    return response 

def get_stock_image(stock_symbol: str):
    try:
        image = get_image(stock_symbol=stock_symbol)

        return image
    
    except Exception as e:
        print("Error in get_stock_image: ", e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error")

def get_category_info_detailed(industry: str):
    try:
        companies_object_filtered_to_category = get_kse_companies_object()
        companies_object_filtered_to_category = companies_object_filtered_to_category[industry]
        # proxyObject = Proxies(max_retries=3, timeout_seconds=10)
        # proxyObject.refresh_proxies()

        for company in companies_object_filtered_to_category:
            symbol = company['symbol']
            company_data = get_live_company_data(symbol)
            company_data['image'] = get_image_b64_encoded(stock_symbol=symbol.upper())

            
            # Add the fetched data to the company object
            company.update(company_data)
        
        return companies_object_filtered_to_category
    except Exception as e:
        print("Error in get_category_info_detailed: ", e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error")

def get_latest_kse100_data():
    try:
        kse100_data = get_latest_kse100_index_data()
        return kse100_data
    except Exception as e:
        print("Error in get_latest_kse100_data: ", e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error")

def get_historical_kse100_data_service(days: int):
    try:
        historical_kse100_data = get_historical_kse100_data(days)
        return historical_kse100_data
    except Exception as e:
        print("Error in get_historical_kse100_data: ", e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error")


def get_industry_top_gainers_losers(industry: str):
    try:
        # First, get the stock symbols for the given industry
        stock_symbols = get_all_stock_symbols_for_specified_industry(industry)

        # Next, fetch the company data for each stock symbol
        company_data = []

        for stock_symbol in stock_symbols:
            company_data.append(get_live_company_data(stock_symbol))
        
        # Split in two based on change_direction = 'up' or 'down'
        top_gainers = []
        top_losers = []

        for company in company_data:
            if company['change_direction'] == 'up':
                top_gainers.append(company)
            else:
                top_losers.append(company)
        
        # Sort the top_gainers and top_losers based on change_percentage in Desc order
        top_gainers = sorted(top_gainers, key=lambda x: x['change_percentage'], reverse=True)
        top_losers = sorted(top_losers, key=lambda x: x['change_percentage'], reverse=True)

        return { "top_gainers": top_gainers, "top_losers": top_losers }

    
    except Exception as e:
        print("Error in get_industry_top_gainers_losers: ", e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error")
