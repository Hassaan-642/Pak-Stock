from fastapi.responses import JSONResponse
import requests
from bs4 import BeautifulSoup
import time
from fastapi import HTTPException
import traceback
import httpx
from utility.kse_data_utils import get_image_b64_encoded
from utility.scrape_utils import Proxies

# Function to fetch HTML content from a URL
async def fetch_data(url: str):
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            response.raise_for_status()
            return BeautifulSoup(response.content, 'html.parser')
    except Exception as e:
        print("Error in fetch_data: ", e)
        raise HTTPException(detail="Internal Server Error", status_code=500)


async def get_live_company_data(stock_symbol):
    try:
        data = await fetch_company_data(stock_symbol)

        data['image'] = get_image_b64_encoded(stock_symbol=stock_symbol)

        return JSONResponse(content=data, status_code=200)

    except Exception as e:
        traceback.print_exc()
        raise e

# Function to fetch company data
async def fetch_company_data(company, proxyObject=None):
    url = f'https://dps.psx.com.pk/company/{company}'
    close_quote_data = None
    if proxyObject is None:
        proxyObject = Proxies(max_retries=3, timeout_seconds=10)
        proxyObject.refresh_proxies()
    
    session = proxyObject.create_session()
    
    for attempt in range(1, proxyObject.MAX_RETRIES + 1):
        try:
            response = session.get(url, timeout=proxyObject.TIMEOUT_SECONDS)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')

            # Get close quote
            close_quote = soup.find(class_='quote__close')

            # Get change details
            change_section = soup.find(class_='quote__change')

            # Handle missing change_direction icon
            change_direction_icon = change_section.find('div', class_='change__direction').find('i')
            if change_direction_icon:
                change_direction = 'up' if 'up' in change_direction_icon['class'][0] else 'down'
            else:
                change_direction = 'unknown'  # Handle case where the icon is missing

            # Get the value and percentage change
            change_value = change_section.find(class_='change__value').text.strip()
            change_percentage = change_section.find(class_='change__percent').text.strip()

            # Find the umbrella div for stats
            stats = soup.find('div', class_='stats stats--wrappable')

            # Initialize variables for stats
            market_cap = None
            shares = None
            free_float_volume = None
            free_float_percentage = None

            # Iterate through each stats_item to extract values
            for item in stats.find_all('div', class_='stats_item'):
                label = item.find('div', class_='stats_label').text.strip()
                value = item.find('div', class_='stats_value').text.strip()

                if 'Market Cap' in label:
                    market_cap = value
                elif 'Shares' in label:
                    shares = value
                elif 'Free Float' in label:
                    if '%' in value:
                        free_float_percentage = value
                    else:
                        free_float_volume = value

            current_time = time.strftime('%Y-%m-%d %H:%M:%S')

            if close_quote is not None:
                close_quote_data = {
                    'company': company,
                    'time': current_time,
                    'close_quote': close_quote.text.strip(),
                    'change_direction': change_direction,
                    'change_value': change_value,
                    'change_percentage': change_percentage,
                    'market_cap': market_cap,
                    'shares': shares,
                    'free_float_volume': free_float_volume,
                    'free_float_percentage': free_float_percentage
                }

                return close_quote_data

        except httpx._exceptions.RequestError as e:
            print(f"Attempt {attempt} for fetch_company_data failed: {e}")
            if attempt < proxyObject.MAX_RETRIES:
                proxyObject.remove_proxy()
                session = proxyObject.create_session()
                wait_time = 2
                print(f"Retrying after {wait_time} seconds...")
                time.sleep(wait_time)

        except Exception as e:
            print(f"Error fetching data for {company}: {e}")
            # Return a message indicating an internal server error for this company
            return {"company": company, "error": "Internal Server Error"}

async def get_kse100_index_data():
    try:
        data = await fetch_kse100_index_data()

        if data is not None:
            return JSONResponse(content=data, status_code=200)
        else:
            raise HTTPException(status_code=500, detail="Internal Server Error")

    except Exception as e:
        traceback.print_exc()
        raise e


# Function to fetch KSE 100 index data
async def fetch_kse100_index_data(proxyObject = None):
    url = 'https://dps.psx.com.pk'

    if proxyObject is None:
        proxyObject = Proxies(max_retries=3, timeout_seconds=10)
        proxyObject.refresh_proxies()
    
    session = proxyObject.create_session()
    
    for attempt in range(1, proxyObject.MAX_RETRIES + 1):
        try:
            response = session.get(url, timeout=proxyObject.TIMEOUT_SECONDS)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')

            kse100_data = {}

            kse100_panel = soup.find('div', class_='tabs__panel marketIndices__details')
            if kse100_panel:
                # Extract the market index price
                index_price_element = kse100_panel.find('h1', class_='marketIndices__price')
                if index_price_element:
                    kse100_data['index_value'] = index_price_element.text.strip().split()[0]  # Get the price part only

                    # Extract the change value and determine if it's up or down
                    change_element = index_price_element.find('span', class_='marketIndices__change')
                    if change_element:
                        kse100_data['index_change'] = change_element.text.strip()

                        # Check if the icon indicates up or down
                        if change_element.find('i', class_='icon-down-dir'):
                            kse100_data['index_direction'] = 'down'
                        elif change_element.find('i', class_='icon-up-dir'):
                            kse100_data['index_direction'] = 'up'
                        else:
                            kse100_data['index_direction'] = 'unknown'

                # Extract other stats (high, low, volume, etc.)
                kse100_data['high'] = kse100_panel.find('div', class_='stats_label', text='High').find_next('div', class_='stats_value').text.strip()
                kse100_data['low'] = kse100_panel.find('div', class_='stats_label', text='Low').find_next('div', class_='stats_value').text.strip()
                kse100_data['volume'] = kse100_panel.find('div', class_='stats_label', text='Volume').find_next('div', class_='stats_value').text.strip()
                kse100_data['1_year_change'] = kse100_panel.find('div', class_='stats_label', text='1-Year Change').find_next('div', class_='stats_value').text.strip()
                kse100_data['ytd_change'] = kse100_panel.find('div', class_='stats_label', text='YTD Change').find_next('div', class_='stats_value').text.strip()
                kse100_data['previous_close'] = kse100_panel.find('div', class_='stats_label', text='Previous Close').find_next('div', class_='stats_value').text.strip()
                
                # Extract the market index date
                date_element = soup.find('div', class_='marketIndices__date')
                if date_element:
                    kse100_data['date'] = date_element.text.strip()

            return kse100_data

        except Exception as e:
            print(f"Error fetching KSE 100 data: {e}")
            traceback.print_exc()
            raise HTTPException(detail="Internal Server Error", status_code=500)
        
        except httpx._exceptions.RequestError as e:
            print(f"Attempt {attempt} for fetch_company_data failed: {e}")
            if attempt < proxyObject.MAX_RETRIES:
                proxyObject.remove_proxy()
                session = proxyObject.create_session()
                wait_time = 2
                print(f"Retrying after {wait_time} seconds...")
                time.sleep(wait_time)