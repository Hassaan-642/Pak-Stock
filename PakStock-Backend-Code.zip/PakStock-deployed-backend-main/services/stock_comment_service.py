from database.schemas.stock_comments import StockComments
from peewee import DoesNotExist
from fastapi import HTTPException
import traceback

from database.procedures.stock_comments import (
    create_stock_comment,
    get_all_stock_comments,
    get_stock_comment_by_id,
    update_stock_comment_by_id,
    delete_stock_comment_by_id,
)

# Service: Create Stock Comment
def create_stock_comment_service(stock_symbol, user_id, username, content, parent_comment_id):
    try:
        success = create_stock_comment(stock_symbol, user_id, username, content, parent_comment_id)
        return {"success": success, "message": "Comment created successfully"}
    except HTTPException as e:
        traceback.print_exc()
        raise e
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Unable to create comment.")

# Service: Get All Comments for a Stock
def get_all_stock_comments_service(stock_symbol):
    try:
        comments = get_all_stock_comments(stock_symbol)
        if not comments:
            raise HTTPException(status_code=404, detail="No comments found for this stock.")
        return comments
    except HTTPException as e:
        traceback.print_exc()
        raise e
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Unable to fetch comments.")

# Service: Get Comment by ID
def get_stock_comment_by_id_service(comment_id):
    try:
        comment = get_stock_comment_by_id(comment_id)
        if not comment:
            raise HTTPException(status_code=404, detail="Comment not found.")
        return comment
    except HTTPException as e:
        traceback.print_exc()
        raise e
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Unable to fetch comment.")

# Service: Update Comment by ID
def update_stock_comment_service(comment_id, content):
    try:
        success = update_stock_comment_by_id(comment_id, content)
        if not success:
            raise HTTPException(status_code=404, detail="Comment not found.")
        return {"success": success, "message": "Comment updated successfully"}
    except HTTPException as e:
        traceback.print_exc()
        raise e
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Unable to update comment.")

# Service: Delete Comment by ID
def delete_stock_comment_service(comment_id):
    try:
        success = delete_stock_comment_by_id(comment_id)
        if not success:
            raise HTTPException(status_code=404, detail="Comment not found.")
        return {"success": success, "message": "Comment deleted successfully"}
    except HTTPException as e:
        traceback.print_exc()
        raise e
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Unable to delete comment.")
