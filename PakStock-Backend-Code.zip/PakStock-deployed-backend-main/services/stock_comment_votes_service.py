# services/stock_comment_votes_service.py
from fastapi import HTTPException
from fastapi.responses import JSONResponse
from peewee import DoesNotExist, IntegrityError
from database.procedures.stock_comment_votes import *
import traceback


def create_stock_vote_service(comment_id, user_id, username, isUpvote):
    """
    Create a new stock comment vote.
    """
    try:
        is_successful = create_stock_comment_vote(comment_id, user_id, username, isUpvote)

        if(is_successful):
            return JSONResponse(status_code=201, content={"detail": "Vote created successfully"})
    
    except Exception as e:
        traceback.print_exc()
        return e
        
def get_stock_votes_service(comment_id):
    """
    Retrieve all votes for a given comment.
    """
    try:
        votes = get_stock_comment_votes(comment_id)
        return JSONResponse(status_code=200, content=votes)
    except Exception as e:
        traceback.print_exc()
        raise e

def delete_stock_vote_service(comment_id, user_id):
    """
    Delete a stock comment vote.
    """
    try:
        is_successful = delete_stock_comment_vote(comment_id, user_id) 
        
        if(is_successful):
            return JSONResponse(status_code=200, content={"detail": "Vote deleted successfully"})
    except Exception as e:
        traceback.print_exc()
        raise e 
