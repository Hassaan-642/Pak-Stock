import traceback
from database.procedures.user_article_images import (
    create_article_image,
    get_article_images_by_article_id,
    delete_article_image_by_id,
)
from database.schemas.user_article_images import UserArticleImages
from fastapi import UploadFile, HTTPException
import uuid
import os
import aiofiles
from utility.filestorage_utils import *
from database.schemas.articles import UserArticles
from database.procedures.user_articles import get_article_by_article_id

# Ensure the upload folder is set
UPLOAD_FOLDER = os.getenv("USER_ARTICLE_IMAGE_UPLOAD_FOLDER")
USERIMAGE_CONTAINER = os.getenv("AZUREFILESTORAGE_USERIMAGES_CONTAINER")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Create the upload folder if it doesn't exist
ARTICLE_IMAGE_SAS_URL_VALID = 720 # 30d


async def create_article_image_service(article_id: str, file_name: str, content_type: str, file_content: bytes):
    try:
        # Confirm whether article exists
        article = get_article_by_article_id(article_id)

        # Extract the file extension
        file_extension = os.path.splitext(file_name)[1]  # Example: ".jpg", ".png"

        # Ensure the extension exists (default to ".jpg" if missing)
        if not file_extension:
            file_extension = ".jpg"  

        # Generate a unique filename with extension
        filestorage_file_name = f"{uuid.uuid4()}{file_extension}"

        # Save the relative file path to the database (if needed)
        created_image_details = create_article_image(article_id=article_id, image_path=filestorage_file_name)

        # Normally, we would save the file to the storage by its actual name (file_name). But,
        # since we have a uuid for the image id, we use that

        # Get blob client
        blob_client = get_blob_client_util(filestorage_file_name)

        # Upload the file to the file storage
        upload_file_to_filestorage(file_content=file_content, 
                                   file_name=filestorage_file_name, 
                                   content_type=content_type,
                                   blob_client=blob_client)
        
        sas_url = generate_blob_sas_url(blob_client=blob_client,
                                        container_name=USERIMAGE_CONTAINER,
                                        file_name=filestorage_file_name,
                                        account_key=blob_service_client.credential.account_key,
                                        permissions=BlobSasPermissions(read=True),
                                        expiry=datetime.utcnow() + timedelta(hours=ARTICLE_IMAGE_SAS_URL_VALID))

        return {
            "image_data": {
                "image_url": sas_url, 
                "image_details": created_image_details
                }, 
            "message": "Article image created successfully."
        }
    
    except UserArticles.DoesNotExist:
        raise HTTPException(status_code=404, detail="Article not found.")
    
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")


def get_article_images_by_article_id_service(article_id: str):
    try:
        # Confirm whether images exist
        image_dicts = get_article_images_by_article_id(article_id)

        # Generate SAS URLs for each image
        for image_dict in image_dicts:
            blob_client = get_blob_client_util(image_dict["image_path"])
            sas_url = generate_blob_sas_url(blob_client=blob_client,
                                            container_name=USERIMAGE_CONTAINER,
                                            file_name=image_dict["image_path"],
                                            account_key=blob_service_client.credential.account_key,
                                            permissions=BlobSasPermissions(read=True),
                                            expiry=datetime.utcnow() + timedelta(hours=ARTICLE_IMAGE_SAS_URL_VALID))
            image_dict["image_url"] = sas_url
            print(image_dict)
        
        return image_dicts
    
    except UserArticles.DoesNotExist:
        raise HTTPException(status_code=404, detail="Article not found.")
    
    except Exception as e:
        traceback.print_exc()
        raise e

def delete_article_image_by_id_service(article_image_id: str):
    try:

        # Delete the database entry
        delete_article_image_by_id(article_image_id)

        # Delete the filestorage entry
        blob_client = get_blob_client_util(article_image_id)
        blob_client.delete_blob()

        return True
    except Exception as e:
        traceback.print_exc()
        raise e
