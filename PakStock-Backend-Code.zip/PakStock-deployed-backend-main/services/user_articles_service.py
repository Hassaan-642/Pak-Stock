import traceback
from fastapi import HTTPException
from fastapi.responses import JSONResponse
from database.procedures.user_articles import (
    create_article,
    get_article_by_article_id,
    get_all_articles,
    update_article,
    delete_article,
    update_article_views
)

def create_article_service(user_id: str, username: str, title: str, content: str):
    try:
        return create_article(user_id, username, title, content)
    except Exception as e:
        traceback.print_exc()
        raise e

def get_article_by_article_id_service(article_id: str):
    try:
        return get_article_by_article_id(article_id)
    except Exception as e:
        traceback.print_exc()
        raise e

def get_all_articles_service():
    try:
        return get_all_articles()
    except Exception as e:
        traceback.print_exc()
        raise e

def update_article_service(article_id: str, title: str, content: str):
    try:
        if title == None and content == None:
            raise HTTPException(status_code=400, detail="At least one of title or content must be provided.")
        
        return update_article(article_id, title, content)
    except Exception as e:
        traceback.print_exc()
        raise e

def delete_article_service(article_id: str):
    try:
        return delete_article(article_id)
    except Exception as e:
        traceback.print_exc()
        raise e

def update_article_views_service(article_id: str):
    try:
        
        return update_article_views(article_id)
        
    except Exception as e:
        traceback.print_exc()
        raise e