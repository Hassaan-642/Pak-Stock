from fastapi.responses import JSONResponse
from fastapi import HTTPException
import traceback
from database.procedures.user_post_comment_votes import (
    create_user_post_comment_vote,
    get_user_post_comment_votes,
    delete_user_post_comment_vote,
)


def create_user_post_comment_vote_service(comment_id, user_id, username, isUpvote):
    try:
        create_user_post_comment_vote(comment_id=comment_id, user_id=user_id, username=username, isUpvote=isUpvote)
        return JSONResponse(content={"message": "Vote created successfully."})

    except HTTPException as e:
        traceback.print_exc()
        raise e

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error.")


def get_user_post_comment_votes_service(comment_id):
    try:
        votes = get_user_post_comment_votes(comment_id=comment_id)
        if not votes:
            raise HTTPException(status_code=404, detail="No votes found for this comment.")
        # print(votes)
        for vote in votes:
            print(vote)
            vote["date_created"] = vote["date_created"].strftime("%Y-%m-%d %H:%M:%S")

        # votes_list = [{"user_id": vote.user_id, "isUpvote": vote.isUpvote} for vote in votes]
        return JSONResponse(content={"votes": votes})

    except HTTPException as e:
        traceback.print_exc()
        raise e

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error.")


def delete_user_post_comment_vote_service(comment_id, user_id):
    try:
        delete_user_post_comment_vote(comment_id=comment_id, user_id=user_id)
        return JSONResponse(content={"message": "Vote deleted successfully."})

    except HTTPException as e:
        traceback.print_exc()
        raise e

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Internal Server Error.")
