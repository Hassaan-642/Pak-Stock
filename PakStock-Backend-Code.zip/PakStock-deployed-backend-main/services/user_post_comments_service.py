from fastapi import HTTPException
from fastapi.responses import JSONResponse
import traceback
from database.procedures.user_post_comments import (
    create_user_post_comment,
    get_all_user_post_comments,
    get_user_post_comment_by_id,
    update_user_post_comment_by_id,
    delete_user_post_comment_by_id,
)


def create_user_post_comment_service(post_id, user_id, username, content, parent_comment_id):
    try:
        create_user_post_comment(post_id=post_id, user_id=user_id, username=username, content=content, parent_comment_id=parent_comment_id)
        return JSONResponse(content={"message": "Comment created successfully."})

    except Exception as e:
        traceback.print_exc()
        raise e


def get_all_user_post_comments_service(post_id):
    try:
        comments = get_all_user_post_comments(post_id)
        if not comments:
            raise HTTPException(status_code=404, detail="No comments found for this post.")
        
        return JSONResponse(content={"comments": comments})

    except Exception as e:
        traceback.print_exc()
        raise e


def get_user_post_comment_by_id_service(comment_id):
    try:
        comment = get_user_post_comment_by_id(comment_id)
        if not comment:
            raise HTTPException(status_code=404, detail="Comment not found.")
        
        return JSONResponse(content={"comment": comment})

    except Exception as e:
        traceback.print_exc()
        raise e


def update_user_post_comment_by_id_service(comment_id, content):
    try:
        response = update_user_post_comment_by_id(comment_id=comment_id, content=content)
        return JSONResponse(content={"message": "Comment updated successfully.", "new_comment": response})

    except Exception as e:
        traceback.print_exc()
        raise e


def delete_user_post_comment_by_id_service(comment_id):
    try:
        delete_user_post_comment_by_id(comment_id=comment_id)
        return JSONResponse(content={"message": "Comment deleted successfully."})

    except Exception as e:
        traceback.print_exc()
        raise e
