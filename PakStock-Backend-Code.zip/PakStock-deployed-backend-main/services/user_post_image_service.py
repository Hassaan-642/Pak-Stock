from database.schemas.user_posts import UserPosts
from fastapi import HTTPException
from fastapi.responses import JSONResponse
import traceback
from database.procedures.user_posts import (
    update_user_post_image_path,
    get_user_post
)
from datetime import datetime, timedelta
import uuid
import os
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv
from azure.storage.blob import generate_blob_sas, BlobSasPermissions, ContentSettings
from urllib.parse import quote
from utility.filestorage_utils import * 

load_dotenv()

# Ensure the upload folder is set
UPLOAD_FOLDER = os.getenv("USER_ARTICLE_IMAGE_UPLOAD_FOLDER")
CONNECTION_STRING = os.getenv("AZUREFILESTORAGE_CONNECTION_STRING")
USERIMAGE_CONTAINER = os.getenv("AZUREFILESTORAGE_USERIMAGES_CONTAINER")

# Initialize the BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
container_client = blob_service_client.get_container_client(USERIMAGE_CONTAINER)


async def create_user_post_image_service(post_id: str, file_content: bytes, filename: str, content_type: str):
    try:
        # Ensure the post_id is valid
        post = get_user_post(post_id)

        if not file_content:
            raise HTTPException(status_code=400, detail="No file uploaded or file is empty")

        # Extract the file extension
        file_extension = os.path.splitext(filename)[1]  # Example: ".jpg", ".png"

        # Ensure the extension exists (default to ".jpg" if missing)
        if not file_extension:
            file_extension = ".jpg"  

        # Generate a unique filename with extension
        file_name = f"{uuid.uuid4()}{file_extension}"

        blob_client = get_blob_client_util(file_name)

        # Upload the file to the file storage
        upload_file_to_filestorage(blob_client=blob_client ,file_content=file_content, file_name=file_name, content_type=content_type)
        
        # Save only the blob name in the database
        created_image_details = update_user_post_image_path(post_id=post_id, picture_path=file_name)

        sas_url = generate_blob_sas_url(blob_client=blob_client, 
                                        container_name=USERIMAGE_CONTAINER, 
                                        file_name=file_name, 
                                        account_key=blob_service_client.credential.account_key, 
                                        permissions=BlobSasPermissions(read=True), 
                                        expiry=datetime.utcnow() + timedelta(hours=1))

        return {
            "image_data": {
                "image_url": sas_url, 
                "image_details": created_image_details
            }, 
            "message": "User post image created successfully."
        }

    except UserPosts.DoesNotExist:
        raise HTTPException(status_code=404, detail="Post not found.")

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")

def get_user_post_image_service(post_id: str):
    try:
        post = get_user_post(post_id)

        if not post:
            raise HTTPException(status_code=404, detail="Post not found.")

        if not post["picture_path"]:
            raise HTTPException(status_code=404, detail="Post image not found.")

        file_name = post["picture_path"]

        blob_client = get_blob_client_util(file_name=file_name)
        
        sas_url = generate_blob_sas_url(blob_client=blob_client,
                                        container_name=USERIMAGE_CONTAINER,
                                        file_name=file_name,
                                        account_key=blob_service_client.credential.account_key,
                                        permissions=BlobSasPermissions(read=True),
                                        expiry=datetime.utcnow() + timedelta(hours=1))

        post_details = {
            "post_id": post["post_id"],
            "title": post["title"],
            "content": post["content"],
            "user_id": post["user_id"],
            "username": post["username"],
            "date_created": post["date_created"],
            "image_url": sas_url
        }
        
        return JSONResponse(content=post_details)
        
    except Exception as e:
        traceback.print_exc()
        raise e