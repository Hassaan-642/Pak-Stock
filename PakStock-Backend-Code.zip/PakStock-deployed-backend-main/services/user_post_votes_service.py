from fastapi import HTTPException
from fastapi.responses import JSONResponse
import traceback
from database.procedures.user_post_votes import (
    create_user_post_vote,
    get_user_post_votes,
    delete_user_post_vote,
)

def create_user_post_vote_service(post_id, user_id, username, isUpvote):
    try:
        create_user_post_vote(post_id=post_id, user_id=user_id, username=username, isUpvote=isUpvote)
        return JSONResponse(content={"message": "Vote added successfully."})

    except Exception as e:
        traceback.print_exc()
        raise e


def get_user_post_votes_service(post_id):
    try:
        votes = get_user_post_votes(post_id)
        if not votes.exists():
            raise HTTPException(status_code=404, detail="No votes found for this post.")
        
        # Serialize results to list of dictionaries
        votes_data = [{"user_id": vote.user_id, "isUpvote": vote.isUpvote} for vote in votes]
        return JSONResponse(content={"votes": votes_data})

    except Exception as e:
        traceback.print_exc()
        raise e


def delete_user_post_vote_service(post_id, user_id):
    try:
        delete_user_post_vote(post_id=post_id, user_id=user_id)
        return JSONResponse(content={"message": "Vote deleted successfully."})

    except Exception as e:
        traceback.print_exc()
        raise e
