from fastapi import HTTPException
from fastapi.responses import JSONResponse
import traceback
from database.procedures.user_posts import (
    create_user_post,
    get_user_post,
    update_user_post,
    delete_user_post,
    get_all_user_posts,
)

def create_user_post_service(title, content, user_id, username, picture_path = None):
    try:
        created_post = create_user_post(title=title, content=content, user_id=user_id, username=username, picture_path=picture_path)

        return JSONResponse(content={"message": "Post created successfully.", "post": created_post})

    except Exception as e:
        traceback.print_exc()
        raise e

def get_user_post_service(post_id):
    try:
        post = get_user_post(post_id)

        if not post:
            raise HTTPException(status_code=404, detail="Post not found.")
        
        response = JSONResponse(content=post)
        print("get_user_post_service: ", response) 
        
        return response 
    
    except Exception as e:
        traceback.print_exc()
        raise e


def update_user_post_service(post_id, title = None, content = None, picture_path = None):
    try:
        updated_rows = update_user_post(post_id, title, content, picture_path)
        
        if updated_rows == 0:
            raise HTTPException(status_code=404, detail="Post not found or no changes made.")
        
        return JSONResponse(content={"message": "Post updated successfully."})
    except Exception as e:
        traceback.print_exc()
        raise e


def delete_user_post_service(post_id):
    try:
        rows_deleted = delete_user_post(post_id)

        if rows_deleted == 0:
            raise HTTPException(status_code=404, detail="Post not found.")
        
        return JSONResponse(content={"message": "Post deleted successfully."})

    except Exception as e:
        traceback.print_exc()
        raise e


def get_all_user_posts_service():
    try:
        posts = get_all_user_posts()
        return JSONResponse(content=posts)
     
    except Exception as e:
        traceback.print_exc()
        raise e
