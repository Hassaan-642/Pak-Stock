# utils.py - Utility functions
from passlib.context import CryptContext
from datetime import datetime, timedelta
import random
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from dotenv import load_dotenv
from utility.datetime_utils import getNowTime
from fastapi import HTTPException, status, Depends
from fastapi.security import OAuth2PasswordBearer
import resend
import smtplib
import jwt
from database.procedures.otp import create_otp
import ssl
from email.message import EmailMessage


load_dotenv('.env')
resend.api_key = os.getenv("RESEND_API_KEY")
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = os.getenv("JWT_SECRET_KEY")
ALGORITHM = os.getenv("JWT_ALGORITHM")
JWT_EXPIRATION_TIME = int(os.getenv("JWT_EXP_DELTA_SECONDS")) / 60
from_email = os.getenv("EMAIL_SENDER")
sender_email = os.getenv("EMAIL_SENDER")
sender_password = os.getenv("EMAIL_APP_PASSWORD")
smtp_server = "smtp.gmail.com"
smtp_port = 465
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")  # Not used directly, but needed for FastAPI OAuth2


def hash_password(password: str):
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
        return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: timedelta = timedelta(minutes=JWT_EXPIRATION_TIME)):
    try:
        to_encode = data.copy()
        expire = getNowTime() + expires_delta
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        return encoded_jwt
    
    except Exception as e:
        print(f"Error creating JWT token: {e}")
        raise HTTPException(detail="Internal Server Error", status_code=500)

def decode_jwt_token(token: str):
    try:
        decoded_data = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return decoded_data
    except jwt.ExpiredSignatureError:
        raise HTTPException(detail="Token has expired", status_code=401)
    except jwt.InvalidTokenError:
        raise HTTPException(detail="Invalid token", status_code=401)
    except Exception as e:
        print(f"Error decoding JWT token: {e}")
        raise HTTPException(detail="Internal Server Error", status_code=500)

# Dependency function to verify the JWT from the Authorization header
def verify_jwt(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )

# OTP Generation
def generate_otp():
    return str(random.randint(100000, 999999))

def send_otp_email(email: str, otp_code: str, purpose: str):
    try:
        
        if purpose == "email_verification":
            subject = "Pakstock -- Your email verification OTP"
            body = f"""\
            Dear User,

            Thank you for registering with Pakstock. Please use the following One-Time Password (OTP) to verify your email address:

            OTP: {otp_code}

            If you did not request this, please disregard this email.

            Best regards,
            Pakstock Support
            """
        
        elif purpose == "2fa":
            subject = "Pakstock -- Your Two-Factor Authentication OTP"
            body = f"""\
            Dear User,

            Thank you for using Pakstock. Please use the following One-Time Password (OTP) for Two-factor Authentication (2FA):

            OTP: {otp_code}

            If you did not request this, please disregard this email.

            Best regards,
            Pakstock Support
            """

        # Create an EmailMessage object
        email_object = EmailMessage()
        email_object.set_content(body)
        email_object['Subject'] = subject
        email_object['From'] = sender_email  # Ensure sender_email is defined in your context
        email_object['To'] = email

        context = ssl.create_default_context()
        print("EMAIL: ", email)
        print("smtp_server: ", smtp_server)
        print("smtp_port: ", smtp_port)

        # Send the email using SMTP_SSL
        with smtplib.SMTP_SSL(smtp_server, smtp_port, context=context) as server:
            server.login(sender_email, sender_password)  # Ensure sender_password is defined
            server.send_message(email_object)  # Use send_message instead of sendmail

    except smtplib.SMTPRecipientsRefused as e:
        # Handle if the recipient email is refused
        print(f"Error: Email refused - {e}")
        raise HTTPException(status_code=404, detail="Email address not found")

    except smtplib.SMTPException as e:
        print(f"SMTP Error: {e.smtp_error} - {e}")
        if e.smtp_code == 550:  # Email not found
            raise HTTPException(status_code=404, detail="Email address not found")
        else:
            raise HTTPException(status_code=500, detail="Internal Server Error")

    except Exception as e:
        print(f"General error: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
def send_otp(user, email: str, purpose: str):
    try:
        otp_code = generate_otp()
        create_otp(user, otp_code, purpose)
        send_otp_email(email=email, otp_code=otp_code, purpose=purpose)
        
        return otp_code
    except Exception as e:
        print(f"Error sending OTP: {e}")
        raise e