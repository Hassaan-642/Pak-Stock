from datetime import datetime, timedelta
import pytz

# Returns the current date and time without seconds and microseconds
def get_current_datetime():
    current_date = getNowTime()
    return current_date.replace(second=0, microsecond=0)

def get_N_days_ago_date(days=0):
    current_date = getNowTime()
    
    if(days == 0):
        return current_date.strftime('%y-%m-%d')
    
    N_days_ago = current_date - timedelta(days=days)
    
    return N_days_ago.strftime('%y-%m-%d')

def get_N_days_after_date(days=0):
    current_date = getNowTime()
    
    if(days == 0):
        return current_date.strftime('%y-%m-%d')
    
    N_days_ago = current_date + timedelta(days=days)
    
    return N_days_ago.strftime('%y-%m-%d')


def isNDaysOld(dateToCheck):
    now = getNowTime().date()
    n_time_ago = now - timedelta(days=n)
    is_within_n_time = n_time_ago <= dateToCheck <= now
    return is_within_n_time

def getNowTime():
    return datetime.now(pytz.timezone('Asia/Karachi')).replace(tzinfo=None)
