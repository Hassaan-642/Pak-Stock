from database.schemas.user_posts import UserPosts
from fastapi import HTTPException
from fastapi.responses import JSONResponse
import traceback
from database.procedures.user_posts import (
    update_user_post_image_path,
    get_user_post
)
from datetime import datetime, timedelta
import uuid
import os
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv
from azure.storage.blob import generate_blob_sas, BlobSasPermissions, ContentSettings, BlobClient
from urllib.parse import quote

load_dotenv()

# Ensure the upload folder is set
UPLOAD_FOLDER = os.getenv("USER_ARTICLE_IMAGE_UPLOAD_FOLDER")
CONNECTION_STRING = os.getenv("AZUREFILESTORAGE_CONNECTION_STRING")
USERIMAGE_CONTAINER = os.getenv("AZUREFILESTORAGE_USERIMAGES_CONTAINER")

# Initialize the BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
container_client = blob_service_client.get_container_client(USERIMAGE_CONTAINER)

# Returns the blob object that references the file_name
def get_blob_client_util(file_name):
    return container_client.get_blob_client(file_name)

def upload_file_to_filestorage(file_content: bytes, file_name: str, content_type: str, blob_client: BlobClient):
    # Print file size (should match previous print)
    print("File size (during upload):", len(file_content))

    # Upload the file with correct MIME type
    blob_client.upload_blob(
        file_content,
        overwrite=True,
        content_settings=ContentSettings(content_type=content_type)  # Ensure correct content type
    )

    print(f"File uploaded successfully with unique ID '{file_name}'.")

def generate_blob_sas_url(blob_client: BlobClient, container_name: str, file_name: str, account_key, permissions: BlobSasPermissions, expiry: datetime):
    # Generate SAS token for secure access (valid for 1 hour)
    sas_token = generate_blob_sas(
        account_name=blob_service_client.account_name,
        container_name=USERIMAGE_CONTAINER,
        blob_name=file_name,
        account_key=blob_service_client.credential.account_key,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.utcnow() + timedelta(hours=1)
    )

    # Ensure correct filename when downloading
    content_disposition = f'attachment; filename="{file_name}"'

    # Generate full URL with SAS token and response headers
    sas_url = (
        f"https://{blob_service_client.account_name}.blob.core.windows.net/"
        f"{USERIMAGE_CONTAINER}/{file_name}?{sas_token}"
    )

    return sas_url