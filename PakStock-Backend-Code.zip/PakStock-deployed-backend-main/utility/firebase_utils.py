from fastapi import HTTPException, Request, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from firebase_admin import auth
from firebase_admin import credentials, firestore, auth
import firebase_admin
import traceback

security = HTTPBearer()
cred = credentials.Certificate("./resources/firebase-auth.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

async def verify_jwt(request: Request):
    # Extract token from header
    try:

        credentials: HTTPAuthorizationCredentials = await security(request)
        if not credentials:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authorization header missing"
            )
        
    
        decoded_token = auth.verify_id_token(credentials.credentials)
        return decoded_token
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token: {str(e)}"
        )

async def get_user_role(user_id: str):
    try:
        user_ref = db.collection('Users').document(user_id)
        user_doc = user_ref.get()
        
        if user_doc.exists:
            print(f"User document found: {user_doc.to_dict()}")
            user_role = user_doc.to_dict().get('role')

            if user_role is not None:
                return user_role
            else:
                raise Exception("User role not found in document")
        else:
            print(f"No document found for user_id: {user_id}")
            raise HTTPException(status_code=404, detail="User not found")
    except Exception as e:
        traceback.print_exc()
        print(f"Exception occurred: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error fetching user role: {str(e)}")