import json
import dotenv
import os
import base64

dotenv.load_dotenv('.env')


industries = os.getenv('INDUSTRIES')
companies = os.getenv('COMPANIES')
stock_images = os.getenv('STOCK_IMAGE_PATH')
# n = int(os.getenv('N'))

def get_image(stock_symbol: str):
    for filename in os.listdir(stock_images):
        if stock_symbol.upper() in filename.upper():
            file_path = os.path.join(stock_images, filename)
            with open(file_path, "rb") as f:
                image_data = f.read()
            return image_data

def get_image_b64_encoded(stock_symbol: str):
    image = get_image(stock_symbol)
    return base64.b64encode(image).decode('utf-8')

def get_kse_companies_object():
    # Extract common search terms
    with open(companies, 'r') as json_file:
        data = json.load(json_file)

    return data

def get_kse_industries():
    terms = []
    # Extract common search terms
    with open(industries, 'r') as json_file:
        data = json.load(json_file)

    # get keys
    keys = data.keys()

    return keys

def get_industry_search_terms():
    terms = []
    # Extract common search terms
    with open(industries, 'r') as json_file:
        data = json.load(json_file)

    # get keys
    keys = data.keys()

    # get the terms for all the keys
    for key in keys:
        terms += data[key]

    return terms

def get_industries_object():
    # Extract common search terms
    with open(industries, 'r') as json_file:
        data = json.load(json_file)

    return data

def get_stock_symbols():
    data = get_kse_companies_object()
    symbols = []
    for sector, companies in data.items():
        for company in companies:
            symbols.append(company['symbol'])
    return symbols


def validate_stock_symbol(uppercase_stock_symbol: str):
    stock_symbols = get_stock_symbols()
    if uppercase_stock_symbol in stock_symbols:
        return True
    else:
        return False

def validate_industry(industry: str):
    industries = get_kse_companies_object()
    if industry in industries.keys():
        return True
    else:
        return False

def get_industry_by_psx_symbol(symbol: str):
    data = get_kse_companies_object()
    # print(json.dumps(data, indent=4))

    # print(data.items())

    for sector, companies in data.items():
        for company in companies:
            if company['symbol'] == symbol:
                return sector
    return False

def get_all_stock_symbols_for_specified_industry(industry: str):
    data = get_kse_companies_object()
    symbols = []

    # get specifically key = 'industry' and its companies
    targetted_industry = data[industry]

    for company in targetted_industry:
        symbols.append(company['symbol'])

    return symbols