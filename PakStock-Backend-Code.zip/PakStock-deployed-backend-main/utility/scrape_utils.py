import requests, re
from bs4 import BeautifulSoup
import random
import httpx

class Proxies:
    def __init__(self, max_retries, timeout_seconds):
        self.MAX_RETRIES = max_retries
        self.TIMEOUT_SECONDS = timeout_seconds
        self.proxies=[]
        self.proxy=""

    # Headers to mimic a real browser
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
    }

    def refresh_proxies(self):
        """Refresh the proxy list by fetching new proxies from the sources."""
        print("Proxy list refreshed.")
        self.proxies = refresh_proxies()

    def get_random_proxy(self):
        """Select a random proxy from the proxies_list.txt file."""
        try:
            if len(self.proxies) < 1:
                raise ValueError("Proxy list is empty. Please check proxies_list.txt.")
            

            self.proxy = random.choice(self.proxies)
            # print(proxy)
            # print(proxies)
            return self.proxy
        except Exception as e:
            print(f"Error selecting a proxy: {e}")
            raise

    def create_session(self):
        """Create a requests session with headers and a random proxy."""
        session = httpx.Client()
        session.headers.update(self.HEADERS)
        self.get_random_proxy()
        # print(proxy)
        session.proxies = {
            'http': self.proxy,
            'https': self.proxy
        }
        print(f'Using proxy: {self.proxy}')
        return session

    def remove_proxy(self):
        self.proxies.remove(self.proxy)



def refresh_proxies():
    proxies = []
    regex = r"[0-9]+(?:\.[0-9]+){3}:[0-9]+"
    c = requests.get("https://spys.me/proxy.txt")
    test_str = c.text
    a = re.finditer(regex, test_str, re.MULTILINE)

    for i in a:
        proxies.append(i.group())
    #==========================================================
    d = requests.get("https://free-proxy-list.net/")
    soup = BeautifulSoup(d.content, 'html.parser')
    td_elements = soup.select('.fpl-list .table tbody tr td')
    
    for j in range(0, len(td_elements), 8):
        ip = td_elements[j].text.strip()
        port = td_elements[j + 1].text.strip()

        proxies.append(f"{ip}:{port}")    

    return proxies