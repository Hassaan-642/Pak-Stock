from dotenv import load_dotenv
import json
import spacy

load_dotenv()
# Load SpaCy model
nlp = spacy.load("en_core_web_md")

def generate_stock_data_documents():
    """
    Load and transform company information documents into the required format for ChromaDB.
    """
    with open('./resources/company_info.json', 'r') as f:
        data = json.load(f)
    print(data)

    documents = []
    ids = []
    meta_data = []
    id_count = 1

    for obj in data:
        # Combine key information into a content field for vectorization
        content = (
            f"{obj.get('company_information', '')} "
            f"Address: {obj.get('address', '')}. "
            f"Website: {obj.get('website', '')}."
        )

        # Extract metadata for filtering and retrieval
        stock_name = obj.get("stock_name", "").split("(")[0]
        meta = {
            "ceo_name": obj.get("ceo_name"),
            "chairperson_name": obj.get("chairperson_name"),
            "fiscal_year_end": obj.get("fiscal_year_end"),
            "market_cap": obj.get("market_cap"),
            "free_float_percentage": obj.get("free_float_percentage"),
            "stock_name": stock_name
        }

        documents.append(content)
        meta_data.append(meta)
        ids.append(f"id{id_count}")
        id_count += 1

    return {"documents": documents, "meta_data": meta_data, "ids": ids}

def generate_website_info_document():
    id = "id99"
    document = """
        PakStock addresses the challenges faced by PSX investors by providing an AI-driven platform offering predictive analytics, market sentiment analysis, personalized recommendations, and real-time broker communication. Its key features include a prediction system, sentiment analysis of news, buy/sell/hold recommendations, and a community collaboration environment. The platform enhances decision-making with accurate market forecasts, risk assessment, and dynamic insights, while fostering user engagement through intuitive tools like chatbots and direct broker interaction. PakStock aims to empower investors with actionable insights, enabling confident and informed investment strategies in the PSX.
    """
    meta_data = {
        "refers_to": "this website",
        "name": "PakStock",
        "website_name": "PakStock",
        "website_url": "https://pakstock.com",
        "website_description": "AI-driven platform offering predictive analytics, market sentiment analysis, personalized recommendations, and real-time broker communication for PSX investors."
    }

    # Manually defined website information:


    return {"documents": document, "meta_data": meta_data, "ids": id}

def generate_investor_guide_document():
    documents = [
        "Free Float of Shares: Shares of a company available for trading by the public, excluding shares held by insiders, promoters, or governments.\nOutstanding Shares: Total number of shares a company has issued, including restricted shares held by insiders and shares available for public trading.\nTreasury Shares: Shares that a company has repurchased from the market but has not canceled; they are not available for trading.\nBullish Momentum: A market condition where stock prices are expected to rise, indicating positive investor sentiment.\nBearish Momentum: A market condition where stock prices are expected to fall, indicating negative investor sentiment.",
        "Simple Moving Average (SMA): The average stock price over a specific time period, used to identify trends.\nExponential Moving Average (EMA): A weighted moving average that gives more significance to recent prices, useful for detecting short-term trends.\nRelative Strength Index (RSI): A momentum oscillator that measures the speed and change of price movements, indicating overbought or oversold conditions.\nMoving Average Convergence Divergence (MACD): A trend-following indicator showing the relationship between two moving averages, used to identify buy/sell signals.\nVolume Analysis: Analyzing the number of shares traded in a period to confirm trends or reversals.",
        "Mean Squared Error (MSE): A metric to evaluate prediction accuracy, representing the average squared difference between predicted and actual values.\nSentiment Score: A numerical representation of the sentiment (positive, negative, or neutral) derived from text data, often used in news analysis.",
        "Normalization: Scaling data to bring all values into a specific range, improving model performance.\nStandardization: Transforming data to have a mean of 0 and a standard deviation of 1 for consistency.\nData Integration: Combining data from multiple sources into a unified dataset for analysis.\nPre-processing: Cleaning data to remove potential errors involving null values, commas, or extra dots.",
        "Transfer Learning: Reusing a pre-trained machine learning model on a new but related problem, improving efficiency.\nFine-Tuning: Adjusting the parameters of a pre-trained model to better fit new data.\nFeature Engineering: Creating new features or transforming existing ones to improve model predictions.\nSupervised Learning: Training a model using labeled data, where the output is known for each input.\nUnsupervised Learning: Training a model to identify patterns in data without labeled outputs.\nReinforcement Learning: A machine learning approach where an agent learns to make decisions by taking actions in an environment to maximize a reward.\nCross-Validation: A technique for assessing how well a model generalizes to unseen data by splitting the data into training and validation subsets.\nHyperparameter Tuning: Optimizing the settings of a machine learning model to improve its performance on a given dataset.\nOverfitting: A condition where a model performs well on training data but poorly on unseen data due to excessive complexity.\nUnderfitting: A condition where a model is too simple to capture the underlying patterns in the data.",
        "Ensemble Learning: Combining multiple machine learning models to improve overall performance and robustness.\nBagging (Bootstrap Aggregating): An ensemble method that reduces variance by training multiple models on different subsets of the data.\nBoosting: An ensemble method that combines weak models sequentially, improving the accuracy of the overall model.\nNeural Networks: A computational framework inspired by the human brain, consisting of layers of interconnected nodes (neurons).\nDeep Learning: A subset of machine learning that uses neural networks with many layers (deep architectures) to model complex patterns in data.\nActivation Function: A function that determines the output of a node in a neural network, introducing non-linearities for better learning.\nLoss Function: A mathematical function that measures the error between predicted and actual values, guiding the optimization process.\nGradient Descent: An optimization algorithm used to minimize the loss function by iteratively adjusting model parameters.\nEpoch: One complete pass through the entire training dataset during model training.\nBatch Size: The number of training examples used in one iteration of model training.",
        "Pak Stock Developers and Leadership Team: Pak Stock is built and maintained by a dedicated team of experts who specialize in data science, artificial intelligence, and software development. Their contributions ensure a robust and efficient stock market analysis platform. Developers include Hassaan Ul Haq (Data and AI Lead), Taimur Mahmood (Backend Lead), Muhammad Jawad (Front End Lead) and Mr. Yasir Ali (Supervisor of Pak Stock)",
        "Hassaan Ul Haq (Data and AI Lead): An expert in data science and artificial intelligence, Hassaan is responsible for developing and implementing advanced machine learning models for stock market prediction and analysis.",
        "Taimur Mahmood (Backend Lead): Leading the backend development, Taimur ensures the smooth processing of stock data, optimizing APIs, and maintaining the system’s stability and performance.",
        "Muhammad Jawad (Front End Lead): The creative force behind the user interface, Jawad designs and develops an intuitive, user-friendly experience for investors and traders.",
        "Mr. Yasir Ali (Supervisor of Pak Stock): As the guiding force behind Pak Stock, Mr. Yasir Ali provides strategic direction, ensuring the platform aligns with industry standards and delivers accurate insights to users.",
        "AI Models Implemented: Pak Stock utilizes two powerful machine learning models for stock market prediction and trend analysis. The first is K-Means Clustering combined with Linear Regression, which helps group similar stocks and predict price trends based on historical patterns. The second model is a Random Forest Regressor, which enhances prediction accuracy by analyzing multiple decision trees and reducing overfitting.",
        "Historical Data Sources: Our stock market predictions are based on a rich dataset collected from two sources. Historical data from 2008 to 2020 has been sourced from Kaggle, ensuring a comprehensive view of long-term market trends. For real-time and recent stock movements, data from 2020 onwards is dynamically scraped from the Pakistan Stock Exchange (PSX) website.",
        "Frontend Technologies: The Pak Stock platform is built using React, a modern JavaScript library that ensures a responsive, interactive, and user-friendly interface. React allows seamless updates, efficient rendering, and a smooth user experience for investors engaging with stock insights and AI-driven predictions.",
        "Backend Technologies: The backend infrastructure of Pak Stock is powered by FastAPI, a high-performance web framework for building APIs with Python. FastAPI enables efficient processing of stock data, secure API interactions, and real-time retrieval of predictions and market insights.",
        "Database Management: Pak Stock leverages MySQL as its primary database for storing stock data, user interactions, and AI model outputs. MySQL provides robust data handling, optimized queries, and secure storage of financial records and analytics.",
        "Cloud Deployment & Infrastructure: The AI models and data processing pipelines are deployed on Microsoft Azure. Azure's cloud infrastructure allows scalable computations, real-time data fetching, and automated scheduling of accuracy scripts to continuously refine model predictions.",
        "Automated Data Fetching & Accuracy Monitoring: The stock market prediction system is maintained through scheduled scripts that run on Azure. These scripts automate data fetching from the PSX website and validate the accuracy of AI models, ensuring precise and reliable predictions for investors.",
        "Community Collaboration Module: Discussion Forum: Users post questions, share insights, and discuss investing. Q&A Section: Community-driven knowledge sharing and support. User Profiles: Showcase expertise, interests, and goals. Engagement Features: Upvoting, commenting, and post history tracking.",
        "Prediction System Module: Transfer Learning: Train ML models efficiently. Evaluation: Use MSE for accuracy assessment. Model Updates: Continuously fine-tune with new data. Dashboards: Visualize predictions.",
        "Sentiment Analysis Module: NLP-Based Sentiment Analysis: Classify news as positive, negative, or neutral. Data Updates: Scrape financial news for real-time insights. APIs: Provide sentiment analysis services for external use.",
        "Recommendation System Module: Data-Driven Suggestions: Analyze stock data to recommend actions. Sentiment Integration: Incorporate news sentiment into recommendations. Technical Indicators: Utilize SMA, EMA, RSI, MACD, and volume analysis. Actionable Insights: Present buy/sell/hold suggestions.",
        "Content Creation & Sharing Module: Article Creation: Users write blogs with HTML storage and separate image paths. Publishing & Engagement: Format text, embed images, track upvotes/downvotes. Content Moderation: Flag harmful content, enable reporting, and manage moderators. Sharing Options: Unique URLs and social media integration.",
        "Historical Data Management Module: Stock Data Collection: Scrape PSX data and integrate API sources. Data Processing: Standardize, clean, normalize, and store. Analytics & Insights: Identify trends and summarize findings. Interactive Dashboards: Visualize trends with charts.",
        "User Authentication & Management Module: Secure Login: Protect user accounts with strong authentication. Admin Panel: Manage users, roles, and broker accounts. Profile Management: Users manage published content. Security: Session management and audit logging.",
        "ChatBot Module: Website Assistance: Answer queries on features, stocks, and services. Stock Data Display: Show real-time stock insights. Investor Guide: Glossary and broker listings. Market Updates: Deliver stock predictions and analysis.",
        "Broker Communication & Real-Time Chat Module: Broker Login: Dedicated access to manage user messages. Document Sharing: Receive files for PSX account creation. Real-Time Chat: Seamless interaction between users and brokers. Notifications: Alert brokers about new messages.",
        "Pak Stock Modules: Pak stock has 9 modules in total i.e Community Collaboration Module, Prediction System Module, Sentiment Analysis Module, Recommendation System Module, Content Creation & Sharing Module, Historical Data Management Module, User Authentication & Management Module, ChatBot Module and Broker Communication & Real-Time Chat Module.",
        "Chatbot-Development: The chatbot is built using the Mistral 7B model from Hugging Face, leveraging a Retrieval-Augmented Generation (RAG) approach for enhanced contextual responses. It integrates ChromaDB as a vector database to efficiently store and retrieve indexed document embeddings.",
        "Why Pak Stock is needed: Investors in the Pakistan Stock Exchange (PSX) lack a unified platform that integrates predictive analytics, sentiment analysis, recommendations, and real-time broker communication. Our solution leverages AI-driven insights, technical indicators, and community collaboration to empower smarter investment decisions. The Invest Now feature seamlessly transitions users from insights to action."
    ]

    meta_datas = [
        {
            "category": "Finance",
            "topic": "Stock Market Terms"
        },
        {
            "category": "Finance",
            "topic": "Technical Analysis"
        },
        {
            "category": "AI/ML",
            "topic": "Prediction and Sentiment Analysis"
        },
        {
            "category": "Data Science",
            "topic": "Data Management"
        },
        {
            "category": "AI/ML",
            "topic": "Machine Learning Basics"
        },
        {
            "category": "AI/ML",
            "topic": "Advanced Machine Learning"
        },
        {
            "category": "Developers and Leadership Team",
            "topic": "Pak Stock Team"
        },
        {
            "category": "Data and AI",
            "topic": "Data and AI team"
        },
        {
            "category": "Backend",
            "topic": "Backend Team"
        },
        {
            "category": "Frontend",
            "topic": "Frontend Team"
        },
        {
            "category": "Supervision",
            "topic": "Supervisor"
        },
        {
            "category": "AI/ML",
            "topic": "Machine Learning Models"
        },
        {
            "category": "Data Science",
            "topic": "Historical Data Sources"
        },
        {
            "category": "Frontend",
            "topic": "React Development"
        },
        {
            "category": "Backend",
            "topic": "FastAPI Development"
        },
        {
            "category": "Database",
            "topic": "MySQL for Stock Market Data"
        },
        {
            "category": "Cloud Computing",
            "topic": "Azure Deployment"
        },
        {
            "category": "Automation",
            "topic": "Data Fetching & Accuracy Monitoring"
        },
        {
        "category": "Community & Engagement",
        "topic": "Community Collaboration Module"
        },
        {
        "category": "Machine Learning",
        "topic": "Prediction System Module"
        },
        {
        "category": "Natural Language Processing",
        "topic": "Sentiment Analysis Module"
        },
        {
        "category": "AI-Driven Recommendations",
        "topic": "Recommendation System Module"
        },
        {
        "category": "Content Management",
        "topic": "Content Creation & Sharing Module"
        },
        {
        "category": "Data Management",
        "topic": "Historical Data Management Module"
        },
        {
        "category": "Security & Authentication",
        "topic": "User Authentication & Management Module"
        },
        {
        "category": "Conversational AI",
        "topic": "ChatBot Module"
        },
        {
        "category": "Real-Time Communication",
        "topic": "Broker Communication & Real-Time Chat Module"
        },
        {
        "category": "System Overview",
        "topic": "Pak Stock Modules Overview"
        },
        {
        "category": "AI & NLP",
        "topic": "Chatbot Development"
        },
        {
        "category": "Market Need & Justification",
        "topic": "Why Pak Stock is Needed"
        }

    ]

    ids = ["id100", "id101", "id102", "id103", "id104", "id105", "id106", "id107", "id108", "id109", "id110", "id111", "id112", "id113", "id114", "id115", "id116", "id117" , "id118" , "id119" , "id120" , "id121" , "id122" , "id123" , "id124" , "id125" , "id126" , "id127" , "id128" , "id129"]

    return {"documents": documents, "meta_data": meta_datas, "ids": ids}    



def extract_keywords(query):
    """
    Extract keywords from the user query.
    """
    doc = nlp(query)
    keywords = [token.text for token in doc if token.pos_ in ("NOUN", "PROPN", "VERB")]
    return keywords
